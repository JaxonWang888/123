@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 需要本机AutoCAD Mechanical 2018。请等待每个自动处理任务结束。
for %%F in ("基础样例-腹板在中间.dwg" "基础样例-腹板在侧面.dwg" "基础样例-Note8缺口.dwg" "基础样例-腹板在中间.dxf" "基础样例-腹板在侧面.dxf" "基础样例-Note8缺口.dxf") do (
 start /wait "" "%~dp0鞍座图纸生成器.exe" --cad-postprocess "%~dp0%%~F" 15 0 0 1
 if errorlevel 1 goto failed
)
start /wait "" "%~dp0鞍座图纸生成器.exe" --cad-postprocess "%~dp0基础样例-比例1比25.dwg" 25 0 0 1
if errorlevel 1 goto failed
start /wait "" "%~dp0鞍座图纸生成器.exe" --cad-postprocess "%~dp0基础样例-比例1比25.dxf" 25 0 0 1
if errorlevel 1 goto failed
echo 完成。请查看同名自动处理日志并检查原生BOM。
pause
exit /b 0
:failed
echo 自动处理未完成，图纸不应作为最终结果。请查看同名日志。
pause
exit /b 1
