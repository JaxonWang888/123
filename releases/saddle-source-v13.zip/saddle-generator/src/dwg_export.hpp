// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "model.hpp"
#include "dxf_compat.hpp"
#include "cad_compat.hpp"
#include <cstring>
extern "C" {
#include "dwg.h"
#include "dwg_api.h"
#include "bits.h"
#include "out_dxf.h"
}
namespace saddle {
// The API converts UTF-8 into CP936; the encoder consumes these bytes directly.
inline std::string cadString(const std::string&v){return v;}
inline Dwg_Object* namedObject(Dwg_Data*d,const std::string&name,const char*table){
 auto bytes=dwg_add_u8_input(d,name.c_str());Dwg_Object* result=nullptr;
 for(unsigned i=0;i<d->num_objects;i++){auto*o=&d->object[i];const char*key=nullptr;
  if(!strcmp(table,"APPID")&&o->fixedtype==DWG_TYPE_APPID)key=o->tio.object->tio.APPID->name;
  if(!strcmp(table,"STYLE")&&o->fixedtype==DWG_TYPE_STYLE)key=o->tio.object->tio.STYLE->name;
  if(!strcmp(table,"LAYER")&&o->fixedtype==DWG_TYPE_LAYER)key=o->tio.object->tio.LAYER->name;
  if(!strcmp(table,"LTYPE")&&o->fixedtype==DWG_TYPE_LTYPE)key=o->tio.object->tio.LTYPE->name;
  if(!strcmp(table,"DIMSTYLE")&&o->fixedtype==DWG_TYPE_DIMSTYLE)key=o->tio.object->tio.DIMSTYLE->name;
  if(!strcmp(table,"BLOCK_RECORD")&&o->fixedtype==DWG_TYPE_BLOCK_HEADER)key=o->tio.object->tio.BLOCK_HEADER->name;
  if(key&&(!strcmp(key,bytes)||!strcmp(key,name.c_str()))){result=o;break;}
 }free(bytes);return result;
}
inline Dwg_Object_DIMSTYLE*getDimstyle(Dwg_Data*d,const char*name){auto o=namedObject(d,name,"DIMSTYLE");return o?o->tio.object->tio.DIMSTYLE:dwg_add_DIMSTYLE(d,cadString(name).c_str());}
inline BITCODE_H tableRef(Dwg_Data*d,const std::string&name,const char*table){auto o=namedObject(d,name,table);if(!o)return nullptr;return dwg_add_handleref(d,5,o->handle.value,nullptr);}
inline BITCODE_H blockRef(Dwg_Data*d,const std::string&name){
 auto o=namedObject(d,name,"BLOCK_RECORD");if(o)return dwg_add_handleref(d,5,o->handle.value,nullptr);
 auto b=dwg_add_BLOCK_HEADER(d,cadString(name).c_str());if(!b)throw std::runtime_error("Cannot create dimension arrow block");auto handle=d->object[b->parent->objid].handle.value;dwg_add_BLOCK(b,cadString(name).c_str());dwg_point_3d a={0,0,0};dwg_point_2d c={-1,name=="Filled-1"?.125:.166667},e={-1,name=="Filled-1"?-.125:-.166667};dwg_add_SOLID(b,&a,&c,&e,&e);if(name=="Filled-1"){dwg_point_3d v[4]={{-1,0,0},{-1,-.125,0},{0,0,0},{-1,.125,0}};dwg_add_LINE(b,&v[0],&v[2]);dwg_add_LINE(b,&v[1],&v[2]);dwg_add_LINE(b,&v[2],&v[3]);dwg_add_LINE(b,&v[3],&v[1]);}dwg_add_ENDBLK(b);return dwg_add_handleref(d,5,handle,nullptr);
}
}
#include "reference_native.hpp"
namespace saddle {
inline int lineweightCode(int v){if(v==-1)return 29;if(v==-2)return 30;if(v==-3)return 31;const int weights[]={0,5,9,13,15,18,20,25,30,35,40,50,53,60,70,80,90,100,106,120,140,158,200,211};for(int i=0;i<24;i++)if(weights[i]==v)return i;return 31;}
inline unsigned modelEntityCount(Dwg_Data*d){unsigned count=0;auto*block=dwg_model_space_object(d);for(auto*e=get_first_owned_entity(block);e;e=get_next_owned_entity(block,e))if(e->fixedtype!=DWG_TYPE_BLOCK&&e->fixedtype!=DWG_TYPE_ENDBLK)count++;return count;}
inline unsigned long cadAppID(Dwg_Data*d){auto*o=namedObject(d,"ACAD","APPID");if(o)return o->handle.value;auto*a=dwg_add_APPID(d,"ACAD");return d->object[a->parent->objid].handle.value;}
inline void cadFontFamily(Dwg_Data*d,Dwg_Object_STYLE*style,bool chinese){
 auto*parent=style->parent;const char*family=chinese?"SimSun":"Arial";size_t n=strlen(family);parent->num_eed=2;parent->eed=(Dwg_Eed*)calloc(2,sizeof(Dwg_Eed));
 auto*text=(Dwg_Eed_Data*)calloc(1,sizeof(Dwg_Eed_Data)+n+1);text->code=0;text->u.eed_0.length=n;text->u.eed_0.codepage=1252;memcpy(text->u.eed_0.string,family,n+1);
 auto*flags=(Dwg_Eed_Data*)calloc(1,sizeof(Dwg_Eed_Data));flags->code=71;flags->u.eed_71.rl=34|(chinese?134<<8:0);
 parent->eed[0].data=text;parent->eed[0].size=n+9;dwg_add_handle(&parent->eed[0].handle,5,cadAppID(d),nullptr);parent->eed[1].data=flags;
}
// ACAD DSTYLE overrides keep the source style while recording real tolerances.
inline void dimensionOverrides(Dwg_Data*d,Dwg_Object_Entity*entity,const Dimension&q,double scale){
 std::vector<std::pair<int,double>> values={{40,scale},{279,2}};if(q.tolerance){std::vector<std::pair<int,double>> tolerance={{71,1},{47,q.tolerance},{48,q.tolerance},{272,1},{284,0},{146,1}};values.insert(values.end(),tolerance.begin(),tolerance.end());}if(q.measurementScale!=1)values.push_back({144,q.measurementScale});
 unsigned long handle=cadAppID(d);
 entity->num_eed=3+2*values.size();entity->eed=(Dwg_Eed*)calloc(entity->num_eed,sizeof(Dwg_Eed));unsigned index=0,total=14;
 auto next=[&](int code){auto*data=(Dwg_Eed_Data*)calloc(1,sizeof(Dwg_Eed_Data)+16);data->code=code;entity->eed[index++].data=data;return data;};
 auto*name=next(0);name->u.eed_0.length=6;name->u.eed_0.codepage=1252;memcpy(name->u.eed_0.string,"DSTYLE",7);next(2)->u.eed_2.close=0;
 for(auto v:values){next(70)->u.eed_70.rs=v.first;bool integer=v.first==71||v.first==272||v.first==284||v.first==279;auto*val=next(integer?70:40);if(integer)val->u.eed_70.rs=(int)v.second;else val->u.eed_40.real=v.second;total+=integer?6:12;}
 next(2)->u.eed_2.close=1;entity->eed[0].size=total;dwg_add_handle(&entity->eed[0].handle,5,handle,nullptr);
}
inline void writeCAD(const Drawing&d,const std::string&path,bool asDWG){
 Dwg_Data*dwg=dwg_new_Document(R_2000,0,0);if(!dwg)throw std::runtime_error("DWG allocation failed");
 try {
 dwg->header.codepage=39;dwg->header_vars.INSUNITS=4;dwg->header_vars.LTSCALE=d.plotFactor;dwg->header_vars.MEASUREMENT=1;
 dwg->header_vars.EXTMIN={d.minX,d.minY,0};dwg->header_vars.EXTMAX={d.maxX,d.maxY,0};
 auto types=refLtypes(d.type);auto layers=refLayers(d.type);auto styles=refStyles(d.type);
 std::vector<unsigned long> lh,sh,th;
 for(auto&t:types){auto o=namedObject(dwg,t.name,"LTYPE");auto*l=o?o->tio.object->tio.LTYPE:dwg_add_LTYPE(dwg,cadString(t.name).c_str());if(!l)throw std::runtime_error("Cannot create reference linetype");l->description=dwg_add_u8_input(dwg,cadString(t.description).c_str());l->alignment=65;l->numdashes=t.dashes.size();l->pattern_len=0;free(l->dashes);l->dashes=(Dwg_LTYPE_dash*)calloc(t.dashes.size(),sizeof(Dwg_LTYPE_dash));for(size_t i=0;i<t.dashes.size();i++){l->dashes[i].parent=l;l->dashes[i].length=t.dashes[i];l->dashes[i].scale=1;l->pattern_len+=std::abs(t.dashes[i]);}th.push_back(dwg->object[l->parent->objid].handle.value);}
 for(auto&t:styles){auto o=namedObject(dwg,t.name,"STYLE");auto*l=o?o->tio.object->tio.STYLE:dwg_add_STYLE(dwg,cadString(t.name).c_str());if(!l)throw std::runtime_error("Cannot create reference text style");l->width_factor=t.width;l->text_size=t.height;l->oblique_angle=t.oblique*PI/180;l->last_height=t.lastHeight;l->font_file=dwg_add_u8_input(dwg,t.font.c_str());l->bigfont_file=dwg_add_u8_input(dwg,t.bigfont.c_str());cadFontFamily(dwg,l,t.name=="Saddle_SimSun");sh.push_back(dwg->object[l->parent->objid].handle.value);}
 for(auto&t:layers){auto o=namedObject(dwg,t.name,"LAYER");auto*l=o?o->tio.object->tio.LAYER:dwg_add_LAYER(dwg,cadString(t.name).c_str());if(!l)throw std::runtime_error("Cannot create reference layer");l->color.index=t.color;l->linewt=lineweightCode(t.lw);l->plotflag=t.plot;l->ltype=dwg_add_handleref(dwg,5,th.at(t.lt),nullptr);lh.push_back(dwg->object[l->parent->objid].handle.value);}
 if(d.type)dimstyles1(dwg);else dimstyles0(dwg);
 auto addEntity=[&](const Entity&e,Dwg_Object_BLOCK_HEADER*b){
  dwg_point_3d p={e.x,e.y,0},q={e.a,e.b,0};Dwg_Object_Entity*parent=nullptr;
  if(e.kind==0){auto*x=dwg_add_LINE(b,&p,&q);if(x)parent=x->parent;}
  else if(e.kind==1){auto*x=dwg_add_CIRCLE(b,&p,e.a);if(x)parent=x->parent;}
  else if(e.kind==2){auto*x=dwg_add_ARC(b,&p,e.a,fmod(e.b+360,360)*PI/180,fmod(e.c+360,360)*PI/180);if(x)parent=x->parent;}
  // One named style for all visible text. Chinese uses a one-line MTEXT font
  // override so HM-ASME can remain Arial Regular without losing SimSun glyphs.
  else if(e.kind==3&&cadHasChinese(e.text)){
   double angle=e.rotation*PI/180;dwg_point_3d top={e.x-e.a*sin(angle),e.y+e.a*cos(angle),0};
   std::string content="{\\fSimSun|b0|i0|c134|p18;\\W1;"+cadUnicodeText(e.text)+"}";
   auto*x=dwg_add_MTEXT(b,&top,e.a*(cadCodepoints(e.text).size()+2)*2,content.c_str());
   if(x){x->text_height=e.a;x->attachment=1;x->flow_dir=1;x->x_axis_dir={cos(angle),sin(angle),0};x->linespace_style=1;x->linespace_factor=1;x->style=tableRef(dwg,"HM-ASME","STYLE");parent=x->parent;}
  }
  else if(e.kind==3){auto*x=dwg_add_TEXT(b,cadUnicodeText(e.text).c_str(),&p,e.a);if(x){x->rotation=e.rotation*PI/180;x->width_factor=e.widthFactor;x->style=tableRef(dwg,"HM-ASME","STYLE");parent=x->parent;}}
  else if(e.kind==4){auto*x=dwg_add_MTEXT(b,&p,e.width,cadUnicodeText(e.text).c_str());if(x){x->text_height=e.a;x->attachment=e.attachment;x->flow_dir=5;x->x_axis_dir={cos(e.rotation*PI/180),sin(e.rotation*PI/180),0};x->linespace_style=1;x->linespace_factor=1;x->style=tableRef(dwg,"HM-ASME","STYLE");parent=x->parent;}}
  else if(e.kind==5){dwg_point_3d a={e.points[0],e.points[1],0};dwg_point_2d c={e.points[2],e.points[3]},dd={e.points[4],e.points[5]},ee={e.points[6],e.points[7]};auto*x=dwg_add_SOLID(b,&a,&c,&dd,&ee);if(x)parent=x->parent;}
  else if(e.kind==6&&e.degree<0){std::vector<dwg_point_3d> pts;for(size_t i=0;i<e.points.size();i+=2)pts.push_back({e.points[i],e.points[i+1],0});dwg_point_3d tan={0,0,0};auto*x=dwg_add_SPLINE(b,pts.size(),pts.data(),&tan,&tan);if(x){x->degree=-e.degree;parent=x->parent;}}
  else if(e.kind==6){dwg_point_3d fit[2]={{e.x,e.y,0},{e.x+1,e.y+1,0}},tan={0,0,0};auto*x=dwg_add_SPLINE(b,2,fit,&tan,&tan);if(x){free(x->fit_pts);x->fit_pts=nullptr;x->num_fit_pts=0;x->scenario=1;x->degree=e.degree;x->rational=!e.weights.empty();x->weighted=x->rational;x->num_knots=e.knots.size();x->num_ctrl_pts=e.points.size()/2;x->knots=(double*)calloc(x->num_knots,sizeof(double));x->ctrl_pts=(Dwg_SPLINE_control_point*)calloc(x->num_ctrl_pts,sizeof(Dwg_SPLINE_control_point));for(size_t i=0;i<e.knots.size();i++)x->knots[i]=e.knots[i];for(unsigned i=0;i<x->num_ctrl_pts;i++){x->ctrl_pts[i].parent=x;x->ctrl_pts[i].x=e.points[i*2];x->ctrl_pts[i].y=e.points[i*2+1];x->ctrl_pts[i].z=0;x->ctrl_pts[i].w=e.weights.empty()?1:e.weights[i];}parent=x->parent;}}
  else if(e.kind==7){auto*x=dwg_add_ELLIPSE(b,&p,e.a,e.b);if(x){x->sm_axis={e.a*cos(e.c*PI/180),e.a*sin(e.c*PI/180),0};x->start_angle=e.points[0];x->end_angle=e.points[1];parent=x->parent;}}
  else if(e.kind==8){const Dwg_Object* dummy=nullptr;auto*x=dwg_add_HATCH(b,1,"ANSI31",false,0,&dummy);if(x){
   free(x->paths);x->num_paths=1;x->paths=(Dwg_HATCH_Path*)calloc(1,sizeof(Dwg_HATCH_Path));auto&loop=x->paths[0];loop.parent=x;loop.flag=3;loop.closed=1;loop.num_segs_or_paths=4;loop.polyline_paths=(Dwg_HATCH_PolylinePath*)calloc(4,sizeof(Dwg_HATCH_PolylinePath));
   double pts[8]={e.x,e.y,e.x+e.a,e.y,e.x+e.a,e.y+e.b,e.x,e.y+e.b};for(int i=0;i<4;i++){loop.polyline_paths[i].parent=&loop;loop.polyline_paths[i].point={pts[2*i],pts[2*i+1]};}
   x->extrusion={0,0,1};x->style=0;x->angle=(e.c-45)*PI/180;x->scale_spacing=e.width/3.175;x->num_deflines=1;x->deflines=(Dwg_HATCH_DefLine*)calloc(1,sizeof(Dwg_HATCH_DefLine));x->deflines[0].parent=x;x->deflines[0].angle=e.c*PI/180;x->deflines[0].pt0={0,0};x->deflines[0].offset={-sin(e.c*PI/180)*e.width,cos(e.c*PI/180)*e.width};parent=x->parent;
  }}
  else if(e.kind==9){std::vector<dwg_point_3d> vertices;for(size_t i=0;i+1<e.points.size();i+=2)vertices.push_back({e.points[i],e.points[i+1],0});auto*x=dwg_add_LEADER(b,vertices.size(),vertices.data(),nullptr,3);if(x){x->annot_type=3;x->path_type=0;x->arrowhead_on=1;x->arrowhead_type=0;x->dimasz=e.a;x->hookline_on=0;x->extrusion={0,0,1};x->box_height=0;x->box_width=0;x->dimstyle=tableRef(dwg,"HM 1-1","DIMSTYLE");parent=x->parent;}}
  if(!parent)throw std::runtime_error("DWG entity allocation failed");parent->ltype_scale=e.ltscale;parent->layer=dwg_add_handleref(dwg,5,lh.at((e.kind==3||e.kind==4)?2:e.layer),nullptr);parent->color.index=e.color;parent->linewt=lineweightCode(e.lw);
  if(e.lt>=0&&e.lt<(int)th.size()){auto name=types[e.lt].name;parent->ltype_flags=name=="ByLayer"?0:name=="ByBlock"?1:name=="Continuous"?2:3;if(parent->ltype_flags==3)parent->ltype=dwg_add_handleref(dwg,5,th[e.lt],nullptr);}

 };
 for(const auto&e:d.e)addEntity(e,dwg_model_space_object(dwg)->tio.object->tio.BLOCK_HEADER);
 // Native dimensions own anonymous display blocks. Their primitives are not in model space.
 auto* ds=getDimstyle(dwg,"HM 1-1");ds->DIMLFAC=1;ds->DIMSCALE=d.ratio;ds->DIMTMOVE=2;ds->DIMTXSTY=tableRef(dwg,"HM-ASME","STYLE");ds->DIMDEC=1;
 dwg->header_vars.DIMSCALE=d.ratio;dwg->header_vars.DIMLFAC=1;dwg->header_vars.DIMSTYLE=tableRef(dwg,"HM 1-1","DIMSTYLE");
 // Keep the current dimension variables consistent with the active style.
 dwg->header_vars.DIMASZ=ds->DIMASZ;dwg->header_vars.DIMEXO=ds->DIMEXO;dwg->header_vars.DIMEXE=ds->DIMEXE;dwg->header_vars.DIMTXT=ds->DIMTXT;dwg->header_vars.DIMGAP=ds->DIMGAP;dwg->header_vars.DIMCEN=ds->DIMCEN;
 dwg->header_vars.DIMTAD=ds->DIMTAD;dwg->header_vars.DIMTIH=ds->DIMTIH;dwg->header_vars.DIMTOH=ds->DIMTOH;dwg->header_vars.DIMJUST=ds->DIMJUST;dwg->header_vars.DIMTMOVE=2;
 dwg->header_vars.DIMLUNIT=ds->DIMLUNIT;dwg->header_vars.DIMDEC=ds->DIMDEC;dwg->header_vars.DIMTDEC=ds->DIMTDEC;dwg->header_vars.DIMAUNIT=ds->DIMAUNIT;dwg->header_vars.DIMADEC=ds->DIMADEC;dwg->header_vars.DIMZIN=ds->DIMZIN;dwg->header_vars.DIMTZIN=ds->DIMTZIN;
 dwg->header_vars.DIMTXSTY=tableRef(dwg,"HM-ASME","STYLE");dwg->header_vars.TEXTSTYLE=tableRef(dwg,"HM-ASME","STYLE");
 auto dimStyleRef=tableRef(dwg,"HM 1-1","DIMSTYLE");
 dwg_add_class(dwg,"LARGE_RADIAL_DIMENSION","AcDbRadialDimensionLarge","ObjectDBX Classes",true);
 for(size_t i=0;i<d.dimensions.size();i++){
  const auto&q=d.dimensions[i];std::string name="*D"+std::to_string(i+1);
  auto* bh=dwg_add_BLOCK_HEADER(dwg,name.c_str());if(!bh)throw std::runtime_error("Cannot allocate native dimension block");
  bh->anonymous=1;bh->flag|=1;unsigned long handle=dwg->object[bh->parent->objid].handle.value;
  auto reacquire=[&](){for(unsigned j=0;j<dwg->num_objects;j++)if(dwg->object[j].handle.value==handle)return dwg->object[j].tio.object->tio.BLOCK_HEADER;throw std::runtime_error("Missing dimension block");};
  dwg_add_BLOCK(bh,name.c_str());for(const auto&e:q.graphics)addEntity(e,reacquire());dwg_add_ENDBLK(reacquire());
  auto*model=dwg_model_space_object(dwg)->tio.object->tio.BLOCK_HEADER;
  dwg_point_3d a={q.first.x,q.first.y,0},b={q.second.x,q.second.y,0},c={q.centre.x,q.centre.y,0},at={q.at.x,q.at.y,0};Dwg_DIMENSION_common*n=nullptr;
  if(q.type==0)n=(Dwg_DIMENSION_common*)dwg_add_DIMENSION_LINEAR(model,&a,&b,&at,q.rotation*PI/180);
  else if(q.type==1)n=(Dwg_DIMENSION_common*)dwg_add_DIMENSION_ALIGNED(model,&a,&b,&at);
  else if(q.jogged){dwg_point_3d jog={q.jogPoint.x,q.jogPoint.y,0},overrideCentre={q.overrideCentre.x,q.overrideCentre.y,0};n=(Dwg_DIMENSION_common*)dwg_add_LARGE_RADIAL_DIMENSION(model,&a,&b,&overrideCentre,&jog,PI/4);}
  else if(q.type==2)n=(Dwg_DIMENSION_common*)dwg_add_DIMENSION_RADIUS(model,&a,&b,magnitude(q.at-q.second));
  else if(q.type==3)n=(Dwg_DIMENSION_common*)dwg_add_DIMENSION_DIAMETER(model,&a,&b,magnitude(q.at-q.second));
  else n=(Dwg_DIMENSION_common*)dwg_add_DIMENSION_ANG3PT(model,&c,&a,&b,&at);
  if(!n)throw std::runtime_error("Cannot allocate native DIMENSION");
  n->flag=(unsigned char)(160+(q.type==0?0:q.type==1?1:q.type==2?4:q.type==3?3:5));n->flag1=2;
  n->block=dwg_add_handleref(dwg,5,handle,nullptr);n->dimstyle=dwg_add_handleref(dwg,5,dimStyleRef->absolute_ref,nullptr);n->act_measurement=q.type==4?q.measurement*PI/180:q.measurement;Point textCentre=cadDimensionTextCentre(q);n->text_midpt={textCentre.x,textCentre.y};for(auto&text:q.graphics)if(text.kind==3)n->text_rotation=text.rotation*PI/180;n->ins_scale={1,1,1};n->attachment=5;n->lspace_factor=1;n->lspace_style=1;
  if(q.type==1||q.type==4)n->def_pt={q.at.x,q.at.y,0};
  // A detail is deliberately drawn larger than the part. Mechanical can reset
  // its measurement-factor override on regeneration. Keep the native measurement
  // and DIMLFAC, and also store the actual part size as explicit dimension text.
  if(q.measurementScale!=1){std::string value=num(q.measurement*q.measurementScale);n->user_text=dwg_add_u8_input(dwg,cadUnicodeText(q.prefix+(q.type==2?"R":"")+value+q.suffix).c_str());}
  else if(!q.prefix.empty()||!q.suffix.empty())n->user_text=dwg_add_u8_input(dwg,cadUnicodeText(q.prefix+"<>"+q.suffix).c_str());
  dimensionOverrides(dwg,n->parent,q,d.ratio);
  int dimLayer=0;auto ls=refLayers(d.type);for(size_t k=0;k<ls.size();k++)if(ls[k].name=="6 尺寸线-管口号外圆（细实线）")dimLayer=k;
  n->parent->layer=dwg_add_handleref(dwg,5,lh.at(dimLayer),nullptr);n->parent->color.index=256;n->parent->linewt=29;
 }
 unsigned savedOpts=dwg->opts;dwg->opts&=~DWG_OPTS_IN;int err=0;
 if(asDWG)err=dwg_write_file(path.c_str(),dwg);
 else {Bit_Chain out={};out.version=R_2004;out.from_version=dwg->header.version;out.codepage=dwg->header.codepage;out.fh=fopen(path.c_str(),"wb");if(!out.fh)throw std::runtime_error("Cannot create DXF");err=dwg_write_dxf(&out,dwg);fclose(out.fh);if(!err)normalizeJoggedDXF(path);}
 dwg->opts=savedOpts;if(err)throw std::runtime_error("DWG write failed, code="+std::to_string(err));dwg_free(dwg);free(dwg);
 }catch(...){dwg_free(dwg);free(dwg);throw;}
}
inline void writeDWG(const Drawing&d,const std::string&path){writeCAD(d,path,true);}
inline void writeDXF(const Drawing&d,const std::string&path){writeCAD(d,path,false);}

}
