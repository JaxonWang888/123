# Saddle drawing generator V2

Native Windows x64 offline single executable using the supplied middle-web and side-web drawing templates. The application and corresponding code are GPL-3.0-or-later. Read dist/使用说明.md for drawing scope, file-format and font limitations.

V2 keeps the reference sheet composition and original layer/text/dimension-style definitions. Middle-web hole input means the count per row; each saddle has two rows. Fixed and sliding variants are drawn together.

## Build

Tested build host: Linux x86_64; Zig 0.13.0; CMake 4.4.4; GNU Make. Runtime target: Windows 10/11 x64.

The source bundle includes third_party/libredwg and its jsmn submodule. The build script performs no downloads. Install the build tools separately, then:

```sh
export ZIG=/absolute/path/to/zig
export CMAKE=/absolute/path/to/cmake
export JOBS=2
bash tools/build.sh
```

Outputs are written outside third_party. LibreDWG and the C++ runtime are statically linked; Windows system DLLs remain system dependencies. Embedded template geometry and drafting tables are in src/reference_data.hpp, reference_styles.hpp and reference_native.hpp. No template regeneration, Python interpreter, network, or external CAD file is needed to build or run the application.

LibreDWG base commit: f860b0fb76d5f8effb5a70769a3389cb1e0308c8.
Local patch: in bits.c, the high byte of two-byte codepage characters is shifted by 8, rather than 4. The exact two-line change is in tools/libredwg-codepage.patch. The builder also avoids a second UTF-8 conversion of API-created CP936 strings during encoding.
jsmn commit: 85695f3d5903b1cd5b4030efe50db3b4f5f3c928.

The DWG writer constructs a real R2000 document. DXF is R2018 and keeps the complete reference style tables. R2000 cannot store all later-version dimension-style attributes. The original exploded dimension entities are preserved as line/solid/text geometry, so drawing them does not depend on those later attributes. Original object handles, constraints and INSERT grouping are not retained; reference groups are expanded into entities.

## Checks

```sh
mkdir -p build
g++ -std=c++17 -O0 -Isrc tests/model_test.cpp -o build/model-test
build/model-test
```

Windows acceptance check, using an existing directory:

```powershell
New-Item -ItemType Directory -Force .\acceptance
& '.\dist\鞍座图纸生成器.exe' --self-test "$((Resolve-Path .\acceptance).Path)"
```

This exercises the UI and emits 16 DWG/DXF pairs. smoke.json reports the result. tests/verify_v2.py compares layer colors, line types, line weights, text styles, primary dimension settings, decoded DWG geometry and per-row hole counts. It uses tests/readback.cpp built against a local LibreDWG library, plus ezdxf and the original style snapshots in reference/. The readback checker passes the correct source codepage to the DXF writer and independently decodes original DWG text bytes using Python's GBK codec, avoiding limitations of rich-MTEXT upconversion in the library's DXF diagnostic output.

Optional template regeneration scripts are included. They require the two user-supplied reference DXFs in input/source0.dxf and input/source1.dxf and ezdxf; the generated headers already contain everything required for an ordinary build. The reference assets retain their original ownership.
