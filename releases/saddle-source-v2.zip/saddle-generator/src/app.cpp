// SPDX-License-Identifier: GPL-3.0-or-later
#define UNICODE
#define _UNICODE
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <vector>
#include <map>
#include <functional>
#include <limits>
#include "dwg_export.hpp"
using namespace saddle;
HINSTANCE inst;HWND mainWnd,panel,canvas,statusWnd,typeBox,paperBox,scaleBox,slideBox,reinforceBox;HFONT uiFont,titleFont;double dpi=1;
Params params;Drawing drawing;bool valid=false,initializing=true,fitMode=true,dragging=false;double zoom=1,panX=0,panY=0;POINT dragStart;int scrollPos=0,contentH=0;
std::wstring errorText; bool smokeMode=false; std::wstring smokeDir; int resultCode=0;
struct Field {const wchar_t*label;const char*key;double Params::*member;HWND edit=nullptr;};
std::vector<Field> fields={
 {L"容器外径 D", "diameter",&Params::diameter},{L"中心高度 H（底面起）","height",&Params::height},
 {L"底板长度 L（横向）","length",&Params::length},{L"底板宽度 B（轴向）","depth",&Params::depth},
 {L"鞍座包角 θ（度）","angle",&Params::angle},{L"鞍座本体轴向宽度 b","supportWidth",&Params::supportWidth},
 {L"底板厚度","base",&Params::base},{L"腹板厚度","web",&Params::web},{L"筋板厚度","rib",&Params::rib},
 {L"垫板厚度","pad",&Params::pad},{L"垫板轴向宽度","padWidth",&Params::padWidth},
 {L"地脚孔直径","hole",&Params::hole},{L"孔中心距底板端边","edgeX",&Params::edgeX},
 {L"孔中心距底板侧边","edgeY",&Params::edgeY},{L"长圆孔总长（轴向）","slot",&Params::slot},
 {L"焊脚高度（几何间隙）","weld",&Params::weld}
};
HWND ribEdit,holeEdit;
std::vector<std::pair<HWND,int>> panelChildren;
int U(double x){return int(x*dpi+.5);}
std::wstring wide(const std::string&s){int n=MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,nullptr,0);std::wstring w(n,0);MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,w.data(),n);if(n)w.pop_back();return w;}
#include "errors.hpp"
void font(HWND h){SendMessageW(h,WM_SETFONT,(WPARAM)uiFont,TRUE);}
HWND control(HWND parent,const wchar_t*cls,const wchar_t*txt,DWORD style,int x,int y,int w,int h,int id){HWND c=CreateWindowExW(cls==std::wstring(L"EDIT")?WS_EX_CLIENTEDGE:0,cls,txt,WS_CHILD|WS_VISIBLE|style,U(x),U(y),U(w),U(h),parent,(HMENU)(INT_PTR)id,inst,nullptr);font(c);if(parent==panel)panelChildren.push_back({c,U(y)});return c;}
std::wstring text(HWND h){int n=GetWindowTextLengthW(h);std::wstring s(n+1,0);GetWindowTextW(h,s.data(),n+1);s.resize(n);return s;}
bool parseNumber(HWND h,double&v){auto s=text(h);if(s.empty())return false;wchar_t*end=nullptr;v=wcstod(s.c_str(),&end);while(end&&iswspace(*end))end++;return end&&*end==0&&std::isfinite(v);}
bool parseInt(HWND h,int&v){double d;if(!parseNumber(h,d)||d!=floor(d)||d<-100000||d>100000)return false;v=(int)d;return true;}
void updateStatus(){std::wstring s;if(!valid)s=L"参数未通过检查："+errorText;else{s=L"模型 1:1 · mm  |  推荐 1:"+wide(num(drawing.recommended))+L"  |  当前 1:"+wide(num(drawing.ratio))+L"  |  "+std::to_wstring(drawing.e.size())+L" 个图元  |  每个鞍座实际孔数："+std::to_wstring(totalHoles(params));if(drawing.ratio<drawing.requiredRatio)s+=L"  |  当前纸张比例可能放不下图形，请调大分母";}SetWindowTextW(statusWnd,s.c_str());EnableWindow(GetDlgItem(mainWnd,501),valid);EnableWindow(GetDlgItem(mainWnd,502),valid);}
void fit(){RECT r;GetClientRect(canvas,&r);if(drawing.e.empty())return;double w=drawing.maxX-drawing.minX,h=drawing.maxY-drawing.minY;zoom=std::max(.0001,std::min((r.right-U(64))/w,(r.bottom-U(64))/h));panX=r.right/2-(drawing.minX+drawing.maxX)/2*zoom;panY=r.bottom/2+(drawing.minY+drawing.maxY)/2*zoom;}
void rebuild(){if(initializing)return;Params p=params;valid=false;
 for(auto&f:fields)if(!parseNumber(f.edit,p.*(f.member))){errorText=L"请填写完整的数字，尺寸单位为 mm。";updateStatus();InvalidateRect(canvas,nullptr,FALSE);return;}
 if(!parseInt(ribEdit,p.ribs)||!parseInt(holeEdit,p.holes)){errorText=L"筋板数量和地脚孔数量必须为整数。";updateStatus();InvalidateRect(canvas,nullptr,FALSE);return;}
 p.type=(int)SendMessageW(typeBox,CB_GETCURSEL,0,0);SetWindowTextW(GetDlgItem(panel,1111),p.type?L"地脚孔数量（单排总数）":L"地脚孔数量（每排）");p.paper=(int)SendMessageW(paperBox,CB_GETCURSEL,0,0);p.sliding=SendMessageW(slideBox,BM_GETCHECK,0,0)==BST_CHECKED;p.reinforced=SendMessageW(reinforceBox,BM_GETCHECK,0,0)==BST_CHECKED;
 auto st=text(scaleBox);if(st==L"自动推荐")p.scale=0;else {wchar_t*e=nullptr;p.scale=wcstod(st.c_str(),&e);if(!e||*e||!std::isfinite(p.scale)||p.scale<=0){errorText=L"比例请输入正分母，例如 10 表示 1:10。";updateStatus();InvalidateRect(canvas,nullptr,FALSE);return;}}
 auto errors=validate(p);if(!errors.empty()){errorText=localError(errors[0]);updateStatus();InvalidateRect(canvas,nullptr,FALSE);return;}
 try{drawing=generate(p);params=p;valid=true;errorText.clear();if(fitMode)fit();}catch(const std::exception&e){errorText=localError(e.what());}
 updateStatus();InvalidateRect(canvas,nullptr,FALSE);
}
void fillInputs(){initializing=true;for(auto&f:fields)SetWindowTextW(f.edit,wide(num(params.*(f.member))).c_str());SetWindowTextW(ribEdit,std::to_wstring(params.ribs).c_str());SetWindowTextW(holeEdit,std::to_wstring(params.holes).c_str());SendMessageW(typeBox,CB_SETCURSEL,params.type,0);SendMessageW(paperBox,CB_SETCURSEL,params.paper,0);SetWindowTextW(scaleBox,params.scale?wide(num(params.scale)).c_str():L"自动推荐");SendMessageW(slideBox,BM_SETCHECK,params.sliding?BST_CHECKED:BST_UNCHECKED,0);SendMessageW(reinforceBox,BM_SETCHECK,params.reinforced?BST_CHECKED:BST_UNCHECKED,0);SendMessageW(slideBox,BM_SETCHECK,BST_CHECKED,0);EnableWindow(slideBox,FALSE);initializing=false;rebuild();}
POINT screenPoint(double x,double y){return {(LONG)std::clamp(panX+x*zoom,-1000000.,1000000.),(LONG)std::clamp(panY-y*zoom,-1000000.,1000000.)};}
#include "render.inc"
std::wstring choosePath(bool save,const wchar_t*filter,const wchar_t*ext,const wchar_t*initial){wchar_t p[32768];wcscpy(p,initial);OPENFILENAMEW o={sizeof(o)};o.hwndOwner=mainWnd;o.lpstrFilter=filter;o.lpstrFile=p;o.nMaxFile=32768;o.lpstrDefExt=ext;o.Flags=OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_PATHMUSTEXIST|(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST);if(save?GetSaveFileNameW(&o):GetOpenFileNameW(&o))return p;return L"";}
void writeBytes(const std::wstring&p,const std::string&s){HANDLE h=CreateFileW(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot create selected file");DWORD n=0;BOOL ok=WriteFile(h,s.data(),(DWORD)s.size(),&n,nullptr);CloseHandle(h);if(!ok||n!=s.size())throw std::runtime_error("File write failed");}
std::string readBytes(const std::wstring&p){HANDLE h=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);if(h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot read file");DWORD n=GetFileSize(h,nullptr);if(n>1024*1024){CloseHandle(h);throw std::runtime_error("Parameter file too large");}std::string s(n,0);DWORD got;BOOL ok=ReadFile(h,s.data(),n,&got,nullptr);CloseHandle(h);if(!ok||got!=n)throw std::runtime_error("File read failed");return s;}
struct TempDir {std::wstring dir;std::string narrow;TempDir(){wchar_t root[MAX_PATH],name[MAX_PATH],shortName[MAX_PATH];if(!GetTempPathW(MAX_PATH,root)||!GetTempFileNameW(root,L"sad",0,name))throw std::runtime_error("Cannot create temporary directory");DeleteFileW(name);if(!CreateDirectoryW(name,nullptr))throw std::runtime_error("Cannot create temporary directory");dir=name;if(!GetShortPathNameW(name,shortName,MAX_PATH))wcscpy(shortName,name);BOOL used=FALSE;char p[MAX_PATH*4];if(!WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,shortName,-1,p,sizeof(p),nullptr,&used)||used){RemoveDirectoryW(dir.c_str());throw std::runtime_error("Temporary path cannot be represented in system codepage. Set TEMP to an ASCII folder.");}narrow=p;}
 ~TempDir(){DeleteFileW((dir+L"\\drawing.dwg").c_str());DeleteFileW((dir+L"\\drawing.dxf").c_str());RemoveDirectoryW(dir.c_str());}};
void exportFile(bool dwg){rebuild();if(!valid)return;auto path=choosePath(true,dwg?L"DWG 图纸 (*.dwg)\0*.dwg\0\0":L"DXF 图纸 (*.dxf)\0*.dxf\0\0",dwg?L"dwg":L"dxf",dwg?L"鞍座图纸.dwg":L"鞍座图纸.dxf");if(path.empty())return;
 SetCursor(LoadCursor(nullptr,IDC_WAIT));try{TempDir temp;std::string p=temp.narrow+(dwg?"\\drawing.dwg":"\\drawing.dxf");if(dwg)writeDWG(drawing,p);else writeDXF(drawing,p);
  if(dwg){Dwg_Data check={};int err=dwg_read_file(p.c_str(),&check);unsigned n=modelEntityCount(&check);dwg_free(&check);if(err>=DWG_ERR_CRITICAL||n!=drawing.e.size())throw std::runtime_error("DWG read-back validation failed");}
  std::wstring source=temp.dir+(dwg?L"\\drawing.dwg":L"\\drawing.dxf");if(!CopyFileW(source.c_str(),path.c_str(),FALSE))throw std::runtime_error("Cannot save to selected path");SetCursor(LoadCursor(nullptr,IDC_ARROW));MessageBoxW(mainWnd,(L"图纸已保存：\n"+path+L"\n\n模型单位：毫米，实际几何尺寸 1:1。\nDWG 为 AutoCAD 2000 兼容格式。图纸为参考图模板版 V2。 ").c_str(),L"导出完成",MB_OK|MB_ICONINFORMATION);
 }catch(const std::exception&e){SetCursor(LoadCursor(nullptr,IDC_ARROW));MessageBoxW(mainWnd,wide(e.what()).c_str(),L"导出失败",MB_OK|MB_ICONERROR);}}
void saveParams(){rebuild();if(!valid)return;auto path=choosePath(true,L"鞍座参数 (*.saddle)\0*.saddle\0\0",L"saddle",L"鞍座参数.saddle");if(path.empty())return;std::ostringstream o;o<<std::setprecision(17)<<"SADDLE_PARAMS_V2\n";for(auto&f:fields)o<<f.key<<"="<<params.*(f.member)<<"\n";o<<"ribs="<<params.ribs<<"\nholes="<<params.holes<<"\ntype="<<params.type<<"\npaper="<<params.paper<<"\nscale="<<params.scale<<"\nsliding="<<params.sliding<<"\nreinforced="<<params.reinforced<<"\n";try{writeBytes(path,o.str());}catch(const std::exception&e){MessageBoxW(mainWnd,wide(e.what()).c_str(),L"保存失败",MB_OK);}}
void loadParams(){auto path=choosePath(false,L"鞍座参数 (*.saddle)\0*.saddle\0\0",L"saddle",L"");if(path.empty())return;try{std::istringstream in(readBytes(path));std::string line;std::getline(in,line);bool legacy=line=="SADDLE_PARAMS_V1";if(!legacy&&line!="SADDLE_PARAMS_V2")throw std::runtime_error("Unsupported parameter file");Params p;std::map<std::string,double> vals;while(std::getline(in,line)){auto i=line.find('=');if(i==std::string::npos)continue;std::string value=line.substr(i+1);size_t n=0;double x=std::stod(value,&n);if(n!=value.size()||!std::isfinite(x))throw std::runtime_error("Invalid parameter value");if(!vals.emplace(line.substr(0,i),x).second)throw std::runtime_error("Duplicate parameter key");}
 for(auto&f:fields){if(!vals.count(f.key))throw std::runtime_error("Missing parameter");p.*(f.member)=vals[f.key];}auto integer=[&](const char*k){double x=vals.at(k);if(x!=floor(x)||x<-100000||x>100000)throw std::runtime_error("Invalid integer parameter");return (int)x;};p.ribs=integer("ribs");p.holes=integer("holes");p.type=integer("type");if(legacy&&p.type==0){if(p.holes%2)throw std::runtime_error("Legacy total hole count is odd");p.holes/=2;}p.paper=integer("paper");p.scale=vals.at("scale");int s=integer("sliding"),r=integer("reinforced");if((s!=0&&s!=1)||(r!=0&&r!=1))throw std::runtime_error("Invalid boolean");p.sliding=s;p.reinforced=r;auto v=validate(p);if(!v.empty())throw std::runtime_error(v[0]);params=p;fitMode=true;fillInputs();}catch(const std::exception&e){MessageBoxW(mainWnd,wide(e.what()).c_str(),L"参数文件无效",MB_OK|MB_ICONERROR);}}
void scrollPanel(int pos){RECT r;GetClientRect(panel,&r);scrollPos=std::clamp(pos,0,std::max(0,contentH-(int)r.bottom));for(auto&c:panelChildren){RECT cr;GetWindowRect(c.first,&cr);POINT pt={cr.left,cr.top};ScreenToClient(panel,&pt);SetWindowPos(c.first,nullptr,pt.x,c.second-scrollPos,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);}SCROLLINFO s={sizeof(s),SIF_RANGE|SIF_PAGE|SIF_POS,0,contentH,(UINT)r.bottom,scrollPos,0};SetScrollInfo(panel,SB_VERT,&s,TRUE);}
LRESULT CALLBACK PanelProc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_CTLCOLORSTATIC:SetBkMode((HDC)w,TRANSPARENT);SetTextColor((HDC)w,RGB(30,41,59));return (LRESULT)GetStockObject(WHITE_BRUSH);case WM_COMMAND:SendMessage(mainWnd,m,w,l);return 0;case WM_VSCROLL:{int p=scrollPos;SCROLLINFO s={sizeof(s),SIF_TRACKPOS};GetScrollInfo(h,SB_VERT,&s);switch(LOWORD(w)){case SB_LINEUP:p-=U(28);break;case SB_LINEDOWN:p+=U(28);break;case SB_PAGEUP:p-=U(300);break;case SB_PAGEDOWN:p+=U(300);break;case SB_THUMBTRACK:p=s.nTrackPos;break;}scrollPanel(p);return 0;}case WM_MOUSEWHEEL:scrollPanel(scrollPos-GET_WHEEL_DELTA_WPARAM(w)/WHEEL_DELTA*U(70));return 0;case WM_SIZE:scrollPanel(scrollPos);return 0;}return DefWindowProcW(h,m,w,l);}
LRESULT CALLBACK CanvasProc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_ERASEBKGND:return 1;case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);HDC mem=CreateCompatibleDC(dc);HBITMAP b=CreateCompatibleBitmap(dc,std::max(1L,r.right),std::max(1L,r.bottom));auto old=SelectObject(mem,b);render(mem,r);BitBlt(dc,0,0,r.right,r.bottom,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(b);DeleteDC(mem);EndPaint(h,&ps);return 0;}case WM_SIZE:if(fitMode)fit();InvalidateRect(h,nullptr,FALSE);return 0;case WM_MOUSEWHEEL:{POINT p={GET_X_LPARAM(l),GET_Y_LPARAM(l)};ScreenToClient(h,&p);double z=std::clamp(zoom*pow(1.2,GET_WHEEL_DELTA_WPARAM(w)/120.),.0002,100.);panX=p.x-(p.x-panX)*z/zoom;panY=p.y-(p.y-panY)*z/zoom;zoom=z;fitMode=false;InvalidateRect(h,nullptr,FALSE);return 0;}case WM_LBUTTONDOWN:dragging=true;dragStart={GET_X_LPARAM(l),GET_Y_LPARAM(l)};SetCapture(h);return 0;case WM_MOUSEMOVE:if(dragging){POINT p={GET_X_LPARAM(l),GET_Y_LPARAM(l)};panX+=p.x-dragStart.x;panY+=p.y-dragStart.y;dragStart=p;fitMode=false;InvalidateRect(h,nullptr,FALSE);}return 0;case WM_LBUTTONUP:dragging=false;ReleaseCapture();return 0;case WM_CAPTURECHANGED:dragging=false;return 0;case WM_LBUTTONDBLCLK:fitMode=true;fit();InvalidateRect(h,nullptr,FALSE);return 0;}return DefWindowProcW(h,m,w,l);}
void layoutMain(){RECT r;GetClientRect(mainWnd,&r);int left=U(330),top=U(76),bottom=U(42);MoveWindow(panel,0,top,left,r.bottom-top-bottom,TRUE);MoveWindow(canvas,left+U(8),top,r.right-left-U(18),r.bottom-top-bottom-U(8),TRUE);MoveWindow(statusWnd,U(12),r.bottom-U(31),r.right-U(24),U(28),TRUE);}
#include "smoke.inc"
LRESULT CALLBACK MainProc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_CREATE:{mainWnd=h;
 control(h,L"STATIC",L"鞍座图纸生成器",SS_LEFT,18,12,300,30,1);SendMessageW(GetDlgItem(h,1),WM_SETFONT,(WPARAM)titleFont,TRUE);
 control(h,L"STATIC",L"离线独立版  /  参考图模板版 V2  /  默认值仅供演示",SS_LEFT,18,46,460,22,2);
 control(h,L"BUTTON",L"导出 DWG",BS_PUSHBUTTON,490,17,108,34,501);control(h,L"BUTTON",L"导出 DXF",BS_PUSHBUTTON,608,17,108,34,502);control(h,L"BUTTON",L"适应窗口",BS_PUSHBUTTON,726,17,98,34,503);control(h,L"BUTTON",L"保存参数",BS_PUSHBUTTON,834,17,98,34,504);control(h,L"BUTTON",L"载入参数",BS_PUSHBUTTON,942,17,98,34,505);control(h,L"BUTTON",L"说明",BS_PUSHBUTTON,1050,17,70,34,506);
 panel=CreateWindowExW(0,L"SaddlePanel",L"",WS_CHILD|WS_VISIBLE|WS_VSCROLL,0,0,0,0,h,nullptr,inst,nullptr);
 canvas=CreateWindowExW(0,L"SaddleCanvas",L"",WS_CHILD|WS_VISIBLE,0,0,0,0,h,nullptr,inst,nullptr);
 statusWnd=control(h,L"STATIC",L"",SS_LEFT,12,850,1000,28,10);
 int y=8;control(panel,L"STATIC",L"结构与孔型",SS_LEFT,16,y,280,24,11);y+=30;
 typeBox=control(panel,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,16,y,284,120,100);SendMessageW(typeBox,CB_ADDSTRING,0,(LPARAM)L"腹板在中间");SendMessageW(typeBox,CB_ADDSTRING,0,(LPARAM)L"腹板在侧面（单侧）");y+=34;
 slideBox=control(panel,L"BUTTON",L"固定＋滑动同图（按参考图）",BS_AUTOCHECKBOX|WS_TABSTOP,16,y,285,24,101);y+=28;
 reinforceBox=control(panel,L"BUTTON",L"垫板起加强作用（包角按原图规则）",BS_AUTOCHECKBOX|WS_TABSTOP,16,y,292,24,102);y+=34;
 auto row=[&](const wchar_t*label,const wchar_t*value,int id){control(panel,L"STATIC",label,SS_LEFT,16,y+4,175,22,id+1000);HWND e=control(panel,L"EDIT",value,ES_AUTOHSCROLL|WS_TABSTOP,199,y,100,25,id);y+=31;return e;};
 ribEdit=row(L"筋板数量（横向总片数）",L"6",110);holeEdit=row(L"地脚孔数量（每排）",L"3",111);y+=8;control(panel,L"STATIC",L"尺寸参数  /  单位 mm",SS_LEFT,16,y,280,22,12);y+=29;
 for(int i=0;i<(int)fields.size();i++)fields[i].edit=row(fields[i].label,L"",200+i);
 y+=10;control(panel,L"STATIC",L"出图设置",SS_LEFT,16,y,280,22,13);y+=29;control(panel,L"STATIC",L"纸张（横向）",SS_LEFT,16,y+4,175,22,14);
 paperBox=control(panel,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_TABSTOP,199,y,100,150,120);for(auto s:{L"A0",L"A1",L"A2",L"A3",L"A4"})SendMessageW(paperBox,CB_ADDSTRING,0,(LPARAM)s);y+=34;
 control(panel,L"STATIC",L"图纸比例 1 :",SS_LEFT,16,y+4,175,22,15);scaleBox=control(panel,L"COMBOBOX",L"",CBS_DROPDOWN|WS_TABSTOP,199,y,100,180,121);for(auto s:{L"自动推荐",L"1",L"2",L"2.5",L"4",L"5",L"10",L"15",L"20",L"25",L"40",L"50",L"100"})SendMessageW(scaleBox,CB_ADDSTRING,0,(LPARAM)s);y+=44;
 control(panel,L"STATIC",L"模型毫米尺寸保持 1:1。比例改变图框排版，屏幕缩放只影响查看。原图占位尺寸须按项目设计填写。",SS_LEFT,16,y,282,80,16);y+=94;control(panel,L"BUTTON",L"恢复演示参数",BS_PUSHBUTTON|WS_TABSTOP,16,y,284,32,507);y+=50;contentH=U(y);layoutMain();fillInputs();return 0;}
 case WM_CTLCOLORSTATIC:SetBkMode((HDC)w,TRANSPARENT);SetTextColor((HDC)w,RGB(30,41,59));return (LRESULT)GetStockObject(WHITE_BRUSH);
 case WM_SIZE:layoutMain();return 0;
 case WM_GETMINMAXINFO:{auto*p=(MINMAXINFO*)l;p->ptMinTrackSize={U(1160),U(720)};return 0;}
 case WM_TIMER:if(w==99){KillTimer(h,99);try{runSmoke(smokeDir);}catch(const std::exception&e){resultCode=2;writeBytes(smokeDir+L"\\smoke-failed.txt",e.what());}DestroyWindow(h);return 0;}if(w==1){KillTimer(h,1);rebuild();}return 0;
 case WM_COMMAND:{int id=LOWORD(w),code=HIWORD(w);if(initializing)return 0;if(id>=500){switch(id){case 501:exportFile(true);break;case 502:exportFile(false);break;case 503:fitMode=true;fit();InvalidateRect(canvas,nullptr,FALSE);break;case 504:saveParams();break;case 505:loadParams();break;case 506:MessageBoxW(h,L"根据两张鞍座示意 DWG 制作。\n\n左侧滚动填写参数；右侧滚轮缩放、左键拖动、双击适应。筋板数量为横向总片数，中置腹板孔数为每排数量，总数为输入值×2；侧置腹板为单排总数。腹板侧置为单侧偏置。\n\n预览与导出共用毫米几何，模型 1:1；纸张比例仅控制图框。DWG 导出兼容 AutoCAD 2000，无需 AutoCAD 或网络。可保存/载入参数文件。\n\n按参考图保留固定/滑动图、剖视、详图、明细栏及技术要求。中置腹板输入孔数为每排数量，实际数量为输入值×2。文字/图层/标注样式沿用原图，独立预览使用系统字体显示。未给定的项目专用详图尺寸仍保留原占位符；不执行强度计算。\n\nDWG 引擎：GNU LibreDWG，GPLv3+；本程序同许可证。",L"使用说明与范围",MB_OK|MB_ICONINFORMATION);break;case 507:params=Params();fitMode=true;fillInputs();break;}return 0;}
 if(code==EN_CHANGE||code==CBN_SELCHANGE||code==CBN_EDITCHANGE||code==BN_CLICKED){SetTimer(h,1,160,nullptr);if(code==CBN_SELCHANGE&&id==121)PostMessageW(h,WM_TIMER,1,0);}return 0;}
 case WM_DESTROY:PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);}
int WINAPI wWinMain(HINSTANCE hi,HINSTANCE,LPWSTR,int show){inst=hi;int argc=0;auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(argc==3&&std::wstring(argv[1])==L"--self-test"){smokeMode=true;smokeDir=argv[2];}LocalFree(argv);SetProcessDPIAware();HDC dc=GetDC(nullptr);dpi=GetDeviceCaps(dc,LOGPIXELSX)/96.;ReleaseDC(nullptr,dc);uiFont=CreateFontW(-U(13),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Microsoft YaHei UI");titleFont=CreateFontW(-U(23),0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Microsoft YaHei UI");
 WNDCLASSW wc={};wc.hInstance=hi;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.lpfnWndProc=MainProc;wc.lpszClassName=L"SaddleMain";RegisterClassW(&wc);wc.lpfnWndProc=PanelProc;wc.lpszClassName=L"SaddlePanel";RegisterClassW(&wc);wc.style=CS_DBLCLKS;wc.lpfnWndProc=CanvasProc;wc.lpszClassName=L"SaddleCanvas";RegisterClassW(&wc);
 HWND h=CreateWindowExW(0,L"SaddleMain",L"鞍座图纸生成器 · 离线独立版",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,U(1440),U(950),nullptr,nullptr,hi,nullptr);if(!h)return 1;ShowWindow(h,show);UpdateWindow(h);if(smokeMode)SetTimer(h,99,800,nullptr);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){if(!IsDialogMessageW(h,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}DeleteObject(uiFont);DeleteObject(titleFont);return resultCode;}
