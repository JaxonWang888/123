// SPDX-License-Identifier: GPL-3.0-or-later
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int cases=0;for(int type:{0,1})for(int holes:{2,3,5})for(int ribs:{2,3,6,10}){
 Params p;p.type=type;p.holes=holes;p.ribs=ribs;assert(validate(p).empty());auto d=generate(p);int fixed=0,slots=0,ribLines=0;const Entity*base=nullptr;const Entity*plan=nullptr;bool radius=false;
 for(auto&e:d.e){if(e.role==5&&e.kind==1)fixed++;if(e.role==6&&e.kind==2)slots++;if(e.role==2)ribLines++;if(e.role==1&&!base)base=&e;if(e.role==3&&!plan)plan=&e;if(e.role==1&&e.kind==2&&std::abs(e.a-p.diameter/2)<1e-8)radius=true;}
 assert(fixed==totalHoles(p));assert(slots==2*totalHoles(p));assert(ribLines==3*ribs);assert(base&&std::abs(base->a-base->x-p.length)<1e-8);assert(plan&&std::abs(plan->a-plan->x-p.depth)<1e-8);assert(radius);
 auto expected=refLayers(type);assert(expected.size()==41);assert(refStyles(type).size()==14);
 p.scale=25;auto manual=generate(p);for(auto&e:manual.e)if(e.role==1&&e.kind==2)assert(std::abs(e.a-p.diameter/2)<1e-8||std::abs(e.a-p.diameter/2-p.pad)<1e-8);
 cases++;
 }
 for(double angle:{60.,90.,120.,150.}){Params p;p.angle=angle;auto d=generate(p);for(auto&e:d.e){assert(std::isfinite(e.x)&&std::isfinite(e.y));if(e.role==2&&e.kind==0&&e.y!=e.b)assert(std::abs(e.b)<1e8);}}
 Params p;p.type=0;p.holes=3;assert(totalHoles(p)==6);p.holes=5;assert(validate(p).empty()&&totalHoles(p)==10);p.holes=1;assert(!validate(p).empty());p=Params();p.height=100;assert(!validate(p).empty());p=Params();p.slot=p.hole-1;assert(!validate(p).empty());std::cout<<cases<<" reference model cases passed\n";
}
