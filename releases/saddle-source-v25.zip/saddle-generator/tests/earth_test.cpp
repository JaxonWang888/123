// SPDX-License-Identifier: GPL-3.0-or-later
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int cases=0;
 for(int type:{0,1})for(int count:{2,3,4,6})for(double scale:{2.,4.,1.5}){
  Params p;p.type=type;p.ribs=count;p.ribSpacings.assign(spacingCount(count),300);p.holes=2;p.holeDistances={500};p.earthScale=scale;
  assert(validateV3(p).empty());auto d=generate(p);double S=d.ratio;
  auto fixed=earthHostRib(p,0),sliding=earthHostRib(p,1);
  auto inner=innerRibPositions(p);if(inner.empty()){assert(fixed.station<0&&sliding.station>0);}else {assert(fixed.station==inner.front()&&sliding.station==inner.back());}
  int holeCount=0,thicknessCount=0,detailDims=0,datum=0;for(auto&e:d.e)if(e.role==81&&e.kind==1){holeCount++;assert(std::abs(e.y-(d.maxY*.52+100))<1e-7);assert(std::abs(e.a-6)<1e-7);}assert(holeCount==2);assert(std::count_if(d.e.begin(),d.e.end(),[](const Entity&e){return e.role==80;})==6);assert(std::count_if(d.e.begin(),d.e.end(),[](const Entity&e){return e.role==88;})==6);
  for(auto&q:d.dimensions){if(q.key=="earth-edge-gap"){assert(std::abs(q.measurement-(earthHostRib(p,thicknessCount).footThickness-p.earthThickness)/2)<1e-7);thicknessCount++;}if(q.key=="earth-height-100"){assert(q.measurement==100);assert(q.textAt.y>q.second.y);datum++;}if(q.key.rfind("earth-detail-",0)==0){detailDims++;double expected=q.key=="earth-detail-width"?50:q.key=="earth-detail-height"?70:q.key=="earth-detail-top"?17:q.key=="earth-detail-end"?23:q.key=="earth-detail-diameter"?12:10;assert(std::abs(q.measurement*q.measurementScale-expected)<1e-7);}}
  assert(thicknessCount==2&&datum==1&&detailDims==6);
  Point endpoint;for(auto&q:d.dimensions)if(q.key=="earth-detail-diameter")endpoint=q.at;
  assert(std::any_of(d.e.begin(),d.e.end(),[&](const Entity&e){return e.role==89&&e.kind==0&&magnitude(Point{e.x,e.y}-endpoint)<1e-7;}));
  for(int view=0;view<2;view++){double px=d.maxX*(view?.405:.19),sign=view?-1:1,attach=px+ribAxialCentre(p,view)+sign*ribAxialWidth(p)/2,station=(d.maxY*.245-8*S)+earthStation(earthHostRib(p,view),100);bool found=false;for(auto&e:d.e)if(e.role==82&&e.kind==0&&std::abs(e.x-px)<p.depth&&std::abs(e.y-(station-3))<1e-7&&std::abs(e.b-e.y)<1e-7){assert(std::abs(std::abs(e.a-e.x)-50)<1e-7);assert(std::abs(std::max(e.x,e.a)-(sign>0?attach+50:attach))<1e-7);found=true;}assert(found);}
  auto hasValue=[&](const char* text){return std::any_of(d.e.begin(),d.e.end(),[&](const Entity&e){return e.text==text;});};assert(hasValue("EARTH LUG DETAIL")&&hasValue("接地板详图")&&hasValue("Earth Lug"));cases++;
 }
 Params p;p.earthRadius=2;assert(validateV3(p).empty());p.earthTop=1;assert(!validateV3(p).empty());p=Params();p.earthWidth=10;assert(!validateV3(p).empty());p=Params();p.earthHeight=100;assert(!validateV3(p).empty());p=Params();p.earthScale=0;assert(!validateV3(p).empty());p=Params();p.earthThickness=NAN;assert(!validateV3(p).empty());p=Params();p.earthHole=20;p.earthEnd=8;p.earthTop=10;assert(!validateV3(p).empty());
 std::cout<<cases<<" earth-lug cases passed: both web types, selected ribs and outer fallback, mirrored projections, 100 mm hole height, independent detail scale, actual dimensions and invalid geometry\n";
}
