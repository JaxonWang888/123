// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <array>
#include <cmath>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <stdexcept>
namespace saddlecad {
struct NativeBomJob {double scale=1,x=0,y=0;std::vector<std::array<std::string,12>> rows;};
inline std::string writeBomJob(const NativeBomJob&job){std::ostringstream s;s<<"SADDLE_NATIVE_BOM_V28\n"<<std::setprecision(17)<<job.scale<<' '<<job.x<<' '<<job.y<<' '<<job.rows.size()<<'\n';for(auto&r:job.rows){for(auto&v:r)s<<std::quoted(v)<<' ';s<<'\n';}return s.str();}
inline NativeBomJob readBomJob(const std::string&data){std::istringstream s(data);std::string magic;std::getline(s,magic);if(magic!="SADDLE_NATIVE_BOM_V28")throw std::runtime_error("Invalid native BOM data version");NativeBomJob j;size_t n=0;if(!(s>>j.scale>>j.x>>j.y>>n)||!std::isfinite(j.scale)||!std::isfinite(j.x)||!std::isfinite(j.y)||j.scale<=0||n<6||n>100)throw std::runtime_error("Invalid native BOM placement or row count");j.rows.resize(n);for(auto&r:j.rows)for(auto&v:r)if(!(s>>std::quoted(v))||v.size()>4096)throw std::runtime_error("Invalid native BOM cell data");s>>std::ws;if(!s.eof())throw std::runtime_error("Unexpected native BOM data");return j;}
}
