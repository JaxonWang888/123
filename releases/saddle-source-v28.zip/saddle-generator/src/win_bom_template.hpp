// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "bom_template_embedded.hpp"
struct OriginalBomTemplate {
 std::wstring path;
 OriginalBomTemplate(){wchar_t root[MAX_PATH],name[MAX_PATH];if(!GetTempPathW(MAX_PATH,root)||!GetTempFileNameW(root,L"sbm",0,name))throw std::runtime_error("Cannot reserve BOM template temporary file");path=std::wstring(name)+L".dwg";DeleteFileW(name);HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_TEMPORARY,nullptr);if(h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot create original BOM template file");DWORD done=0;BOOL ok=WriteFile(h,saddleBomTemplate,sizeof(saddleBomTemplate),&done,nullptr);CloseHandle(h);if(!ok||done!=sizeof(saddleBomTemplate)){DeleteFileW(path.c_str());throw std::runtime_error("Cannot extract original BOM template");}}
 ~OriginalBomTemplate(){DeleteFileW(path.c_str());}
};
