# Independent checks of native balloon alignment and BOM values in exported DXF.
import pathlib,sys,math,json
import ezdxf
from ezdxf.lldxf.encoding import decode_dxf_unicode
root=pathlib.Path(sys.argv[1]);results=[]
for path in sorted(root.glob('case_*.dxf'))+[root/'notch-sample.dxf',root/'notch-sample.readback.dxf']:
 if not path.exists():continue
 doc=ezdxf.readfile(path);ms=doc.modelspace();S=doc.header['$DIMSCALE'];texts=list(ms.query('TEXT MTEXT'))
 plain=lambda e:decode_dxf_unicode(e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text)
 circles=[c for c in ms.query('CIRCLE') if math.isclose(c.dxf.radius,5*S,abs_tol=1e-6)]
 count=8 if path.stem.split('_')[-1].split('.')[0]=='6' or path.stem.startswith('notch') else 7
 assert len(circles)==count,(path,len(circles),count)
 nums=[]
 for c in circles:
  matches=[t for t in ms.query('TEXT') if t.dxf.get('halign',0)==1 and t.dxf.get('valign',0)==2 and math.isclose(t.dxf.height,5*S,abs_tol=1e-6) and (t.dxf.align_point-c.dxf.center).magnitude<1e-6]
  assert len(matches)==1,(path,c.dxf.center,matches)
  t=matches[0];assert t.dxf.style=='HM-ASME';nums.append(int(t.dxf.text))
 assert sorted(nums)==list(range(1,count+1))
 values=[plain(e) for e in texts]
 # The raw offline handoff contains no reconstructed BOM lines or text.
 # AutoCAD must copy the original AcDbTable, using the sidecar job.
 for v in ('93201-2406362','ASME-EB-04','FIXED BASE PLATE','OUTSIDE RIB PLATE'):
  assert v not in values,(path,'unexpected exploded BOM',v)
 jobpath=path.with_name(path.stem.replace('.readback','')+'.dxf.BOM数据')
 import shlex
 tokens=shlex.split(jobpath.read_text());assert tokens[0]=='SADDLE_NATIVE_BOM_V28'
 assert int(tokens[4])==count
 cells=[tokens[5+i*12:5+(i+1)*12] for i in range(count)]
 assert cells[-1][1:3]==['93201-2406362','ASME-EB-04']
 assert cells[-1][5:10]==['SA-240 316/316L','ZD','0.16','0.32','通用图 General']
 assert [int(row[0]) for row in cells]==list(range(1,count+1))
 for row in cells[:-1]:assert row[1]==row[2]==row[5]=='***' and row[7]==row[8]==''
 results.append({'file':path.name,'items':count,'diameter_mm':10,'digit_height_mm':5,'alignment':'middle-center'})
assert len(results)==42,len(results)
(root/'verification-bom.json').write_text(json.dumps({'passed':True,'files':len(results),'checks':results},indent=2));print(len(results),'native balloon / original-template BOM handoff files passed')
