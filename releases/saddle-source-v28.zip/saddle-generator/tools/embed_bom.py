# Embed the supplied original DWG byte-for-byte; no conversion or reconstruction.
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
src=root/'reference/bom-template-original.dwg';data=src.read_bytes()
assert hashlib.sha256(data).hexdigest()=='bc7e01186f5635a17360dda3972adba1a8b1f830d8fb1e1a21fc8ad7c5035005'
out=root/'build/bom_template_embedded.hpp'
out.write_text('// User-supplied BOM template, embedded without conversion.\n#pragma once\ninline const unsigned char saddleBomTemplate[]={\n'+''.join(','.join(str(v) for v in data[i:i+32])+',\n' for i in range(0,len(data),32))+'};\n')
