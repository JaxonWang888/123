// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int cases=0;for(int type:{0,1})for(int n:{2,3,4,6,7,10,20}){
 Params p;p.type=type;p.ribs=n;p.ribSpacings.assign(spacingCount(n),n>7?70:200);p.holes=2;p.holeDistances={800};
 auto rows=bomItems(p);assert(rows.size()==6+(n-1)/2-(n==2?0:0)); // ceil((n-2)/2) inner shapes
 int inner=0;for(auto&r:rows)if(r.en.rfind("RIB PLATE",0)==0)inner+=r.quantity;assert(inner==(n-2)*(type?2:4));assert(rows[0].quantity==1&&rows[1].quantity==2&&rows[2].quantity==1&&rows[3].quantity==2);assert(rows[rows.size()-2].quantity==4);auto&earth=rows.back();assert(earth.quantity==2&&earth.unitMass=="0.16"&&earth.totalMass=="0.32"&&earth.code=="93201-2406362");for(size_t i=0;i+1<rows.size();i++)assert(rows[i].code=="***"&&rows[i].standard=="***"&&rows[i].material=="***"&&rows[i].unitMass.empty()&&rows[i].totalMass.empty());
 // Dense plates are checked as BOM groups; representative drawing layouts cover 2/4/6/7 stations.
 if(n<=7&&n!=3){auto d=generate(p);assert(d.bom.size()==rows.size()&&d.balloons.size()==rows.size());Drawing original=generateGeometry(p); // The selected automatic ratio can grow to make room.
 Params same=p;same.scale=d.ratio;original=generateGeometry(same);addBomTable(original,p);auto obs=bomObstacles(original);
 for(auto&b:d.balloons){if(b.number==4)assert(magnitude(b.centre-b.tip)<=p.depth/2+20*d.ratio+1e-6);if(b.number==(int)d.bom.size()){double right=.78*d.maxX+p.earthWidth*d.ratio/p.earthScale;assert(fabs(b.tip.x-right)<1e-6);assert(b.tip.y>.19*d.maxY+p.earthRadius*d.ratio/p.earthScale);assert(b.tip.y<.19*d.maxY+(p.earthHeight-p.earthRadius)*d.ratio/p.earthScale);for(size_t k=1;k<b.route.size();k++)for(auto&o:obs)if(o.text)assert(bomSegmentDistance(b.route[k-1],b.route[k],o.a,o.b)>.25*d.ratio);}
 for(auto&o:obs)assert(bomPointDistance(b.centre,o.a,o.b)>=5.8*d.ratio-1e-6);for(auto&o:d.balloons)if(o.number!=b.number)assert(magnitude(o.centre-b.centre)>10*d.ratio);int circles=0,texts=0;for(auto&e:d.e)if(e.role==100+b.number){if(e.kind==1){circles++;assert(fabs(e.a-5*d.ratio)<1e-8);}if(e.kind==3){texts++;assert(e.text==std::to_string(b.number)&&fabs(e.a-5*d.ratio)<1e-8);assert(e.points.size()==2&&e.points[0]==b.centre.x&&e.points[1]==b.centre.y);}}assert(circles==1&&texts==1);}}
 cases++;}
 for(int paper:{0,2,4}){Params p;p.paper=paper;auto d=generate(p);assert(d.balloons.size()==d.bom.size());cases++;}
 Params compact;compact.length=1400;compact.depth=400;compact.supportWidth=220;compact.padWidth=300;compact.holeRowSpacing=200;compact.holes=2;compact.holeDistances={500};compact.ribSpacings={250,250};auto nearby=generate(compact);for(auto&b:nearby.balloons)if(b.number==4)assert(magnitude(b.centre-b.tip)<30*nearby.ratio);cases++;
 std::cout<<cases<<" BOM cases passed: actual quantities, dynamic shape grouping, fixed earth data, empty masses, balloon dimensions/centering and clearances\n";
}
