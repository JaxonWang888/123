// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#define UNICODE
#define _UNICODE
#include "win_cad.hpp"
#include <shellapi.h>
#include <functional>
#include <cassert>
using namespace saddlecad;
struct Fake:IDispatch {
 bool rejectPutRef=false;ULONG refs=1;std::map<std::wstring,DISPID>names;std::map<DISPID,std::wstring>ids;
 std::function<Value(const std::wstring&,WORD,const std::vector<Value>&)> fn;
 explicit Fake(decltype(fn)callback):fn(std::move(callback)){}
 HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void**out)override{if(IsEqualIID(id,IID_IUnknown)||IsEqualIID(id,IID_IDispatch)){*out=this;AddRef();return S_OK;}*out=nullptr;return E_NOINTERFACE;}
 ULONG STDMETHODCALLTYPE AddRef()override{return ++refs;}ULONG STDMETHODCALLTYPE Release()override{auto n=--refs;if(!n)delete this;return n;}
 HRESULT STDMETHODCALLTYPE GetTypeInfoCount(UINT*n)override{*n=0;return S_OK;}HRESULT STDMETHODCALLTYPE GetTypeInfo(UINT,LCID,ITypeInfo**)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE GetIDsOfNames(REFIID,LPOLESTR*keys,UINT count,LCID,DISPID*out)override{for(UINT i=0;i<count;i++){std::wstring k=keys[i];if(!names.count(k)){DISPID id=(DISPID)names.size()+1;names[k]=id;ids[id]=k;}out[i]=names[k];}return S_OK;}
 HRESULT STDMETHODCALLTYPE Invoke(DISPID id,REFIID,LCID,WORD flags,DISPPARAMS*p,VARIANT*out,EXCEPINFO*error,UINT*)override{if(rejectPutRef&&flags==DISPATCH_PROPERTYPUTREF)return DISP_E_MEMBERNOTFOUND;try{std::vector<Value>args;for(UINT i=p->cArgs;i>0;i--){Value v;VariantCopy(&v.v,&p->rgvarg[i-1]);args.push_back(v);}Value result=fn(ids.at(id),flags,args);if(out)VariantCopy(out,&result.v);return S_OK;}catch(const std::exception&e){if(error)error->bstrDescription=SysAllocString(wideError(e.what()).c_str());return DISP_E_EXCEPTION;}}
};
struct EntityState {std::map<std::wstring,Value>properties;bool ignoreScale=false,failLinearRead=false;int updates=0;};
Object entity(EntityState&state,const wchar_t*kind){state.properties[L"ObjectName"]=Value(kind);state.properties[L"StyleName"]=Value(L"HM 1-1");state.properties[L"TextRotation"]=Value(1.5);state.properties[L"ScaleFactor"]=Value(7.0);state.properties[L"LinearScaleFactor"]=Value(.2);state.properties[L"TextOverride"]=Value(L"2×R27");return Object(new Fake([&state](auto&name,WORD flags,auto&args){
 if(flags&(DISPATCH_PROPERTYPUT|DISPATCH_PROPERTYPUTREF)){if(name==L"ScaleFactor"&&state.ignoreScale)return Value();state.properties[name]=args.at(0);if(name==L"StyleName"){state.properties[L"LinearScaleFactor"]=Value(1.0);state.properties[L"TextOverride"]=Value(L"");}return Value();}
 if(name==L"Update"){state.updates++;return Value();}if(name==L"LinearScaleFactor"&&state.failLinearRead)throw std::runtime_error("measurement factor read failed");return state.properties.at(name);
 }),false);}
Object block(std::vector<Object>entities,bool xref){return Object(new Fake([entities=std::move(entities),xref](auto&name,WORD,auto&args){if(name==L"Count")return Value((long)entities.size());if(name==L"IsXRef")return Value(xref);if(name==L"Item")return Value(entities.at((size_t)args[0].number()).p);throw std::runtime_error("unknown block member");}),false);}
struct Fixture {
 EntityState a,b,c,line,xref;int copies=0,regens=0;bool changeOnRegen=false,legacyPutOnly=false;double scale=0;bool added=false;Object style,styles,blocks,doc;
 Fixture(bool hasStyle=true,bool withDimensions=true){
  auto dim1=entity(a,L"AcDbRotatedDimension"),dim2=entity(b,L"AcDbRadialDimensionLarge"),dim3=entity(c,L"AcDbAlignedDimension"),lineObj=entity(line,L"AcDbLine"),external=entity(xref,L"AcDbRotatedDimension");
  style=Object(new Fake([this](auto&name,WORD,auto&){if(name==L"CopyFrom"){copies++;return Value();}throw std::runtime_error("unknown style member");}),false);
  styles=Object(new Fake([this,hasStyle](auto&name,WORD,auto&args){if(name==L"Item"){if(!hasStyle&&!added)throw std::runtime_error("style not found");assert(args.at(0).str()==L"HM-ASME 1-1");return Value(style.p);}if(name==L"Add"){added=true;return Value(style.p);}throw std::runtime_error("unknown styles member");}),false);
  std::vector<Object>items;if(withDimensions){items={block({lineObj,dim1},false),block({dim2},false),block({dim3},false),block({external},true)};}else items={block({lineObj},false)};
  blocks=Object(new Fake([items](auto&name,WORD,auto&args){if(name==L"Count")return Value((long)items.size());if(name==L"Item")return Value(items.at((size_t)args.at(0).number()).p);throw std::runtime_error("unknown blocks member");}),false);
  doc=Object(new Fake([this](auto&name,WORD flags,auto&args){if(name==L"DimStyles")return Value(styles.p);if(name==L"ActiveDimStyle"){if(flags&(DISPATCH_PROPERTYPUT|DISPATCH_PROPERTYPUTREF)){assert(flags==(legacyPutOnly?DISPATCH_PROPERTYPUT:DISPATCH_PROPERTYPUTREF));assert(args.at(0).v.pdispVal==style.p);return Value();}return Value(style.p);}if(name==L"Blocks")return Value(blocks.p);if(name==L"SetVariable"){assert(args.at(0).str()==L"DIMSCALE");scale=args.at(1).number();return Value();}if(name==L"GetVariable"){assert(args.at(0).str()==L"DIMSCALE");return Value(scale);}if(name==L"Regen"){assert(args.at(0).number()==1);regens++;if(changeOnRegen)a.properties[L"TextRotation"]=Value(2.0);return Value();}throw std::runtime_error("unknown document member");}),false);
 }
};
int clicks=0;int chosen=0;
LRESULT CALLBACK dialogProc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_COMMAND){clicks++;chosen=LOWORD(w);return 0;}return DefWindowProcW(h,m,w,l);}
void dialogCheck(DialogWatcher&watcher,const wchar_t*title,const wchar_t*body,std::vector<std::pair<int,const wchar_t*>>buttons,int expected){
 clicks=0;chosen=0;watcher.clicked.clear();HWND h=CreateWindowExW(0,L"SaddleMockCADDialog",title,WS_OVERLAPPEDWINDOW|WS_VISIBLE,50,50,500,260,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
 CreateWindowW(L"STATIC",body,WS_CHILD|WS_VISIBLE,10,10,470,90,h,nullptr,nullptr,nullptr);int y=100;for(auto b:buttons){CreateWindowW(L"BUTTON",b.second,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,10,y,450,24,h,(HMENU)(INT_PTR)b.first,nullptr,nullptr);y+=28;}
 watcher.check(h);pump(50);assert(clicks==(expected?1:0));if(expected)assert(chosen==expected);DestroyWindow(h);pump(10);
}
int wmain(int argc,wchar_t**argv){CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);int checks=0;
 for(double ratio:{2.5,15.0,25.0,40.0,1.3333333333333333}){Fixture f;auto r=normalizeDimensions(f.doc,ratio);assert(r.dimensions==3&&r.blocks==3&&f.regens==1&&f.scale==ratio&&f.copies==1);for(auto*e:{&f.a,&f.b,&f.c}){assert(e->properties.at(L"StyleName").str()==L"HM-ASME 1-1");assert(e->properties.at(L"TextRotation").number()==0&&e->properties.at(L"ScaleFactor").number()==ratio);assert(e->properties.at(L"LinearScaleFactor").number()==.2&&e->properties.at(L"TextOverride").str()==L"2×R27");assert(e->updates==1);}assert(f.line.updates==0&&f.xref.updates==0);checks+=6;}
 {Fixture f(false);normalizeDimensions(f.doc,15);assert(f.added&&f.copies==2);checks++;}
 {Fixture f;f.a.ignoreScale=true;bool failed=false;try{normalizeDimensions(f.doc,15);}catch(...){failed=true;}assert(failed&&f.regens==0);checks++;}
 {Fixture f(true,false);bool failed=false;try{normalizeDimensions(f.doc,15);}catch(...){failed=true;}assert(failed&&f.regens==0);checks++;}
 {Fixture f;f.changeOnRegen=true;bool failed=false;try{normalizeDimensions(f.doc,15);}catch(...){failed=true;}assert(failed&&f.regens==1);checks++;}
 assert(repairDeletedObjects(L"删除的对象：0")==0&&repairDeletedObjects(L"删除的对象：2")==2);checks++;
 {Fixture f;bool failed=false;try{normalizeDimensions(f.doc,15,4);}catch(...){failed=true;}assert(failed&&f.a.updates==0);checks++;}
 {Fixture f;f.legacyPutOnly=true;static_cast<Fake*>(f.doc.p)->rejectPutRef=true;auto result=normalizeDimensions(f.doc,15);assert(result.dimensions==3);checks++;}
 {Fixture f;f.a.failLinearRead=true;bool failed=false;try{normalizeDimensions(f.doc,15);}catch(...){failed=true;}assert(failed&&f.a.updates==0);checks++;}
 WNDCLASSW cls={};cls.lpfnWndProc=dialogProc;cls.hInstance=GetModuleHandleW(nullptr);cls.lpszClassName=L"SaddleMockCADDialog";RegisterClassW(&cls);
 DialogWatcher watcher(L"C:\\folder\\saddle.dwg");watcher.pid=GetCurrentProcessId();watcher.opening=true;
 dialogCheck(watcher,L"打开 - 外来 DWG 文件",L"此 DWG 文件由非 Autodesk 开发或许可的应用程序保存",{{100,L"继续打开 DWG 文件"},{101,L"取消打开文件"}},100);checks++;
 dialogCheck(watcher,L"打开图形 - 发现错误",L"打开图形文件时发现一个错误。是否要取消这次打开操作？",{{IDYES,L"是(Y)"},{IDNO,L"否(N)"}},IDNO);checks++;
 dialogCheck(watcher,L"打开图形 - 文件损坏",L"图形文件需要修复。C:\\folder\\saddle.dwg",{{90,L"始终修复图形文件"},{91,L"修复"},{IDCANCEL,L"取消"}},91);checks++;
 dialogCheck(watcher,L"打开图形 - 文件损坏",L"已修复图形文件。发现的错误40，修复的错误40，删除的对象0",{{IDCLOSE,L"关闭(C)"}},IDCLOSE);checks++;
 dialogCheck(watcher,L"打开图形 - 文件损坏",L"图形文件需要修复。C:\\folder\\other.dwg",{{91,L"修复"}},0);checks++;
 dialogCheck(watcher,L"删除所有图形",L"确定删除？",{{IDOK,L"确定"}},0);checks++;
 watcher.pid=GetCurrentProcessId()+9999;dialogCheck(watcher,L"打开 - 外来 DWG 文件",L"此 DWG 文件由非 Autodesk 保存",{{100,L"继续打开 DWG 文件"}},0);checks++;
 watcher.pid=GetCurrentProcessId();watcher.opening=false;dialogCheck(watcher,L"打开 - 外来 DWG 文件",L"此 DWG 文件由非 Autodesk 保存",{{100,L"继续打开 DWG 文件"}},0);checks++;
 assert(promptKind(L"Open Drawing - Damaged",L"Drawing file requires recovery")==Prompt::Repair);assert(matchesButton(Prompt::Foreign,L"Continue opening DWG file",100));checks++;
 std::wstring path=L"C:\\含空格 folder\\saddle drawing.dwg";auto cmd=quote(L"C:\\app.exe")+L" --cad-postprocess "+quote(path)+L" "+exactNumber(1.3333333333333333)+L" 400 50";int n=0;auto args=CommandLineToArgvW(cmd.c_str(),&n);assert(n==6&&args[2]==path&&std::stod(args[3])==1.3333333333333333);LocalFree(args);checks++;
 if(argc>1){auto source=std::wstring(argv[1])+L"\\backup-test.dwg";writeLog(source,L"original-drawing");auto first=makeBackup(source),second=makeBackup(source);assert(first!=second);checks++;}
 if(argc>1)writeLog(std::wstring(argv[1])+L"\\verification-automation.json",L"{\"passed\":true,\"checks\":"+std::to_wstring(checks)+L",\"kind\":\"Windows COM mocks and scoped-dialog integration; no real AutoCAD installed\"}");
 printf("%d Windows COM/property/dialog/backup tests passed; real AutoCAD 2018 not available\n",checks);CoUninitialize();return 0;
}
