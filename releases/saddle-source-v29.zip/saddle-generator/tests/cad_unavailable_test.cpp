// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
// Run only in the Wine test environment without a registered AutoCAD server.
#include "win_cad.hpp"
#include <cassert>
using namespace saddlecad;
DWORD child=0;bool sawFailure=false;
BOOL CALLBACK closeExpectedError(HWND h,LPARAM){DWORD pid=0;GetWindowThreadProcessId(h,&pid);if(pid==child&&windowText(h)==L"自动整理未完成"){sawFailure=true;HWND ok=GetDlgItem(h,IDOK);if(ok)PostMessageW(ok,BM_CLICK,0,0);}return TRUE;}
std::string bytes(const std::wstring&path){HANDLE h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);assert(h!=INVALID_HANDLE_VALUE);DWORD size=GetFileSize(h,nullptr),got=0;std::string out(size,0);assert(ReadFile(h,out.data(),size,&got,nullptr)&&got==size);CloseHandle(h);return out;}
int wmain(int argc,wchar_t**argv){assert(argc==4);CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
 for(const wchar_t*name:{L"AutoCAD.Application.22",L"AutoCAD.Application.22.0"}){CLSID id;if(FAILED(CLSIDFromProgID(name,&id)))continue;wchar_t guid[64];StringFromGUID2(id,guid,64);HKEY key=nullptr;if(RegOpenKeyExW(HKEY_CLASSES_ROOT,(L"CLSID\\"+std::wstring(guid)+L"\\LocalServer32").c_str(),0,KEY_READ,&key)==ERROR_SUCCESS){RegCloseKey(key);return 77;}}
 std::wstring source=argv[2];auto original=bytes(source);auto command=quote(argv[1])+L" --cad-postprocess "+quote(source)+L" 15 0 0";STARTUPINFOW start={sizeof(start)};PROCESS_INFORMATION process={};assert(CreateProcessW(argv[1],command.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&start,&process));child=process.dwProcessId;CloseHandle(process.hThread);ULONGLONG until=GetTickCount64()+30000;
 while(WaitForSingleObject(process.hProcess,50)==WAIT_TIMEOUT){EnumWindows(closeExpectedError,0);if(GetTickCount64()>until){TerminateProcess(process.hProcess,9);assert(false&&"worker did not report missing AutoCAD");}}
 DWORD code=0;GetExitCodeProcess(process.hProcess,&code);CloseHandle(process.hProcess);assert(code==4&&sawFailure&&bytes(source)==original);auto log=bytes(source+L".自动处理.log");assert(log.find("ActiveX")!=std::string::npos);
 writeLog(std::wstring(argv[3])+L"\\verification-no-autocad.json",L"{\"passed\":true,\"checks\":1,\"exit_code\":4,\"original_dwg_unchanged\":true,\"failure_log_present\":true}");printf("Actual generator worker reported missing AutoCAD and preserved the exported DWG\n");CoUninitialize();return 0;
}
