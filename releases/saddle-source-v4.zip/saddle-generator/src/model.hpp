// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <fstream>
#include "template.hpp"
namespace saddle {
constexpr double PI=3.14159265358979323846;
struct Params {
 int type=0,ribs=6,holes=3,paper=2; // 0: central web, 1: side web; A0..A4
 double diameter=2000,height=1400,length=1800,depth=560,angle=120;
 double base=24,web=12,rib=12,pad=12,padWidth=400,supportWidth=280,hole=54,edgeX=100,edgeY=60,slot=90,weld=6;
 double padAngle=126,fillet=36,ventOffset=20,ventDiameter=6,outerSetback=30;
 double holeRowSpacing=440;std::vector<double> holeDistances={800};
 std::vector<double> ribSpacings={300,300}; // Independent, centre-outward; excludes outer ribs.
 double scale=0; bool reinforced=false; bool sliding=false; // 0 = recommended
};
struct Entity {int kind;double x,y,a,b,c;std::string text;int layer; int color=256,style=0,lt=1,lw=-1,attachment=1,degree=3,role=0; double rotation=0,width=0,widthFactor=1,ltscale=1; std::string source,previewText; std::vector<double> points,samples,knots,weights;};
struct RefLayer {std::string name;int color,lw,lt,plot;};
struct RefStyle {std::string name,font,bigfont;double width,height,oblique,lastHeight;};
struct RefLtype {std::string name,description;std::vector<double> dashes;};
struct Point {double x=0,y=0;};
struct Dimension {
 int type=0; // 0 rotated linear, 1 aligned, 2 radius, 3 diameter, 4 angular 3-point
 Point first,second,centre,at,textAt;double rotation=0,measurement=0;
 std::string prefix,key;std::vector<Entity> graphics;
};
struct Drawing {
 int type=0;
 std::vector<Dimension> dimensions;bool webNotched=false;double deg3=0;
 std::vector<Entity> e; size_t modelCount=0; double minX=0,minY=0,maxX=1,maxY=1; double plotFactor=1,requiredRatio=1; double sheetW=0,sheetH=0,ratio=1,recommended=1;
 void line(double x,double y,double a,double b,int l=0){e.push_back({0,x,y,a,b,0,"",l});}
 void circle(double x,double y,double r,int l=0){e.push_back({1,x,y,r,0,0,"",l});}
 void arc(double x,double y,double r,double s,double t,int l=0){e.push_back({2,x,y,r,s,t,"",l});}
 void text(double x,double y,std::string t,double h=14,int l=2){e.push_back({3,x,y,h,0,0,t,l});}
 void rect(double x,double y,double w,double h,int l=0){line(x,y,x+w,y,l);line(x+w,y,x+w,y+h,l);line(x+w,y+h,x,y+h,l);line(x,y+h,x,y,l);}
 void bounds(){minX=minY=1e30;maxX=maxY=-1e30;auto p=[&](double x,double y){minX=std::min(minX,x);minY=std::min(minY,y);maxX=std::max(maxX,x);maxY=std::max(maxY,y);};for(auto&v:e){if(v.kind!=2)p(v.x,v.y);if(v.kind==0)p(v.a,v.b);if(v.kind==1){p(v.x-v.a,v.y-v.a);p(v.x+v.a,v.y+v.a);}if(v.kind==2){auto point=[&](double deg){double t=deg*PI/180;p(v.x+v.a*cos(t),v.y+v.a*sin(t));};point(v.b);point(v.c);double sweep=fmod(v.c-v.b+360.,360.);if(sweep==0)sweep=360;for(double deg:{0.,90.,180.,270.})if(fmod(deg-v.b+720.,360.)<=sweep)point(deg);}if(v.kind==3)p(v.x+v.text.size()*v.a*.62,v.y+v.a);}}
};
inline std::string num(double x){std::ostringstream o;o<<std::fixed<<std::setprecision(std::abs(x-std::round(x))<1e-7?0:2)<<x;return o.str();}
inline std::vector<std::string> validate(const Params&p){
 std::vector<std::string> v;auto chk=[&](bool ok,const char*s){if(!ok)v.push_back(s);};
 const double values[]={p.diameter,p.height,p.length,p.depth,p.angle,p.base,p.web,p.rib,p.pad,p.padWidth,p.supportWidth,p.weld,p.hole,p.edgeX,p.edgeY,p.slot,p.scale};
 for(double x:values)if(!std::isfinite(x)){v.push_back("All parameters must be finite.");return v;}
 chk(p.diameter>=100&&p.diameter<=20000,"Vessel diameter must be 100..20000 mm.");
 chk(p.height>p.diameter/2+p.base+p.pad&&p.height<=p.diameter*3,"Centre height must exceed R + base + wear plate.");
 chk(p.angle>=60&&p.angle<=160,"Contact angle must be 60..160 degrees.");
 chk(p.length>=p.diameter*.4&&p.length<=p.diameter*1.5,"Base length must be 0.4..1.5 times vessel diameter.");
 chk(p.depth>=80&&p.depth<=5000,"Base depth must be 80..5000 mm.");
 chk(p.base>=4&&p.base<=200&&p.web>=4&&p.web<=100&&p.rib>=4&&p.rib<=100&&p.pad>=3&&p.pad<=100,"Plate thickness is out of range.");
 chk(p.supportWidth>p.web+20&&p.supportWidth+2*p.weld+20<=p.depth,"Body width plus weld clearance must fit base.");
 chk(p.weld>=3&&p.weld<=30,"Weld leg must be 3..30 mm.");
 chk(p.padWidth>=p.supportWidth+2*p.weld+40&&p.padWidth<=p.depth,"Wear plate width must be at least body width + 2*weld + 40.");
 chk(p.depth/2-p.edgeY-p.slot/2>p.supportWidth/2+p.weld+5,"Anchor rows need more clearance from rib/weld (increase base width or reduce edge distance/body width).");
 chk(p.ribs>=2&&p.ribs<=20,"Rib count must be 2..20 (total transverse stations).");
 chk(p.holes>=2&&p.holes<=40,"Hole count per row must be 2..40.");
 chk(p.hole>=6&&p.hole<=150&&p.slot>=p.hole,"Hole diameter must be 6..150; slot length >= diameter.");
 chk(p.edgeX>p.hole/2+5&&p.edgeX<p.length/2&&p.edgeY>p.slot/2+5&&p.edgeY<p.depth/2,"Anchor edge distance is invalid.");
 chk((p.length-2*p.edgeX)/(p.holes-1)>p.hole+10,"Anchor holes overlap along base length.");
 chk(p.depth-2*p.edgeY>p.slot+10,"Anchor rows overlap.");
 chk(p.rib*(p.ribs+1)<p.length-2*p.edgeX,"Rib count/thickness does not fit base.");
 chk(p.type==0||p.type==1,"Unknown saddle type."); chk(p.paper>=0&&p.paper<5,"Unknown paper."); chk(p.scale==0||(p.scale>=1&&p.scale<=1000),"Scale denominator must be 1..1000, or automatic.");return v;
}
inline void dimH(Drawing&d,double x1,double x2,double y,double at,const std::string&t,double h){
 d.line(x1,y,x1,at+h*.5,2);d.line(x2,y,x2,at+h*.5,2);d.line(x1,at,x2,at,2);
 for(double x:{x1,x2}){double sign=x==x1?1:-1;d.line(x,at,x+sign*h*.7,at+h*.28,2);d.line(x,at,x+sign*h*.7,at-h*.28,2);}d.text((x1+x2)/2-t.size()*h*.25,at+h*.4,t,h);
}
inline void dimV(Drawing&d,double y1,double y2,double x,double at,const std::string&t,double h){
 d.line(x,y1,at+h*.4,y1,2);d.line(x,y2,at+h*.4,y2,2);d.line(at,y1,at,y2,2);
 for(double y:{y1,y2}){double sign=y==y1?1:-1;d.line(at,y,at-h*.28,y+sign*h*.7,2);d.line(at,y,at+h*.28,y+sign*h*.7,2);}d.text(at+h*.5,(y1+y2)/2,t,h);
}
inline Drawing generateLegacy(const Params&p){
 auto errors=validate(p);if(!errors.empty())throw std::runtime_error(errors[0]);
 Drawing d; double R=p.diameter/2,ro=R+p.pad,a=p.angle*PI/360,half=ro*sin(a),end=p.height-ro*cos(a),bottom=p.height-ro;
 double h=std::max(12.,p.length/50),gap=std::max(200.,p.length*.25),side=p.length+gap,plan=-p.depth-gap;
 // Front elevation: vessel-centred contact arcs, continuous web and wear plate.
 double pa=std::min(180.,p.angle+(p.reinforced?ceil(p.angle/12):6.)); double aa=pa*PI/360;
 d.rect(-p.length/2,0,p.length,p.base);d.arc(0,p.height,R,270-pa/2,270+pa/2);d.arc(0,p.height,ro,270-pa/2,270+pa/2);
 for(int sign:{-1,1}) d.line(sign*R*sin(aa),p.height-R*cos(aa),sign*ro*sin(aa),p.height-ro*cos(aa));
 for(int sign:{-1,1}){d.line(sign*half,end,sign*(p.length/2-20),p.base);}
 d.line(-p.length/2+20,p.base,p.length/2-20,p.base);d.line(0,-h*3,0,p.height+h*2,1);d.line(-half-h*2,p.height,half+h*2,p.height,1);
 double ribLeft=p.length/2-30;
 for(int i=0;i<p.ribs;i++){double t=-a+2*a*i/(p.ribs-1),x=ro*sin(t),bx=ribLeft*sin(t)/sin(a);double top=p.height-ro*cos(t);d.line(bx-p.rib/2,p.base,x-p.rib/2,top);d.line(bx+p.rib/2,p.base,x+p.rib/2,top);d.line(x-p.rib/2,top,x+p.rib/2,top);}
 dimH(d,-p.length/2,p.length/2,0,-h*4,num(p.length),h);dimV(d,0,p.height,p.length/2,p.length/2+h*5,"H="+num(p.height),h);
 d.text(-p.length/2,p.height+h*4,"FRONT / D="+num(p.diameter)+"  CONTACT="+num(p.angle)+"deg",h*1.1);
 // Axial elevation: central web vs web on one axial side, per source drawings.
 double webY=p.type==0?0:p.supportWidth/2-p.web/2;
 d.rect(side-p.depth/2,0,p.depth,p.base);double outerTop=p.height-ro*cos(aa),innerTop=p.height-R*cos(aa);d.rect(side-p.padWidth/2,bottom,p.padWidth,innerTop-bottom);d.line(side-p.padWidth/2,bottom+p.pad,side+p.padWidth/2,bottom+p.pad,1);d.line(side-p.padWidth/2,outerTop,side+p.padWidth/2,outerTop,1);
 d.rect(side+webY-p.web/2,p.base,p.web,end-p.base);
 d.rect(side-p.supportWidth/2,p.base,p.supportWidth,end-p.base);
 d.line(side,-h*3,side,p.height+h*2,1);d.line(side-p.padWidth/2-h,p.height,side+p.padWidth/2+h,p.height,1);
 d.circle(side-p.padWidth/2+20,bottom+p.pad/2,3);d.text(side-p.depth/2,bottom-h*2,"VENT D6",h);
 dimH(d,side-p.depth/2,side+p.depth/2,0,-h*4,num(p.depth),h);dimV(d,p.base,bottom,side+p.depth/2,side+p.depth/2+h*4,"hmin="+num(bottom-p.base),h);
 d.text(side-p.depth/2,p.height+h*4,p.type==0?"SIDE / CENTRAL WEB":"SIDE / SIDE WEB",h*1.1);
 // Plan: exact N holes, two rows; rib stations projected consistently.
 d.rect(-p.length/2,plan-p.depth/2,p.length,p.depth);d.rect(-ro*sin(aa),plan-p.padWidth/2,2*ro*sin(aa),p.padWidth,1);
 d.rect(-half,plan+webY-p.web/2,2*half,p.web);
 for(int i=0;i<p.ribs;i++){double t=-a+2*a*i/(p.ribs-1),x=ribLeft*sin(t)/sin(a);d.rect(x-p.rib/2,plan-p.supportWidth/2,p.rib,p.supportWidth);}
 int perRow=p.holes;
 for(int row: (p.type?std::vector<int>{-1}:std::vector<int>{-1,1}))for(int i=0;i<perRow;i++){
  double x=perRow==1?0:-p.length/2+p.edgeX+(p.length-2*p.edgeX)*i/(perRow-1),y=plan+row*(p.depth/2-p.edgeY),r=p.hole/2;
  if(!p.sliding||p.slot==p.hole)d.circle(x,y,r);else {double s=(p.slot-p.hole)/2;d.arc(x,y+s,r,0,180);d.arc(x,y-s,r,180,360);d.line(x-r,y-s,x-r,y+s);d.line(x+r,y-s,x+r,y+s);}
  d.line(x-r-h*.5,y,x+r+h*.5,y,1);d.line(x,y-r-h*.5,x,y+r+h*.5,1);
 }
 dimH(d,-p.length/2,p.length/2,plan-p.depth/2,plan-p.depth/2-h*4,num(p.length),h);if(perRow>1)dimH(d,-p.length/2+p.edgeX,p.length/2-p.edgeX,plan+p.depth/2,plan+p.depth/2+h*3,num(p.length-2*p.edgeX)+" +/-1.0",h);
 d.text(-p.length/2,plan-p.depth/2-h*7,"PLAN / "+std::to_string(p.holes*(p.type?1:2))+(p.sliding?" SLOTS ":" HOLES D=")+num(p.hole)+(p.sliding?" x "+num(p.slot):""),h);
 d.text(side-p.depth/2,plan+p.depth/2,"PLATES (mm)",h*1.1);double yy=plan+p.depth/2-h*3;
 for(auto t:std::vector<std::string>{"BASE t="+num(p.base),"WEB t="+num(p.web),"RIB t="+num(p.rib)+" / N="+std::to_string(p.ribs),"WEAR t="+num(p.pad)+" / W="+num(p.padWidth),"BODY WIDTH="+num(p.supportWidth),"WEAR ANGLE="+num(pa)+"deg", "WELD LEG="+num(p.weld),"UNITS: mm / MODEL 1:1","GEOMETRY ONLY; VERIFY DESIGN"}){d.text(side-p.depth/2,yy,t,h);yy-=h*2.3;}
 // Frame dimensions are multiplied by plot ratio: model geometry remains 1:1.
 d.modelCount=d.e.size(); d.bounds(); double minx=d.minX,miny=d.minY,maxx=d.maxX,maxy=d.maxY;
 const double papers[][2]={{1189,841},{841,594},{594,420},{420,297},{297,210}};
 double w=papers[p.paper][0],sh=papers[p.paper][1],need=std::max((maxx-minx)/(w-40),(maxy-miny)/(sh-65));
 const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};d.requiredRatio=need;d.recommended=1000;
 for(double s:scales)if(s>=need){d.recommended=s;break;}
 d.ratio=p.scale>0?p.scale:d.recommended;d.sheetW=w;d.sheetH=sh;
 double s=d.ratio,ox=minx-20*s,oy=miny-40*s;
 d.rect(ox,oy,w*s,sh*s,3);d.rect(ox+10*s,oy+10*s,(w-20)*s,(sh-20)*s,3);
 d.rect(ox+(w-190)*s,oy+10*s,180*s,22*s,3);
 d.text(ox+(w-185)*s,oy+24*s,"SADDLE / "+std::string(p.type?"SIDE":"CENTRAL"),3*s,3);
 d.text(ox+(w-185)*s,oy+16*s,"A"+std::to_string(p.paper)+"  SCALE 1:"+num(s)+"  mm",3*s,3);
 // Preserve visible bounds if manual paper scale is too small.
 d.bounds();return d;
}
inline std::string escapeDXF(const std::string&s){return s;} // model annotations are portable ASCII
inline void legacyWriteDXF(const Drawing&d,const std::string&path){
 std::ofstream f(path,std::ios::binary);if(!f)throw std::runtime_error("Cannot create DXF file");f<<std::setprecision(12);
 auto g=[&](int c,const auto&v){f<<c<<"\r\n"<<v<<"\r\n";};
 f<<templatePre;
 const char* layers[]={"OUTLINE","CENTER","DIMENSION","BORDER"};
 unsigned long handle=0x1000;
 for(const auto&e:d.e){g(0,e.kind==0?"LINE":e.kind==1?"CIRCLE":e.kind==2?"ARC":"TEXT");g(5,[] (unsigned long n){std::ostringstream o;o<<std::hex<<std::uppercase<<n;return o.str();}(handle++));g(330,modelOwner);g(100,"AcDbEntity");g(8,layers[e.layer]);
  g(100,e.kind==0?"AcDbLine":e.kind==3?"AcDbText":"AcDbCircle");g(10,e.x);g(20,e.y);g(30,0);
  if(e.kind==0){g(11,e.a);g(21,e.b);g(31,0);}else if(e.kind==1||e.kind==2){g(40,e.a);if(e.kind==2){g(100,"AcDbArc");g(50,e.b);g(51,e.c);}}else{g(40,e.a);g(1,escapeDXF(e.text));g(50,0);g(100,"AcDbText");}
 }
 f<<templatePost;f.flush();if(!f)throw std::runtime_error("DXF write failed");
}
}

#include "reference_model.hpp"
#include "native_model.hpp"
