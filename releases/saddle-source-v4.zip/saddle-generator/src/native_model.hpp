// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
namespace saddle {
inline Point operator+(Point a,Point b){return {a.x+b.x,a.y+b.y};}
inline Point operator-(Point a,Point b){return {a.x-b.x,a.y-b.y};}
inline Point operator*(Point a,double b){return {a.x*b,a.y*b};}
inline double dot(Point a,Point b){return a.x*b.x+a.y*b.y;}
inline double magnitude(Point a){return hypot(a.x,a.y);}
inline Point unit(Point a){double l=magnitude(a);return l?a*(1/l):Point{1,0};}
inline Point normal(Point a){return {-a.y,a.x};}
inline int spacingCount(int ribs){return std::max(0,(ribs-2)/2);}
inline std::vector<double> innerRibPositions(const Params&p){
 const int n=p.ribs-2;std::vector<double> v;if(n<=0)return v;
 if((int)p.ribSpacings.size()!=spacingCount(p.ribs))throw std::runtime_error("Re-enter inner rib centre spacings after changing the rib count.");
 for(double x:p.ribSpacings)if(!std::isfinite(x)||x<=p.rib)throw std::runtime_error("Inner rib centre spacing must exceed rib thickness.");
 double x=0;int start=0;if(n%2)v.push_back(0);else {x=p.ribSpacings[0]/2;start=1;v.push_back(-x);v.push_back(x);}
 for(int i=start;i<(int)p.ribSpacings.size();i++){x+=p.ribSpacings[i];v.push_back(-x);v.push_back(x);}
 std::sort(v.begin(),v.end());return v;
}
struct RibShape {Point base[2],top[2],contact,direction;double station=0,footThickness=0;};
inline std::vector<double> anchorStations(const Params&p){
 if((int)p.holeDistances.size()!=p.holes/2)throw std::runtime_error("Enter one positive centre distance for each symmetric hole pair.");
 std::vector<double> out;if(p.holes%2)out.push_back(0);double previous=0;
 for(double x:p.holeDistances){if(!std::isfinite(x)||x<=previous)throw std::runtime_error("Hole centre distances must be positive and strictly increasing.");out.push_back(-x);out.push_back(x);previous=x;}
 std::sort(out.begin(),out.end());return out;
}
inline std::vector<RibShape> ribShapes(const Params&p){
 double ro=p.diameter/2+p.pad,theta=p.angle*PI/360,top=p.height-ro*cos(theta),outerFace=p.length/2-p.outerSetback;
 Point contact={ro*sin(theta),top};double innerX=outerFace-p.rib;
 for(int i=0;i<30;i++){Point direction=unit(contact-Point{innerX,p.base});innerX=outerFace-p.rib/direction.y;}
 Point innerBase={innerX,p.base},direction=unit(contact-innerBase),outerTop=contact-normal(direction)*p.rib;
 RibShape right;right.base[0]=innerBase;right.base[1]={outerFace,p.base};right.top[0]=contact;right.top[1]=outerTop;right.contact=contact;right.direction=direction;right.station=(innerX+outerFace)/2;right.footThickness=outerFace-innerX;
 RibShape left=right;for(int j=0;j<2;j++){left.base[j].x*=-1;left.top[j].x*=-1;}left.contact.x*=-1;left.direction.x*=-1;left.station*=-1;
 std::vector<RibShape> out={left};
 for(double x:innerRibPositions(p)){double x0=x-p.rib/2,x1=x+p.rib/2,y0=p.height-sqrt(std::max(0.,ro*ro-x0*x0)),y1=p.height-sqrt(std::max(0.,ro*ro-x1*x1));double y=std::min(y0,y1);RibShape q;q.base[0]={x0,p.base};q.base[1]={x1,p.base};q.top[0]={x0,y};q.top[1]={x1,y};q.contact=y0<y1?q.top[0]:q.top[1];q.direction={0,1};q.station=x;q.footThickness=p.rib;out.push_back(q);}
 out.push_back(right);return out;
}
inline std::vector<std::string> validateV3(const Params&p){
 std::vector<std::string> errors;auto chk=[&](bool ok,const char*text){if(!ok)errors.push_back(text);};
 for(double x:{p.diameter,p.height,p.length,p.depth,p.base,p.web,p.rib,p.pad,p.padWidth,p.supportWidth,p.hole,p.slot,p.scale,p.angle,p.padAngle,p.fillet,p.ventOffset,p.ventDiameter,p.outerSetback,p.holeRowSpacing})if(!std::isfinite(x)){errors.push_back("All parameters must be finite.");return errors;}
 chk(p.type==0||p.type==1,"Unknown saddle type.");chk(p.ribs>=2&&p.ribs<=20,"Rib count must be 2..20 (total transverse stations).");chk(p.holes>=1&&p.holes<=40,"Hole count per row must be 1..40.");
 chk(p.diameter>=100&&p.diameter<=20000,"Vessel diameter must be 100..20000 mm.");chk(p.height>p.diameter/2+p.pad+p.base,"Centre height must exceed R + base + wear plate.");
 chk(p.angle>=60&&p.angle<=160,"Contact angle must be 60..160 degrees.");chk(p.padAngle>=p.angle&&p.padAngle<=180,"Wear plate angle must be between contact angle and 180 degrees.");
 chk(p.length>p.rib*3&&p.length<=30000&&p.depth>p.web&&p.depth<=5000,"Base dimensions are invalid.");chk(p.base>0&&p.web>0&&p.rib>0&&p.pad>0,"Plate thickness is out of range.");
 chk(p.supportWidth>p.web&&p.supportWidth+(p.type?2*p.web:0)<p.depth,"Body width plus weld clearance must fit base.");chk(p.padWidth>=p.supportWidth+(p.type?2*p.web:0)&&p.padWidth<=p.depth,"Wear plate width must contain the rib and web projections.");
 chk(p.fillet>0&&2*p.fillet<p.padWidth,"Wear plate corner radius must fit within its width.");chk(p.ventDiameter>0&&p.ventOffset>p.ventDiameter/2&&p.ventOffset<p.padWidth/2,"Vent offset must lie between the hole radius and half the wear plate width.");
 chk(p.outerSetback>=0&&p.outerSetback+p.rib<p.length/2,"Outer rib setback is invalid.");chk(p.hole>0&&p.slot>=p.hole,"Hole diameter must be 6..150; slot length >= diameter.");chk(p.paper>=0&&p.paper<5,"Unknown paper.");chk(p.scale==0||(p.scale>=1&&p.scale<=1000),"Scale denominator must be 1..1000, or automatic.");
 if(!errors.empty())return errors;
 try{
  auto ribs=ribShapes(p);auto ys=anchorStations(p);auto inner=innerRibPositions(p);
  double limit=std::min(ribs.back().base[0].x,p.diameter/2*sin(p.angle*PI/360))-p.rib;
  chk(inner.empty()||inner.back()<limit,"Inner rib positions must fit between the outer ribs and under the wear plate.");
  std::vector<double> rows=p.type?std::vector<double>{0}:std::vector<double>{-p.holeRowSpacing/2,p.holeRowSpacing/2};
  chk(p.type||p.holeRowSpacing>p.slot,"Anchor rows overlap.");
  for(double x:rows)for(double y:ys){
   chk(std::abs(x)+p.slot/2<p.depth/2&&std::abs(y)+p.hole/2<p.length/2,"Anchor hole extends outside the base.");
   double halfStraight=(p.slot-p.hole)/2;
   auto collision=[&](double loX,double hiX,double loY,double hiY){double dx=std::max({loX-(x+halfStraight),(x-halfStraight)-hiX,0.}),dy=std::max({loY-y,y-hiY,0.});return hypot(dx,dy)<p.hole/2-1e-7;};
   double wx=p.type?-(p.supportWidth+p.web)/2:0;
   double webEnd=p.type?p.length/2:ribs.back().base[0].x;
   chk(!collision(wx-p.web/2,wx+p.web/2,-webEnd,webEnd),"Anchor hole interferes with the web.");
   for(auto&r:ribs)chk(!collision(-p.supportWidth/2,p.supportWidth/2,r.station-r.footThickness/2,r.station+r.footThickness/2),"Anchor hole interferes with a rib.");
  }
  for(size_t i=1;i<ys.size();i++)chk(ys[i]-ys[i-1]>=p.hole,"Anchor holes overlap along base length.");
 }catch(const std::exception&e){errors.push_back(e.what());}return errors;
}
inline void dimensionGraphics(Dimension&dim,double h,int layer){
 auto line=[&](Point a,Point b){dim.graphics.push_back({0,a.x,a.y,b.x,b.y,0,"",layer});};
 auto arrow=[&](Point tip,Point dir){dir=unit(dir);Point side=normal(dir)*(h*.19),back=tip+dir*(h*2.5/3.5);
  Entity e={5,tip.x,tip.y,0,0,0,"",layer};e.points={tip.x,tip.y,back.x+side.x,back.y+side.y,back.x-side.x,back.y-side.y,back.x-side.x,back.y-side.y};dim.graphics.push_back(e);};
 Point a=dim.first,b=dim.second;std::ostringstream formatted;formatted<<std::fixed<<std::setprecision(1)<<dim.measurement;std::string value=formatted.str();if(value.size()>2&&value.substr(value.size()-2)==".0")value.resize(value.size()-2);double rot=0;
 if(dim.type<=1){
  Point u=dim.type==0?Point{cos(dim.rotation*PI/180),sin(dim.rotation*PI/180)}:unit(b-a),n=normal(u);
  Point aa=a+n*dot(dim.at-a,n),bb=b+n*dot(dim.at-b,n);double sign=dot(bb-aa,u)<0?-1:1;u=u*sign;
  auto ext=[&](Point start,Point end){Point dir=unit(end-start);line(start+dir*(h*.625/3.5),end+dir*(h/3.5));};ext(a,aa);ext(b,bb);
  dim.textAt=(aa+bb)*.5+n*(h*.6);rot=atan2(u.y,u.x)*180/PI;if(rot>90||rot<-90)rot+=180;
  double gap=std::min(magnitude(bb-aa)*.2,h*(value.size()+dim.prefix.size())*.3);
  Point mid=(aa+bb)*.5;line(aa,mid-u*gap);line(mid+u*gap,bb);arrow(aa,u);arrow(bb,u*-1);
 }else if(dim.type==2||dim.type==3){
  Point c=dim.type==2?a:(a+b)*.5;Point tip=b;Point dir=unit(dim.at-tip);line(tip,dim.at);arrow(tip,dir);dim.textAt=dim.at+Point{h*.4,h*.3};value=(dim.type==2?"R":"%%c")+value;
  if(dim.type==3){line(a,b);arrow(a,unit(b-a));}
 }else{
  Point c=dim.centre;double radius=magnitude(dim.at-c),s=atan2(a.y-c.y,a.x-c.x),end=atan2(b.y-c.y,b.x-c.x);while(end<s)end+=2*PI;
  Entity e={2,c.x,c.y,radius,s*180/PI,end*180/PI,"",layer};dim.graphics.push_back(e);
  Point aa=c+Point{cos(s),sin(s)}*radius,bb=c+Point{cos(end),sin(end)}*radius;
  line(a,aa+unit(aa-c)*h*.5);line(b,bb+unit(bb-c)*h*.5);arrow(aa,{-sin(s),cos(s)});arrow(bb,{sin(end),-cos(end)});
  double mid=(s+end)/2;dim.textAt=c+Point{cos(mid),sin(mid)}*(radius-h*.8);value+="°";
 }
 Entity text={3,dim.textAt.x,dim.textAt.y,h,0,0,dim.prefix+value,layer};text.previewText=plainMtext(text.text);text.rotation=rot;text.widthFactor=.8;text.style=9;dim.graphics.push_back(text);
}
inline Drawing generate(const Params&p){
 auto errors=validateV3(p);if(!errors.empty())throw std::runtime_error(errors.front());
 Drawing d;d.type=p.type;auto layers=refLayers(p.type);auto layer=[&](const std::string&s){for(size_t i=0;i<layers.size();i++)if(layers[i].name==s)return (int)i;throw std::runtime_error("Missing reference layer");};
 int visible=layer("可见 (Himile)"),centre=layer("中心线 (Himile)"),dimLayer=layer("6 尺寸线-管口号外圆（细实线）"),hidden=layer("4 不可见线（虚线）"),hatchLayer=layer("剖面线 (Himile)");
 const double papers[][2]={{1189,841},{841,594},{594,420},{420,297},{297,210}};d.sheetW=papers[p.paper][0];d.sheetH=papers[p.paper][1];
 double need=std::max({p.height/(135*d.sheetH/420),p.length/(130*d.sheetH/420),p.depth/(55*d.sheetW/594),(p.diameter+2*p.pad)*sin(p.padAngle*PI/360)/(170*d.sheetW/594)});
 const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};d.recommended=1000;for(double s:scales)if(s>=need){d.recommended=s;break;}
 d.requiredRatio=need;d.ratio=p.scale?p.scale:d.recommended;double S=d.ratio;d.plotFactor=S;double W=d.sheetW*S,H=d.sheetH*S,h=3.5*S,offset=8*S;
 auto line=[&](Point a,Point b,int l,int role=0){Entity e={0,a.x,a.y,b.x,b.y,0,"",l};e.role=role;if(l==hidden)e.ltscale=std::min(.08,magnitude(b-a)/(S*19.05*3));d.e.push_back(e);};
 auto rect=[&](double x,double y,double w,double ht,int role=0){line({x,y},{x+w,y},visible,role);line({x+w,y},{x+w,y+ht},visible,role);line({x+w,y+ht},{x,y+ht},visible,role);line({x,y+ht},{x,y},visible,role);};
 auto arc=[&](Point c,double r,double s,double end,int role=0){Entity e={2,c.x,c.y,r,s,end,"",visible};e.role=role;d.e.push_back(e);};
 auto circle=[&](Point c,double r,int role=0){Entity e={1,c.x,c.y,r,0,0,"",visible};e.role=role;d.e.push_back(e);};
 auto label=[&](Point a,std::string text,bool chinese=false){Entity e={3,a.x,a.y,h,0,0,text,dimLayer};e.previewText=text;if(chinese)e.style=refStyles(p.type).size()-1;d.e.push_back(e);};
 auto dim=[&](std::string key,int type,Point a,Point b,Point at,double rotation=0,Point c=Point{},std::string prefix=""){
  Dimension q;q.type=type;q.key=key;q.first=a;q.second=b;q.centre=c;q.at=at;q.rotation=rotation;q.prefix=prefix;
  if(type==0)q.measurement=std::abs(dot(b-a,{cos(rotation*PI/180),sin(rotation*PI/180)}));
  else if(type==1||type==3)q.measurement=magnitude(b-a);else if(type==2)q.measurement=magnitude(b-a);
  else {double ang=atan2(b.y-c.y,b.x-c.x)-atan2(a.y-c.y,a.x-c.x);while(ang<0)ang+=2*PI;q.measurement=ang*180/PI;}
  if(q.measurement<1e-7)return;dimensionGraphics(q,h,dimLayer);d.dimensions.push_back(q);
 };
 auto dh=[&](std::string key,Point a,Point b,double y){dim(key,0,a,b,{(a.x+b.x)/2,y});};
 auto dv=[&](std::string key,Point a,Point b,double x){dim(key,0,a,b,{x,(a.y+b.y)/2},90);};
 const double R=p.diameter/2,ro=R+p.pad,theta=p.angle*PI/360,wear=p.padAngle*PI/360;
 const double frontX=W*.72,frontY=H*.52,sideY=frontY,planY=H*.245,fixedX=W*.19,slidingX=W*.405;
 Point c={frontX,frontY+p.height};double left=frontX-p.length/2,right=frontX+p.length/2,baseTop=frontY+p.base;
 rect(left,frontY,p.length,p.base,1);arc(c,R,270-p.padAngle/2,270+p.padAngle/2,1);arc(c,ro,270-p.padAngle/2,270+p.padAngle/2,1);
 for(int sign:{-1,1})line(c+Point{sign*sin(wear),-cos(wear)}*R,c+Point{sign*sin(wear),-cos(wear)}*ro,visible,1);
 line({frontX,frontY-offset},{frontX,c.y+offset},centre);line({left-offset,c.y},{right+offset,c.y},centre);
 auto inner=innerRibPositions(p);auto ribs=ribShapes(p);const auto&outer=ribs.back();
 std::vector<double> ribBases;for(auto&r:ribs)ribBases.push_back(r.station);
 Point outerDir=outer.direction,innerFace={frontX+outer.base[0].x,frontY+outer.base[0].y},innerContact={frontX+outer.contact.x,frontY+outer.contact.y},fromCentre=innerFace-c;
 double projection=dot(fromCentre,outerDir);Point radial=unit(innerContact-c),tangent=normal(radial);
 d.deg3=acos(std::clamp(std::abs(dot(outerDir,tangent)),0.,1.))*180/PI;d.webNotched=d.deg3<20;
 for(size_t i=0;i<ribs.size();i++){
  auto&r=ribs[i];for(int edge=0;edge<2;edge++)line(r.base[edge]+Point{frontX,frontY},r.top[edge]+Point{frontX,frontY},visible,2);
  line(r.top[0]+Point{frontX,frontY},r.top[1]+Point{frontX,frontY},visible,15);
  Point middle=(r.base[0]+r.base[1])*.5+r.direction*((r.top[0].y-p.base)*.3/r.direction.y)+Point{frontX,frontY},perp=normal(r.direction);
  dim("tw",1,middle-perp*(p.rib/2),middle+perp*(p.rib/2),middle+perp*offset);
 }
 // Web profile: the 50 mm end relief follows a radius through the vessel centre.
 double endRadius=d.webNotched?ro+50:ro;
 double endIntersection=-projection-sqrt(std::max(0.,projection*projection-dot(fromCentre,fromCentre)+endRadius*endRadius));
 Point rightNotch=innerFace+outerDir*endIntersection,rightArc=c+unit(rightNotch-c)*ro;
 Point leftNotch={2*c.x-rightNotch.x,rightNotch.y},leftArc={2*c.x-rightArc.x,rightArc.y};
 Point webBase=innerFace-outerDir*((innerFace.y-baseTop)/outerDir.y);
 line({2*c.x-webBase.x,baseTop},leftNotch,visible,7);if(d.webNotched)line(leftNotch,leftArc,visible,7);
 double webHalfAngle=atan2(rightArc.x-c.x,c.y-rightArc.y)*180/PI;
 arc(c,ro,270-webHalfAngle,270+webHalfAngle,7);if(d.webNotched)line(rightArc,rightNotch,visible,7);line(rightNotch,webBase,visible,7);

 dv("Hs",{left,frontY},{frontX,c.y},left-offset*2);dh("E",{left,frontY},{right,frontY},frontY-offset*2);
 dv("tb",{right,frontY},{right,baseTop},right+offset);dh("X",{left,baseTop},{left+p.outerSetback,baseTop},frontY-offset);
 for(size_t i=1;i<inner.size();i++)dh("di",{frontX+inner[i-1],baseTop},{frontX+inner[i],baseTop},frontY-offset*(3+(i%2)));
 dim("theta",4,{2*c.x-innerContact.x,innerContact.y},innerContact,c+Point{0,-R*.45},0,c);
 dim("theta-w",4,c+Point{-sin(wear),-cos(wear)}*R,c+Point{sin(wear),-cos(wear)}*R,c+Point{0,-R*.65},0,c);
 Point padDirection={sin(wear*.8),-cos(wear*.8)};dim("tp",1,c+padDirection*R,c+padDirection*ro,c+padDirection*(R+p.pad/2)+normal(padDirection)*offset*1.5);
 for(int sign:{-1,1}){line(c,c+Point{sign*sin(wear),-cos(wear)}*(ro+offset),centre,16);line(c,{frontX+sign*outer.contact.x,frontY+outer.contact.y},centre,16);}
 if(d.webNotched){line(c,leftNotch,centre,16);line(c,rightNotch,centre,16);}
 // Elevations use the transverse rib/web heights and the actual bottom pad thickness.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,by=sideY,top=by+p.height-ro*cos(wear),padBottom=by+p.height-ro,padInside=by+p.height-R;
  double pw=p.padWidth,r=p.fillet,wx=p.type?(view?1:-1)*(p.supportWidth+p.web)/2:0;
  rect(px-p.depth/2,by,p.depth,p.base,10);
  for(double x:(p.type?std::vector<double>{0}:std::vector<double>{-p.holeRowSpacing/2,p.holeRowSpacing/2})){
   double half=view?p.slot/2:p.hole/2;for(int sign:{-1,1})line({px+x+sign*half,by},{px+x+sign*half,by+p.base},hidden,17);
  }
  line({px-pw/2,padBottom},{px-pw/2,top-r},visible,11);arc({px-pw/2+r,top-r},r,90,180,11);
  line({px-pw/2+r,top},{px+pw/2-r,top},visible,11);arc({px+pw/2-r,top-r},r,0,90,11);line({px+pw/2,top-r},{px+pw/2,padBottom},visible,11);
  double ribHeight=by+std::max(outer.top[0].y,outer.top[1].y),webHeight=rightArc.y;
  auto padLine=[&](double y){double lo=-p.supportWidth/2,hi=p.supportWidth/2;if(p.type&&y<=webHeight){lo=std::min(lo,wx-p.web/2);hi=std::max(hi,wx+p.web/2);}line({px-pw/2,y},{px+lo,y},visible,11);line({px+lo,y},{px+hi,y},hidden,18);line({px+hi,y},{px+pw/2,y},visible,11);};
  padLine(padBottom);padLine(padInside);
  rect(px-p.supportWidth/2,by+p.base,p.supportWidth,ribHeight-by-p.base,12);
  int webLayer=p.type?visible:hidden;
  line({px+wx-p.web/2,by+p.base},{px+wx-p.web/2,webHeight},webLayer,13);line({px+wx+p.web/2,by+p.base},{px+wx+p.web/2,webHeight},webLayer,13);line({px+wx-p.web/2,webHeight},{px+wx+p.web/2,webHeight},webLayer,13);
  line({px,by-offset},{px,top+offset},centre);
  double ventX=px+(view?-1:1)*(pw/2-p.ventOffset),ventY=(padBottom+padInside)/2;
  for(int sign:{-1,1})line({ventX+sign*p.ventDiameter/2,padBottom},{ventX+sign*p.ventDiameter/2,padInside},hidden,14);
  line({ventX,padBottom-offset*.5},{ventX,padInside+offset*.5},centre,14);
  dh("Wp",{px-pw/2,top},{px+pw/2,top},top+offset*2);dh("b",{px-p.supportWidth/2,ribHeight},{px+p.supportWidth/2,ribHeight},ribHeight+offset);
  dh("a1",{ventX,ventY},{px+(view?-1:1)*pw/2,ventY},ventY+offset*.7);
  Point fc={px-pw/2+r,top-r},fp=fc+Point{-sqrt(.5),sqrt(.5)}*r;dim("R1",2,fc,fp,{px-pw/2-offset,top+offset},0,{},"4×");
  label({px-p.depth/2,by-offset*2},view?"滑动鞍座":"固定鞍座",true);label({px-p.depth/2,by-offset*3},view?"Sliding Saddle":"Fixed Saddle");
 }
 auto hatch=[&](double x,double y,double width,double height,double angle,int role){
  if(width<=0||height<=0)return;Entity e={8,x,y,width,height,angle,"",hatchLayer};e.role=role;e.width=5*S;
  double slope=angle>0?1:-1,minV=std::min({y-slope*x,y+height-slope*x,y-slope*(x+width),y+height-slope*(x+width)}),maxV=std::max({y-slope*x,y+height-slope*x,y-slope*(x+width),y+height-slope*(x+width)});
  for(double v=floor(minV/(e.width*sqrt(2.)))*e.width*sqrt(2.);v<maxV;v+=e.width*sqrt(2.)){
   std::vector<Point> pts;auto add=[&](Point q){if(q.x>=x-1e-7&&q.x<=x+width+1e-7&&q.y>=y-1e-7&&q.y<=y+height+1e-7){for(auto&a:pts)if(magnitude(q-a)<1e-6)return;pts.push_back(q);}};
   add({x,slope*x+v});add({x+width,slope*(x+width)+v});add({(y-v)/slope,y});add({(y+height-v)/slope,y+height});if(pts.size()==2)e.samples.insert(e.samples.end(),{pts[0].x,pts[0].y,pts[1].x,pts[1].y});
  }d.e.push_back(e);
 };
 // Plans share the physical rib stations, not scaled or inferred annotation endpoints.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,py=planY,x0=px-p.depth/2,y0=py-p.length/2,wx=p.type?(view?1:-1)*(p.supportWidth+p.web)/2:0;
  rect(x0,y0,p.depth,p.length,3);
  double webLength=p.type?p.length:2*outer.base[0].x,webY=py-webLength/2;
  rect(px+wx-p.web/2,webY,p.web,webLength,8);hatch(px+wx-p.web/2,webY,p.web,webLength,45,21);
  for(size_t i=0;i<ribs.size();i++){
   auto&r=ribs[i];double bottom=py+r.station-r.footThickness/2;bool split=!p.type&&i>0&&i+1<ribs.size();
   if(split){double width=(p.supportWidth-p.web)/2;rect(px-p.supportWidth/2,bottom,width,r.footThickness,4);rect(px+p.web/2,bottom,width,r.footThickness,4);hatch(px-p.supportWidth/2,bottom,width,r.footThickness,45,20);hatch(px+p.web/2,bottom,width,r.footThickness,-45,20);}
   else {rect(px-p.supportWidth/2,bottom,p.supportWidth,r.footThickness,4);hatch(px-p.supportWidth/2,bottom,p.supportWidth,r.footThickness,45,20);}
  }
  line({px,y0-offset},{px,y0+p.length+offset},centre);line({x0-offset,py},{x0+p.depth+offset,py},centre);
  std::vector<int> rows=p.type?std::vector<int>{0}:std::vector<int>{-1,1};auto stations=anchorStations(p);
  for(int row:rows)for(int i=0;i<p.holes;i++){
   double x=px+row*p.holeRowSpacing/2,y=py+stations[i],rad=p.hole/2,straight=view?p.slot-p.hole:0;
   if(straight<1e-8)circle({x,y},rad,view?6:5);else {arc({x-straight/2,y},rad,90,270,6);arc({x+straight/2,y},rad,270,450,6);line({x-straight/2,y+rad},{x+straight/2,y+rad},visible,6);line({x-straight/2,y-rad},{x+straight/2,y-rad},visible,6);}
   line({x-rad-h*.5,y},{x+rad+h*.5,y},centre);line({x,y-rad-h*.5},{x,y+rad+h*.5},centre);
   if(std::abs(y-py)>1e-7)dv("a2",{x,py},{x,y},row<0?x0-offset*(1.2+i*.75):x0+p.depth+offset*(1.2+i*.75));
   if(i==0&&row==rows.front()){
    dim("bolt-diameter",3,{x,y-rad},{x,y+rad},{x+p.depth*.65,y+offset},0,{},std::to_string(totalHoles(p))+"×");
    if(view&&straight>1e-8)dh("a4",{x-straight/2,y+rad},{x+straight/2,y+rad},y+rad+offset);
   }
  }
  dv("E",{x0,y0},{x0,y0+p.length},view?x0+p.depth+offset*2:x0-offset*(p.holes*.75+2));
  dh("F",{x0,y0+p.length},{x0+p.depth,y0+p.length},y0+p.length+offset*2);
  if(!p.type)dh("a3",{px-p.holeRowSpacing/2,py},{px+p.holeRowSpacing/2,py},py-offset*2);
  dh("ts",{px+wx-p.web/2,py},{px+wx+p.web/2,py},py+offset*1.4);

 }
 label({W*.81,H*.93},"1 : "+num(d.ratio));
 d.modelCount=d.e.size()+d.dimensions.size();d.minX=d.minY=0;d.maxX=W;d.maxY=H;return d;
}
}
