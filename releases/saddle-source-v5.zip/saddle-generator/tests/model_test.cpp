// SPDX-License-Identifier: GPL-3.0-or-later
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int cases=0;
 for(int type:{0,1})for(int holes:{1,2,3,4,5})for(int count:{4,6}){
  Params p;p.type=type;p.holes=holes;p.ribs=count;p.ribSpacings.assign(spacingCount(count),300);p.holeDistances.clear();if(holes/2==1)p.holeDistances={800};if(holes/2==2)p.holeDistances={300,800};assert(validateV3(p).empty());auto d=generate(p);auto r=ribShapes(p);Point centre={0,p.height};
  for(size_t i=0;i<r.size();i++){auto&q=r[i];assert(std::abs(dot(q.top[1]-q.top[0],q.direction))<1e-7);assert(std::abs(magnitude(q.contact-centre)-(p.diameter/2+p.pad))<1e-7);if(i>0&&i+1<r.size())assert(q.top[0].y==q.top[1].y);}
  double angle=atan2(r.back().contact.x,p.height-r.back().contact.y)*360/PI;assert(std::abs(angle-p.angle)<1e-8);
  auto ys=anchorStations(p);assert(ys.size()==(unsigned)holes);for(int i=0;i<holes;i++)assert(std::abs(ys[i]+ys[holes-1-i])<1e-8);if(holes%2)assert(ys[holes/2]==0);
  int fixed=0,slots=0,baseHidden=0,vents=0,webHidden=0,a2=0;std::vector<const Entity*> sections;
  for(auto&e:d.e){if(e.role==5&&e.kind==1)fixed++;if(e.role==6&&e.kind==2)slots++;if(e.role==17){assert(e.layer==6);baseHidden++;}if(e.role==14&&e.layer==6){assert(e.kind==0);vents++;double mid=(e.x+e.a)/2;assert(mid<d.maxX*.405&&mid>d.maxX*.19);}if(e.role==13&&e.layer==6)webHidden++;if(e.kind==8)sections.push_back(&e);assert(e.text!="A-A"&&e.text!="B-B"&&e.text!="VIEW A");}
  assert(fixed==holes*(type?1:2));assert(slots==fixed*2);assert(baseHidden==(type?4:8));assert(vents==4);assert(webHidden==(type?0:6));
  for(size_t i=0;i<sections.size();i++)for(size_t j=i+1;j<sections.size();j++){auto&a=*sections[i],&b=*sections[j];double dx=std::min(a.x+a.a,b.x+b.a)-std::max(a.x,b.x),dy=std::min(a.y+a.b,b.y+b.b)-std::max(a.y,b.y);assert(dx<1e-7||dy<1e-7);}
  for(auto&q:d.dimensions){if(q.key=="bolt-pair"){a2++;assert(q.tolerance==1);assert(std::find(p.holeDistances.begin(),p.holeDistances.end(),q.measurement/2)!=p.holeDistances.end());}if(q.key=="a3")assert(std::abs(q.measurement-p.holeRowSpacing)<1e-7);for(auto&e:q.graphics)assert(e.layer==(e.kind==3?2:4));}
  assert(a2==2*(holes/2));
  p.scale=25;auto scaled=generate(p);assert(scaled.dimensions.size()==d.dimensions.size());for(size_t i=0;i<d.dimensions.size();i++)assert(std::abs(scaled.dimensions[i].measurement*scaled.dimensions[i].measurementScale-d.dimensions[i].measurement*d.dimensions[i].measurementScale)<1e-7);cases++;
 }
 Params p;p.type=1;p.holes=2;p.holeDistances={150};assert(!validateV3(p).empty());p.holeDistances={300};assert(validateV3(p).empty());p.holes=1;p.holeDistances.clear();assert(validateV3(p).empty());p.ribs=3;p.ribSpacings.clear();assert(!validateV3(p).empty());
 p=Params();p.holeRowSpacing=120;p.holeDistances={300};assert(validateV3(p).empty());p.holeRowSpacing=70;assert(!validateV3(p).empty());
 p=Params();p.holeDistances={890};assert(!validateV3(p).empty());p.holes=4;p.holeDistances={300,290};assert(!validateV3(p).empty());
 p=Params();p.ribs=7;p.ribSpacings={200,350};auto positions=innerRibPositions(p);assert((positions==std::vector<double>{-550,-200,0,200,550}));
 p=Params();auto d=generate(p);assert(!d.webNotched);p.outerSetback=300;d=generate(p);assert(d.webNotched);int radialEdges=0;Point c={d.maxX*.72,d.maxY*.52+p.height};for(auto&e:d.e)if(e.role==7&&e.kind==0&&std::abs(hypot(e.a-e.x,e.b-e.y)-50)<1e-7){Point a={e.x-c.x,e.y-c.y},b={e.a-c.x,e.b-c.y};assert(std::abs(a.x*b.y-a.y*b.x)<1e-6);radialEdges++;}assert(radialEdges==2);
 std::cout<<cases<<" V5 parameter cases plus flat ends, contact angle, projections, symmetric holes, nonintersecting sections, interference and Note8 checks passed\n";
}
