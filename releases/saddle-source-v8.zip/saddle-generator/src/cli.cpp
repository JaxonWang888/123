// SPDX-License-Identifier: GPL-3.0-or-later
#include "dwg_export.hpp"
#include <iostream>
int main(int argc,char**argv){try{saddle::Params p;if(argc>2)p.type=std::stoi(argv[2]);if(argc>3)p.holes=std::stoi(argv[3]);if(argc>4)p.ribs=std::stoi(argv[4]);if(argc>5)p.sliding=std::stoi(argv[5]);p.holeDistances.clear();for(int i=1;i<=p.holes/2;i++)p.holeDistances.push_back(800.*i/(p.holes/2));p.ribSpacings.assign(saddle::spacingCount(p.ribs),300);auto d=saddle::generate(p);saddle::writeDXF(d,argc>1?argv[1]:"saddle.dxf");saddle::writeDWG(d,std::string(argc>1?argv[1]:"saddle.dxf")+".dwg");std::cout<<"entities="<<d.e.size()<<" scale=1:"<<d.ratio<<"\n";}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
