// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <map>
#include <functional>
#include <regex>
#include "reference_styles.hpp"
#include "reference_data.hpp"
namespace saddle {
inline std::vector<RefLayer> refLayers(int t){return t?layers1():layers0();}
inline std::vector<RefStyle> refStyles(int t){auto result=t?styles1():styles0();for(auto&style:result){style.font="arial.ttf";style.bigfont="";}result.push_back({"Saddle_SimSun","simsun.ttc","",1,0,0,2.5});return result;}
inline std::vector<RefLtype> refLtypes(int t){return t?ltypes1():ltypes0();}
inline int totalHoles(const Params&p){return p.holes*(p.type?1:2);}
inline std::string plainMtext(std::string raw){
 raw=std::regex_replace(raw,std::regex(R"(\\[fWHACQpT][^;]*;)"),"");
 raw=std::regex_replace(raw,std::regex(R"(\\[Pp])"),"\n");
 raw=std::regex_replace(raw,std::regex(R"(\\[LlOoKk])"),"");
 raw=std::regex_replace(raw,std::regex(R"([{}])"),"");
 raw=std::regex_replace(raw,std::regex("%%[cC]"),"Ø");raw=std::regex_replace(raw,std::regex("%%[pP]"),"±");raw=std::regex_replace(raw,std::regex("%%[dD]"),"°");return raw;
}
inline double lerpAxis(double v,const std::vector<std::pair<double,double>>&p){
 auto it=std::upper_bound(p.begin(),p.end(),v,[](double x,const auto&y){return x<y.first;});
 size_t i=it==p.begin()?0:it==p.end()?p.size()-2:it-p.begin()-1;
 return p[i].second+(v-p[i].first)*(p[i+1].second-p[i].second)/(p[i+1].first-p[i].first);
}
inline void mapEntity(Entity&e,const std::function<std::pair<double,double>(double,double)>&f){
 auto a=f(e.x,e.y);e.x=a.first;e.y=a.second;
 if(e.kind==0){auto b=f(e.a,e.b);e.a=b.first;e.b=b.second;}
 if(e.kind==5||e.kind==6)for(size_t i=0;i+1<e.points.size();i+=2){auto b=f(e.points[i],e.points[i+1]);e.points[i]=b.first;e.points[i+1]=b.second;}
 for(size_t i=0;i+1<e.samples.size();i+=2){auto b=f(e.samples[i],e.samples[i+1]);e.samples[i]=b.first;e.samples[i+1]=b.second;}
}
inline void replaceAll(std::string&s,const std::string&a,const std::string&b){size_t at=0;while((at=s.find(a,at))!=std::string::npos){s.replace(at,a.size(),b);at+=b.size();}}
inline std::map<std::string,std::string> dimensions(const Params&p){
 double pa=std::min(180.,p.angle+(p.reinforced?ceil(p.angle/12):6.));
 std::map<std::string,std::string> d;
 auto set=[&](std::initializer_list<const char*>ids,double value){for(auto id:ids)d[id]=num(value);};
 if(!p.type){
 set({"E8D0B","E8D68"},p.base);set({"E8D25"},p.supportWidth);set({"E8D32"},p.padWidth);set({"E8F2C"},p.web);
 set({"E8D8E"},p.height);set({"E8D9A"},p.diameter/2);set({"E8DA3"},p.pad);
 set({"E8DBB"},p.base);set({"E8DF8"},p.length);set({"E8DC8","E8DD2","E8DDF"},(p.length-60)/(p.ribs-1));set({"E8E03","E8E0F","E8E1B"},p.rib);
 set({"E8E2C","E8E3F","E8E70","E8E7E"},p.depth);set({"E8E52","E8E59","E8E65"},p.length-2*p.edgeX);set({"E8E8C","E8E98"},p.web);
 set({"E8EA4","E8EB3","E8F09"},p.edgeY);set({"E8EF4"},p.slot);
 d["E8D70"]=num(p.angle)+"°";d["E8D7F"]=num(pa)+"°";
 }else{
 // Source-specific handles are used instead of guessing from the text value.
 set({"E9188","E9228"},p.base);set({"E91D8"},p.supportWidth);set({"E91E9","E925E","E92B5"},p.web);set({"E91FC"},p.padWidth);
 set({"E922B","E927F","E92A4","E933F"},p.depth);set({"E923C","E9270","E92D7","E97EA"},p.length-2*p.edgeX);set({"E924A","E9290"},p.edgeX);set({"E9353"},p.slot);set({"E9365"},p.edgeY);
 set({"E93A3"},p.height);set({"E93B2","E93C3","E93D4"},(p.length-60)/(p.ribs-1));set({"E93E5"},p.base);set({"E93F9"},p.length);set({"E941C","E942E","E9440"},p.rib);set({"E9452"},p.pad);set({"E9466"},p.diameter/2);d["E9470"]=num(p.angle)+"°";d["E947F"]=num(pa)+"°";
 }
 return d;
}
inline Drawing generateV2(const Params&p){
 auto errors=validate(p);if(!errors.empty())throw std::runtime_error(errors.front());
 static const auto central=reference0(),edge=reference1();auto src=p.type?edge:central;
 Drawing d;d.type=p.type;auto layers=refLayers(p.type);
 auto layer=[&](const std::string&name){for(size_t i=0;i<layers.size();i++)if(layers[i].name==name)return (int)i;throw std::runtime_error("Missing reference layer");};
 int outline=layer("可见 (Himile)"),center=layer("中心线 (Himile)"),dimension=layer("尺寸 (Himile)");
 const double papers[][2]={{1189,841},{841,594},{594,420},{420,297},{297,210}};
 d.sheetW=papers[p.paper][0];d.sheetH=papers[p.paper][1];double k=std::min(d.sheetW/594.,d.sheetH/420.);
 double need=std::max({p.height/(125*k),p.length/(130*k),p.depth/(55*k),(p.diameter+2*p.pad)*sin(p.angle*PI/360)/(170*k)});
 const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};d.recommended=1000;for(double s:scales)if(s>=need){d.recommended=s;break;}
 d.requiredRatio=need;d.ratio=p.scale?p.scale:d.recommended;double F=k*d.ratio;d.plotFactor=F;
 // All source coordinates are paper coordinates; F converts to model millimetres.
 const double frontX=p.type?329.81711414662:335.06270166246,frontY=p.type?191.86395203993:199.85603910476;
 const double fixedX=p.type?88.77271372357:88.53418602501,slidingX=p.type?179.65342220351:185.19985269168;
 const double sideY=p.type?193.56215444479:201.55542240563,planY=p.type?87.05340534271:92.56783503712;
 auto dims=dimensions(p);double R=p.diameter/2,ro=R+p.pad,a=p.angle*PI/360,pa=std::min(180.,p.angle+(p.reinforced?ceil(p.angle/12):6.)),aa=pa*PI/360;
 double oldH=113.33333333333;
 auto height=[&](double y){return lerpAxis(y,{{0,0},{1.6,p.base/F},{31.7333333333,(p.height-ro)/F},{72.5333333333,(p.height-ro*cos(a))/F},{oldH,p.height/F}});};
 auto width=[&](double x){double sign=x<0?-1:1;x=std::abs(x);return sign*lerpAxis(x,{{0,0},{.8,p.web/(2*F)},{11.6666666667,p.supportWidth/(2*F)},{13.3333333333,p.depth/(2*F)},{18.3333333333,p.padWidth/(2*F)},{40,40}});};
 auto planHeight=[&](double y){return y*(p.length/F)/113.3333333333;};
 auto add=[&](Entity e,int role=0){e.role=role;d.e.push_back(std::move(e));};
 // Identify source view windows. Notes, detail views and BOM remain unchanged.
 for(auto e:src){
  double mx=e.x,my=e.y;if(e.kind==0){mx=(e.x+e.a)/2;my=(e.y+e.b)/2;}
  bool front=mx>245&&mx<430&&my>170&&my<330;
  bool side=mx>25&&mx<235&&my>185&&my<330;
  bool plan=mx>25&&mx<235&&my>25&&my<175;
  double sx=std::abs(mx-fixedX)<std::abs(mx-slidingX)?fixedX:slidingX;
  bool visible=e.layer==outline;
  if(front&&visible)continue; // rebuilt from exact dimensional geometry below
  if(plan&&visible&&std::abs(mx-sx)<19)continue;
  // Source centre markers of removed holes are regenerated with the holes.
  if(plan&&layers[e.layer].name.find("中心")!=std::string::npos&&std::abs(mx-sx)<19)continue;
  if(front){
   double oldRadius=e.a,oldStart=e.b,oldEnd=e.c;bool ring=e.kind==2&&std::abs(e.x-frontX)<.02&&std::abs(e.y-(frontY+oldH))<.02;
   mapEntity(e,[&](double x,double y){double dx=x-frontX,dy=y-(frontY+oldH),rr=hypot(dx,dy);if(dy<-.001&&rr<90){double angle=atan2(dy,dx)*180/PI;if(angle<0)angle+=360;double factor=rr<43?pa/122.628:p.angle/120.;double theta=(270+(angle-270)*factor)*PI/180;return std::make_pair(frontX+rr*(ro/F)/81.6*cos(theta),frontY+p.height/F+rr*(ro/F)/81.6*sin(theta));}return std::make_pair(frontX+dx*(p.length/F)/113.3333333333,frontY+height(y-frontY));});
   if(ring){double factor=oldRadius<43?pa/122.628:p.angle/120.;e.a=oldRadius*ro/(81.6*F);e.b=270+(oldStart-270)*factor;e.c=270+(oldEnd-270)*factor;}
  }
  else if(side)mapEntity(e,[&](double x,double y){return std::make_pair(sx+width(x-sx),sideY+height(y-sideY));});
  else if(plan)mapEntity(e,[&](double x,double y){return std::make_pair(sx+width(x-sx),planY+planHeight(y-planY));});
  if(e.kind==3||e.kind==4){
   auto found=dims.find(e.source);if(found!=dims.end()){
    if(e.text.find("***")!=std::string::npos)replaceAll(e.text,"***",found->second);else {auto pos=e.text.rfind(';');e.text=e.text.substr(0,pos==std::string::npos?0:pos+1)+found->second;}
   }
   if(e.text.find("6×Ø54")!=std::string::npos||e.text.find("2×Ø54")!=std::string::npos){e.text=std::regex_replace(e.text,std::regex("[26]×Ø54"),std::to_string(totalHoles(p))+"×Ø"+num(p.hole));}
   replaceAll(e.text,"6Nos.",std::to_string(totalHoles(p))+"Nos.");replaceAll(e.text,"2Nos.",std::to_string(totalHoles(p))+"Nos.");replaceAll(e.text,"2×R27","2×R"+num(p.hole/2));
   if(e.text.find("比例SCALE")!=std::string::npos&&e.text.find("15")!=std::string::npos)e.text=std::regex_replace(e.text,std::regex("1 *: *15"),"1 : "+num(d.ratio));
   if(e.text.find("***mm")!=std::string::npos)replaceAll(e.text,"***mm",num(p.weld)+"mm");
  }
  if(e.kind==3||e.kind==4)e.previewText=plainMtext(e.text);add(std::move(e));
 }
 auto line=[&](double x,double y,double xx,double yy,int l,int role=0){Entity e={0,x,y,xx,yy,0,"",l};e.lw=layers[l].lw;add(e,role);};
 auto rect=[&](double x,double y,double w,double h,int role=0){line(x,y,x+w,y,outline,role);line(x+w,y,x+w,y+h,outline,role);line(x+w,y+h,x,y+h,outline,role);line(x,y+h,x,y,outline,role);};
 auto arc=[&](double x,double y,double r,double start,double end,int role=0){Entity e={2,x,y,r,start,end,"",outline};add(e,role);};
 auto circ=[&](double x,double y,double r,int role){Entity e={1,x,y,r,0,0,"",outline};add(e,role);};
 // Front view matches reference: four vertical interior ribs and two inclined outer ribs at N=6.
 double cx=frontX,by=frontY,cy=by+p.height/F,rad=ro/F;
 rect(cx-p.length/(2*F),by,p.length/F,p.base/F,1);
 arc(cx,cy,R/F,270-pa/2,270+pa/2,1);arc(cx,cy,rad,270-pa/2,270+pa/2,1);
 for(int sign:{-1,1})line(cx+sign*R/F*sin(aa),cy-R/F*cos(aa),cx+sign*rad*sin(aa),cy-rad*cos(aa),outline,1);
 for(int i=0;i<p.ribs;i++){
  double bx,tx;if(i==0||i==p.ribs-1){int sign=i==0?-1:1;bx=sign*(p.length/2-30)/F;tx=sign*rad*sin(a);}else {tx=p.ribs==3?0:(-std::min(p.length*.31,ro*sin(a)*.8)+2*std::min(p.length*.31,ro*sin(a)*.8)*(i-1)/(p.ribs-3))/F;bx=tx;}
  double ty=cy-sqrt(std::max(0.,rad*rad-tx*tx));double t=p.rib/(2*F);
  line(cx+bx-t,by+p.base/F,cx+tx-t,ty,outline,2);line(cx+bx+t,by+p.base/F,cx+tx+t,ty,outline,2);line(cx+tx-t,ty,cx+tx+t,ty,outline,2);
 }
 // The reference puts fixed and sliding plans together. Each central plan has two rows.
 for(int sliding=0;sliding<2;sliding++){
  double px=sliding?slidingX:fixedX,py=planY;
  rect(px-p.depth/(2*F),py-p.length/(2*F),p.depth/F,p.length/F,3);
  double wx=p.type?(sliding?1:-1)*(p.supportWidth-p.web)/(2*F):0;
  rect(px+wx-p.web/(2*F),py-p.length/(2*F)+20/F,p.web/F,(p.length-40)/F,3);
  for(int i=0;i<p.ribs;i++){double y=(i==0?-p.length/2+30:i==p.ribs-1?p.length/2-30:p.ribs==3?0:-std::min(p.length*.31,ro*sin(a)*.8)+2*std::min(p.length*.31,ro*sin(a)*.8)*(i-1)/(p.ribs-3))/F;rect(px-p.supportWidth/(2*F),py+y-p.rib/(2*F),p.supportWidth/F,p.rib/F,4);}
  for(int row:(p.type?std::vector<int>{-1}:std::vector<int>{-1,1}))for(int i=0;i<p.holes;i++){
   double x=px+row*(p.depth/2-p.edgeY)/F,y=py+(-p.length/2+p.edgeX+(p.length-2*p.edgeX)*i/(p.holes-1))/F,r=p.hole/(2*F);
   int role=sliding?6:5;
   if(!sliding||p.slot==p.hole)circ(x,y,r,role);else {double t=(p.slot-p.hole)/(2*F);arc(x-t,y,r,90,270,role);arc(x+t,y,r,270,450,role);line(x-t,y+r,x+t,y+r,outline,role);line(x-t,y-r,x+t,y-r,outline,role);}
   line(x-r-1,y,x+r+1,y,center);line(x,y-r-1,x,y+r+1,center);
  }
 }
 // Convert the entire sheet uniformly; only the parametric geometry changes with dimensions.
 for(auto&e:d.e){mapEntity(e,[&](double x,double y){return std::make_pair(x*F,y*F);});if(e.kind==1||e.kind==2||e.kind==3||e.kind==4||e.kind==7)e.a*=F;e.width*=F;}
 d.modelCount=d.e.size();d.minX=d.minY=0;d.maxX=594*F;d.maxY=420*F;return d;
}
inline std::string unicodeDxf(const std::string&s){return s;}
inline void writeDXFV2(const Drawing&d,const std::string&path){
 std::ofstream f(path,std::ios::binary);if(!f)throw std::runtime_error("Cannot create DXF");f<<std::setprecision(15);auto g=[&](int c,const auto&v){f<<c<<"\n"<<v<<"\n";};
 std::string prefix=d.type?refPre1:refPre0;auto at=prefix.find("$LTSCALE\n");if(at!=std::string::npos){auto start=prefix.find('\n',at+9)+1;auto end=prefix.find('\n',start);prefix.replace(start,end-start,num(d.plotFactor));}f<<prefix;auto layers=refLayers(d.type);auto styles=refStyles(d.type);auto ltypes=refLtypes(d.type);unsigned handle=0x100000;
 for(const auto&e:d.e){
  const char*type=e.kind==0?"LINE":e.kind==1?"CIRCLE":e.kind==2?"ARC":e.kind==3?"TEXT":e.kind==4?"MTEXT":e.kind==5?"SOLID":e.kind==6?"SPLINE":"ELLIPSE";
  g(0,type);std::ostringstream hex;hex<<std::hex<<handle++;g(5,hex.str());g(330,d.type?refOwner1:refOwner0);g(100,"AcDbEntity");g(8,layers.at(e.layer).name);if(e.color!=256)g(62,e.color);g(48,e.ltscale);if(e.lw!=-1)g(370,e.lw);if(e.lt>=0&&e.lt<(int)ltypes.size())g(6,ltypes[e.lt].name);
  g(100,e.kind==0?"AcDbLine":e.kind==1||e.kind==2?"AcDbCircle":e.kind==3?"AcDbText":e.kind==4?"AcDbMText":e.kind==5?"AcDbTrace":e.kind==6?"AcDbSpline":"AcDbEllipse");
  if(e.kind!=5&&e.kind!=6){g(10,e.x);g(20,e.y);g(30,0);}
  if(e.kind==0){g(11,e.a);g(21,e.b);g(31,0);}
  if(e.kind==1||e.kind==2){g(40,e.a);if(e.kind==2){g(100,"AcDbArc");g(50,fmod(e.b+360,360));g(51,fmod(e.c+360,360));}}
  if(e.kind==3||e.kind==4){g(40,e.a);g(7,styles.at(e.style).name);if(e.kind==4){g(41,e.width);g(71,e.attachment);g(72,5);g(11,cos(e.rotation*PI/180));g(21,sin(e.rotation*PI/180));g(31,0);g(73,1);g(44,1);}else {g(41,e.widthFactor);g(50,e.rotation);}
   std::string value=e.text;size_t at=0;while(value.size()-at>240){size_t n=240;while(n&&((unsigned char)value[at+n]&0xc0)==0x80)n--;g(3,value.substr(at,n));at+=n;}g(1,value.substr(at));if(e.kind==3)g(100,"AcDbText");}
  if(e.kind==5)for(int i=0;i<4;i++){g(10+i,e.points[i*2]);g(20+i,e.points[i*2+1]);g(30+i,0);}
  if(e.kind==6){g(70,e.weights.empty()?8:12);g(71,std::abs(e.degree));g(72,e.knots.size());g(73,e.degree>0?e.points.size()/2:0);g(74,e.degree<0?e.points.size()/2:0);for(auto v:e.knots)g(40,v);for(auto v:e.weights)g(41,v);for(size_t i=0;i<e.points.size();i+=2){g(e.degree<0?11:10,e.points[i]);g(e.degree<0?21:20,e.points[i+1]);g(e.degree<0?31:30,0);}}
  if(e.kind==7){g(11,e.a*cos(e.c*PI/180));g(21,e.a*sin(e.c*PI/180));g(31,0);g(40,e.b);g(41,e.points[0]);g(42,e.points[1]);}
 }
 f<<(d.type?refPost1:refPost0);f.flush();if(!f)throw std::runtime_error("DXF write failed");
}
}
