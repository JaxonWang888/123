// SPDX-License-Identifier: GPL-3.0-or-later
#include <cassert>
#include <cstdlib>
#include <cstring>
extern "C" {
#include "dwg.h"
#include "dwg_api.h"
}
int main(){auto*d=dwg_new_Document(R_2000,0,0);d->header.codepage=39;auto*s=dwg_add_u8_input(d,"尺寸");const unsigned char gbk[]={0xb3,0xdf,0xb4,0xe7,0};assert(!memcmp(s,gbk,sizeof(gbk)));free(s);dwg_free(d);free(d);}
