# Inspect real exported PDFs with an independent renderer; no PDF library in the app.
import json,pathlib,re,subprocess,sys
from PIL import Image,ImageChops
root=pathlib.Path(sys.argv[1]);results=[]
for pdf in sorted(root.glob('*.pdf')):
    raw=pdf.read_bytes();assert raw.startswith(b'%PDF-1.4')
    assert b'/Subtype /Image' not in raw and b'/Font' not in raw
    assert b'0 G 0 g' in raw and not re.search(rb'\b(?:RG|rg|K|k)\b',raw)
    widths=set(re.findall(rb'([0-9.]+) w\n',raw));assert len(widths)>=2
    info=subprocess.check_output(['pdfinfo',str(pdf)],text=True);assert 'Pages:           1' in info
    assert '1683.78 x 1190.55 pts (A2)' in info
    target=root/(pdf.stem+'.pdf-check')
    run=subprocess.run(['pdftoppm','-scale-to','1200','-png','-singlefile',str(pdf),str(target)],capture_output=True,check=True);assert not run.stderr,run.stderr
    png=target.with_suffix('.pdf-check.png');im=Image.open(png).convert('RGB');r,g,b=im.split();assert ImageChops.difference(r,g).getbbox() is None and ImageChops.difference(r,b).getbbox() is None
    assert sum(v*n for v,n in enumerate(r.histogram()))<255*im.width*im.height
    results.append({'file':pdf.name,'bytes':len(raw),'paper':'A2','black_only':True,'vector':True,'lineweights':len(widths)})
assert len(results)==21
(root/'verification-pdf.json').write_text(json.dumps({'passed':True,'files':len(results),'checks':results},indent=2));print(f'{len(results)} vector PDFs passed independent parsing/rendering, page size, black-only pixels and lineweights')
