"""Audit real Windows exports, original drafting tables and decoded DWG geometry."""
from pathlib import Path
import json,sys,subprocess,math,collections,re
import ezdxf
root=Path(__file__).resolve().parents[1];base=Path(sys.argv[1]);reader=sys.argv[2]
def load_reference(i):
 snapshot=json.loads((root/f'reference/styles{i}.json').read_text());doc=ezdxf.new('R2018')
 for tab in ['layers','styles','dimstyles']:
  table=getattr(doc,tab)
  for attrs in snapshot[tab]:
   name=attrs['name'];entry=table.get(name) if name in table else table.new(name)
   for key in list(entry.dxfattribs()):
    if key not in ['handle','owner','name']:entry.dxf.discard(key)
   entry.update_dxf_attribs({k:v for k,v in attrs.items() if k not in ['handle','owner','material_handle','plotstyle_handle','unknown1'] and not k.endswith('_handle')})
 return doc
sources=[load_reference(i) for i in range(2)]
def close(a,b):return math.isclose(a,b,rel_tol=1e-8,abs_tol=2e-6)
def canon(s):return s.replace('\\\\','\\')
def sig(e):
 t=e.dxftype();a=e.dxf
 if t=='LINE':return t,a.layer,*a.start,*a.end
 if t=='CIRCLE':return t,a.layer,*a.center,a.radius
 if t=='ARC':return t,a.layer,*a.center,a.radius,a.start_angle%360,a.end_angle%360
 if t in ('TEXT','MTEXT'):return t,a.layer,a.style,*a.insert,a.char_height if t=='MTEXT' else a.height,canon(e.text if t=='MTEXT' else a.text)
 if t=='SOLID':return t,a.layer,*[v for p in e.wcs_vertices() for v in p]
 if t=='SPLINE':return t,a.layer,a.degree,*[v for p in e.control_points for v in p],*[v for p in e.fit_points for v in p],*e.knots,*e.weights
 if t=='ELLIPSE':return t,a.layer,*a.center,*a.major_axis,a.ratio,a.start_param,a.end_param
 raise AssertionError(t)
def tables(source,actual,native):
 report={}
 for tab,keys in [('layers',['color','linetype','lineweight','plot']),('styles',['font','bigfont','width','height','oblique']),('dimstyles',['dimtxt','dimasz','dimlfac','dimtxsty','dimdec','dimgap'])]:
  assert len(getattr(source,tab))==len(getattr(actual,tab))
  for original in getattr(source,tab):
   got=getattr(actual,tab).get(original.dxf.name)
   for k in keys:
    a=getattr(original.dxf,k);b=getattr(got.dxf,k)
    if k=='dimtxsty' and not a:a='Standard'
    if k=='dimtxsty' and not b:b='Standard'
    if isinstance(a,str) and isinstance(b,str):assert a.casefold()==b.casefold(),(tab,original.dxf.name,k,a,b)
    elif isinstance(a,(int,float)) and isinstance(b,(int,float)):assert close(a,b),(tab,original.dxf.name,k,a,b)
    else:assert a==b,(tab,original.dxf.name,k,a,b)
  report[tab]=len(getattr(actual,tab))
 return report
records=[]
for path in sorted(base.glob('case_*.dwg')):
 _,typ,slide,holes,ribs=path.stem.split('_');typ,holes,ribs=map(int,(typ,holes,ribs));actualpath=path.with_suffix('.readback.dxf')
 p=subprocess.run([reader,str(path),str(actualpath)],capture_output=True);assert p.returncode==0,(path.name,p.stderr[-300:])
 expected=ezdxf.readfile(path.with_suffix('.dxf'));actual=ezdxf.readfile(actualpath)
 assert close(expected.header['$LTSCALE'],actual.header['$LTSCALE'])
 for doc in [expected,actual]:
  audit=doc.audit();assert not audit.errors and not audit.fixes,(path.name,[(x.code,x.message) for x in audit.errors+audit.fixes]);assert doc.units==4
  tables(sources[typ],doc,doc is actual)
 a=list(expected.modelspace());b=list(actual.modelspace());
 # Compare original DWG TV bytes through Python's independent GBK decoder.
 # LibreDWG DXF upconversion does not reliably decode rich MTEXT strings.
 for line in Path(str(actualpath)+'.texts').read_text().splitlines():
  parts=line.split(' ',1);index=int(parts[0]);value=bytes.fromhex(parts[1]).decode('gbk')
  value=re.sub(r'\\U\+([0-9A-Fa-f]{4})',lambda m:chr(int(m[1],16)),value)
  if b[index].dxftype()=='MTEXT':b[index].text=value
  else:b[index].dxf.text=value
 assert len(a)==len(b),(path.name,len(a),len(b))
 for aa,bb in zip(a,b):
  assert close(aa.dxf.ltscale,bb.dxf.ltscale),(path.name,'entity linetype scale',aa.dxf.ltscale,bb.dxf.ltscale)
  assert aa.dxf.color==bb.dxf.color,(path.name,'entity color',aa.dxf.color,bb.dxf.color)
  assert aa.dxf.lineweight==bb.dxf.lineweight,(path.name,'entity lineweight',aa.dxf.lineweight,bb.dxf.lineweight)
  assert aa.dxf.linetype.casefold()==bb.dxf.linetype.casefold(),(path.name,'entity linetype',aa.dxf.linetype,bb.dxf.linetype)
  x,y=sig(aa),sig(bb);assert len(x)==len(y),(aa.dxftype(),len(x),len(y))
  for m,n in zip(x,y):
   if isinstance(m,(int,float)):assert close(m,n),(path.name,aa.dxftype(),m,n)
   else:assert m==n,(path.name,aa.dxftype(),str(m)[:100],str(n)[:100])
 circles=[e for e in b if e.dxftype()=='CIRCLE' and close(e.dxf.radius,27)]
 slots=[e for e in b if e.dxftype()=='ARC' and close(e.dxf.radius,27)]
 total=holes*(1 if typ else 2);assert len(circles)==total,(path.name,len(circles),total);assert len(slots)==total*2
 records.append({'file':path.name,'type':typ,'input_holes_per_row':holes,'actual_holes_per_saddle':total,'ribs':ribs,'entities':len(b),'layers':41,'text_styles':14,'dimension_styles':37,'audit_errors':0,'audit_repairs':0,'geometry_match':True})
assert len(records)==16,len(records)
(base/'verification.json').write_text(json.dumps({'passed':True,'cases':records},indent=2));print('PASS: 16 DWGs; original layers/text styles/primary dimension settings; odd per-row counts; geometry and Unicode roundtrip')
