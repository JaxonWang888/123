# Independent exported-file checks: run after the Windows --self-test suite.
import collections,json,math,pathlib,subprocess,sys
import ezdxf
root=pathlib.Path(sys.argv[1]);reader=pathlib.Path(sys.argv[2]);report=[]
for dwg in sorted(root.glob('case_*.dwg'))+[root/'notch-sample.dwg']:
    if dwg.stem=='notch-sample': type_,holes,ribs=0,3,6
    else:
        _,type_,_,holes,ribs=dwg.stem.split('_');type_,holes,ribs=map(int,(type_,holes,ribs))
    expected_holes=holes*(1 if type_ else 2)
    dxf=dwg.with_suffix('.dxf');converted=dwg.with_suffix('.readback.dxf')
    subprocess.run([str(reader),str(dwg),str(converted)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for path in (dxf,converted):
        doc=ezdxf.readfile(path);audit=doc.audit();assert not audit.errors and not audit.fixes,(path,len(audit.errors),len(audit.fixes))
        ms=doc.modelspace();dims=list(ms.query('DIMENSION'));assert len(dims)>25
        kinds=collections.Counter(e.dxf.dimtype&7 for e in dims);assert all(k in kinds for k in (0,1,3,4,5)),kinds
        assert doc.header['$INSUNITS']==4
        texts=[e.dxf.text for e in ms.query('TEXT')]
        assert not any(any(s in text for s in ('Note','Deg-3','BOM','Ls','***','注')) for text in texts)
        assert not list(ms.query('SOLID LEADER MLEADER TABLE MTEXT INSERT'))
        for dim in dims:
            assert dim.dxf.geometry in doc.blocks
            assert len(doc.blocks[dim.dxf.geometry])>=3
            measured=dim.get_measurement()
            raw=dim.dxf.actual_measurement
            if dim.dxf.dimtype&7==5: raw=math.degrees(raw)
            assert math.isclose(measured,raw,abs_tol=1e-6),(path,measured,raw)
            assert dim.dxf.get('text','') in ('','<>','4×<>',f'{expected_holes}×<>') or path==converted
            assert doc.dimstyles.get(dim.dxf.dimstyle).dxf.dimlfac==1
        lengths=[e.get_measurement() for e in dims if e.dxf.dimtype&7==0]
        # E appears in all 3 orthographic views; Wp, b, a1 in both elevations.
        for actual,minimum in ((1800,3),(400,2),(280,2),(20,2),(560,2),(1400,1),(36,1)):
            assert sum(math.isclose(x,actual,abs_tol=1e-6) for x in lengths)>=minimum,(path,actual,lengths)
        # Native angular entities contain only the two desired vessel/wear-plate angles.
        angles=sorted(round(e.get_measurement(),6) for e in dims if e.dxf.dimtype&7==5)
        assert angles==[120.,126.],angles
        assert sum(e.dxf.dimtype&7==4 for e in dims)==2
        assert sum(e.dxf.dimtype&7==3 for e in dims)==2
        a2_expected=(1800-200)/2
        assert sum(math.isclose(x,a2_expected,abs_tol=1e-6) for x in lengths)>=4
        assert doc.styles.get('Saddle_SimSun').dxf.font=='simsun.ttc'
        assert all(s.dxf.font.lower() in ('arial.ttf','simsun.ttc') for s in doc.styles)
        # Actual fixed holes are circles in the upper half of both plans; vent holes are only 6 mm.
        circles=[e for e in ms.query('CIRCLE') if math.isclose(e.dxf.radius,27,abs_tol=1e-7)]
        assert len(circles)==expected_holes,(path,len(circles),expected_holes)
        if dwg.stem=='notch-sample':
            centre=(594*15*.72,420*15*.52+1400)
            radial=[]
            for edge in ms.query('LINE'):
                a,b=edge.dxf.start,edge.dxf.end
                if a.x<594*15*.5 or a.y<420*15*.5: continue
                if math.isclose((b-a).magnitude,50,abs_tol=1e-7):
                    ar=(a.x-centre[0],a.y-centre[1]);br=(b.x-centre[0],b.y-centre[1])
                    assert abs(ar[0]*br[1]-ar[1]*br[0])<1e-5
                    assert all(math.isclose(x,y,abs_tol=1e-6) for x,y in zip(sorted((math.hypot(*ar),math.hypot(*br))),(1012,1062)))
                    radial.append(edge)
            assert len(radial)==2,(path,len(radial))
        report.append({'file':path.name,'native_dimensions':len(dims),'native_types':dict(kinds),'audit_errors':0,'audit_fixes':0})
(root/'verification-v3.json').write_text(json.dumps({'passed':True,'files':len(report),'checks':report},ensure_ascii=False,indent=2))
print(f'{len(report)} exported DXF/DWG readback documents passed native dimensions, actual measurements, table removal, fonts and anchor-hole checks')
