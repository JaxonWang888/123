#!/usr/bin/env bash
# Build from the distributed corresponding-source bundle. No package downloads.
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "$0")/.." && pwd)"
: "${ZIG:?Set ZIG to the Zig 0.13.0 executable}"
: "${CMAKE:=cmake}"
: "${JOBS:=2}"
export ZIG_GLOBAL_CACHE_DIR="$project_dir/build/zig-global"
export ZIG_LOCAL_CACHE_DIR="$project_dir/build/zig-local"
mkdir -p "$project_dir/build" "$project_dir/dist"
cat > "$project_dir/build/zig-cc" <<'WRAPPER'
#!/bin/sh
exec "$ZIG" cc -target x86_64-windows-gnu "$@"
WRAPPER
chmod +x "$project_dir/build/zig-cc"
export ZIG
cat > "$project_dir/build/windows.cmake" <<TOOLCHAIN
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)
set(CMAKE_C_COMPILER "$project_dir/build/zig-cc")
set(CMAKE_C_COMPILER_WORKS TRUE)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
TOOLCHAIN
"$CMAKE" -S "$project_dir/third_party/libredwg" -B "$project_dir/build/dwg-win" \
 -DCMAKE_PROJECT_INCLUDE="$project_dir/tools/libredwg-export.cmake" -DCMAKE_TOOLCHAIN_FILE="$project_dir/build/windows.cmake" \
 -DBUILD_SHARED_LIBS=OFF -DLIBREDWG_LIBONLY=ON -DLIBREDWG_DISABLE_JSON=ON \
 -DENABLE_LTO=OFF -DDISABLE_WERROR=ON -DBUILD_TESTING=OFF -DCMAKE_BUILD_TYPE=Release
"$CMAKE" --build "$project_dir/build/dwg-win" --target redwg -j "$JOBS"
"$ZIG" c++ -target x86_64-windows-gnu -std=c++17 -O1 -static -municode -Wl,--subsystem,windows \
 -I"$project_dir/third_party/libredwg/include" -I"$project_dir/third_party/libredwg/src" -I"$project_dir/build/dwg-win/src" "$project_dir/src/app.cpp" \
 "$project_dir/build/dwg-win/libredwg.a" -luser32 -lgdi32 -lcomdlg32 -lshell32 -lcomctl32 \
 -o "$project_dir/dist/鞍座图纸生成器.exe"
