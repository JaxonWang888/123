from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
s=['#pragma once\nnamespace saddle {\ninline std::vector<Entity> parseReference(const char* rows){std::istringstream in(rows);std::vector<Entity> out;for(;;){Entity e;if(!(in>>e.kind>>e.x>>e.y>>e.a>>e.b>>e.c>>e.layer>>e.color>>e.style>>e.lt>>e.lw>>e.rotation>>e.width>>e.widthFactor>>e.attachment>>e.degree>>e.ltscale>>std::quoted(e.source)>>std::quoted(e.text)))break;for(auto* list:{&e.points,&e.samples,&e.knots,&e.weights}){size_t n;in>>n;list->resize(n);for(double&v:*list)in>>v;}out.push_back(std::move(e));}return out;}\n']
for t in range(2):
 rows=[]
 for e in json.loads((root/f'tools/reference-records{t}.json').read_text()):
  keys=['kind','x','y','a','b','c','layer','color','style','lt','lw','rotation','width','widthFactor','attachment','degree','ltscale']
  line=' '.join(format(e[k],'.16g') for k in keys)+' '+json.dumps(e['handle'],ensure_ascii=False)+' '+json.dumps(e['text'].replace('\n','\\P'),ensure_ascii=False)
  for k in ['points','samples','knots','weights']:line+=' '+str(len(e[k]))+' '+ ' '.join(format(v,'.16g') for v in e[k])
  rows.append(line)
 s.append(f'inline std::vector<Entity> reference{t}(){{return parseReference(R"REFROWS('+ '\n'.join(rows)+')REFROWS");}\n')
s.append('}\n');(root/'src/reference_data.hpp').write_text(''.join(s))
