"""Generate embedded, self-contained reference geometry and style tables."""
from pathlib import Path
import ezdxf,json,math,re,io
from ezdxf.disassemble import recursive_decompose
from ezdxf import bbox
from ezdxf.addons.importer import Importer
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'src'
def q(s):
 s=str(s).encode('utf8','surrogateescape').decode('utf8','replace')
 return json.dumps(s,ensure_ascii=False)
def vec(v):return '{'+','.join(format(float(x),'.15g') for x in v)+'}'
def floats(v):return [float(x) for x in v]
headers=['#pragma once\nnamespace saddle {\n']
meta=['#pragma once\nnamespace saddle {\n'];native=['#pragma once\nnamespace saddle {\n']
manifest=[]
for typ in range(2):
 doc=ezdxf.readfile(ROOT/f'input/source{typ}.dxf');flat=list(recursive_decompose(doc.modelspace()));bb=bbox.extents(flat);ox,oy=bb.extmin.x,bb.extmin.y
 layers=list(doc.layers);styles=list(doc.styles);ltypes=list(doc.linetypes)
 layerids={x.dxf.name:i for i,x in enumerate(layers)};styleids={x.dxf.name:i for i,x in enumerate(styles)};ltids={x.dxf.name:i for i,x in enumerate(ltypes)}
 headers.append(f'inline std::vector<Entity> reference{typ}(){{std::vector<Entity> out;out.reserve({len(flat)+100});\n')
 # Keep table semantics including all source text/dimension style definitions in DXF.
 clean=ezdxf.new('R2018');imp=Importer(doc,clean);imp.import_tables(['layers','linetypes','styles','dimstyles']);imp.finalize()
 for tabname in ['layers','styles','dimstyles','linetypes']:
  for source_entry in getattr(doc,tabname):
   dest=getattr(clean,tabname).get(source_entry.dxf.name)
   attrs={k:v for k,v in source_entry.dxfattribs().items() if k not in ['handle','owner','material_handle','plotstyle_handle','unknown1'] and not k.endswith('_handle')}
   dest.update_dxf_attribs(attrs)
 clean.units=4;clean.header['$MEASUREMENT']=1
 tmp=ROOT/f'tools/reference-tables{typ}.dxf';clean.saveas(tmp);s=tmp.read_text();a=s.index('ENTITIES\n')+len('ENTITIES\n');b=s.index('  0\nENDSEC',a)
 headers.append('')
 meta.append(f'inline const char* refPre{typ}=R"REFDATA('+s[:a]+')REFDATA";\n')
 meta.append(f'inline const char* refPost{typ}=R"REFDATA('+s[b:]+')REFDATA";\n')
 meta.append(f'inline const char* refOwner{typ}="{clean.modelspace().block_record_handle}";\n')
 records=[]
 def point(p):return [p[0]-ox,p[1]-oy]
 for idx,e in enumerate(flat):
  typname=e.dxftype();rec={'kind':-1,'x':0,'y':0,'a':0,'b':0,'c':0,'text':'','layer':layerids.get(e.dxf.layer,0),'points':[],'knots':[],'samples':[],'style':styleids.get(e.dxf.get('style','Standard'),0) if typname in ['TEXT','MTEXT','ATTRIB'] else 0,'color':e.dxf.get('color',256),'lt':ltids.get(e.dxf.get('linetype','ByLayer'),1),'lw':e.dxf.get('lineweight',-1),'rotation':0,'width':0,'widthFactor':1,'attachment':1,'handle':e.dxf.get('handle') or 'V'+str(idx),'degree':3,'weights':[],'ltscale':e.dxf.get('ltscale',1)}
  if typname=='LINE':rec.update(kind=0,x=e.dxf.start.x-ox,y=e.dxf.start.y-oy,a=e.dxf.end.x-ox,b=e.dxf.end.y-oy)
  elif typname in ['CIRCLE','ARC']:
   c=e.ocs().to_wcs(e.dxf.center);rec.update(kind=1 if typname=='CIRCLE' else 2,x=c.x-ox,y=c.y-oy,a=e.dxf.radius)
   if typname=='ARC':
    sa,ea=e.dxf.start_angle,e.dxf.end_angle
    if e.dxf.extrusion.z<0:sa,ea=180-ea,180-sa
    rec.update(b=sa%360,c=ea%360)
  elif typname in ['MTEXT','TEXT','ATTRIB']:
   ip=e.dxf.insert;raw=e.text if typname=='MTEXT' else e.dxf.text
   raw=raw.encode('utf8','surrogateescape').decode('utf8','replace')
   raw=re.sub(r'\\+(?=[fWHACQPTOSLlp])',lambda m:'\\',raw)
   rec.update(kind=4 if typname=='MTEXT' else 3,x=ip.x-ox,y=ip.y-oy,a=e.dxf.char_height if typname=='MTEXT' else e.dxf.height,text=raw)
   if typname=='MTEXT':rec.update(width=e.dxf.width,attachment=e.dxf.attachment_point,rotation=math.degrees(math.atan2(e.dxf.text_direction.y,e.dxf.text_direction.x)))
   else:rec.update(rotation=e.dxf.get('rotation',0),widthFactor=e.dxf.get('width',1))
  elif typname in ['SOLID','TRACE']:
   pts=[point(e.ocs().to_wcs(e.dxf.get('vtx'+str(j)))) for j in range(4)];rec.update(kind=5,x=pts[0][0],y=pts[0][1],points=sum(pts,[]))
  elif typname=='SPLINE':
   pts=[point(v) for v in e.control_points];fit=[point(v) for v in e.fit_points];samples=[point(v) for v in e.flattening(.04)]
   rec.update(kind=6,points=sum(pts,[]),knots=floats(e.knots),weights=floats(e.weights),degree=e.dxf.degree if pts else -e.dxf.degree,samples=sum(samples,[]));rec['x'],rec['y']=pts[0] if pts else fit[0];rec['points']=sum(pts or fit,[])
  elif typname=='LWPOLYLINE':
   # Preserve bulged polylines by exact line/arc decomposition, including frame.
   for child in e.virtual_entities():
    # Process recursively on a small separate list via append, never mutate input docs.
    child.dxf.layer=e.dxf.layer
    flat.append(child)
   continue
  elif typname=='ELLIPSE':
   # Tiny mechanical detail ellipse; keep its exact centre/axes/parameters.
   c=e.dxf.center;v=e.dxf.major_axis;rec.update(kind=7,x=c.x-ox,y=c.y-oy,a=math.hypot(v.x,v.y),b=e.dxf.ratio,c=math.degrees(math.atan2(v.y,v.x)),points=[e.dxf.start_param,e.dxf.end_param],samples=sum([point(v) for v in e.flattening(.02)],[]))
  else:raise RuntimeError(typname)
  attrs=[rec[k] for k in ['kind','x','y','a','b','c']];out='{'+','.join(format(x,'.15g') if isinstance(x,(int,float)) else str(x) for x in attrs)+','+q(rec['text'])+','+str(rec['layer'])+'}'
  headers.append('{Entity e='+out+';e.color='+str(rec['color'])+';e.style='+str(rec['style'])+';e.lt='+str(rec['lt'])+';e.lw='+str(rec['lw'])+';e.rotation='+str(rec['rotation'])+';e.width='+str(rec['width'])+';e.widthFactor='+str(rec['widthFactor'])+';e.attachment='+str(rec['attachment'])+';e.source='+q(rec['handle'])+';e.points='+vec(rec['points'])+';e.samples='+vec(rec['samples'])+';e.knots='+vec(rec['knots'])+';e.weights='+vec(rec['weights'])+';e.degree='+str(rec['degree'])+';out.push_back(std::move(e));}\n')
  records.append(rec)
 headers.append('return out;}\n')
 # Plain metadata used by the preview, and the native DWG builder.
 meta.append(f'inline std::vector<RefLayer> layers{typ}(){{return {{'+','.join('{'+q(x.dxf.name)+','+str(abs(x.dxf.color))+','+str(x.dxf.lineweight)+','+str(ltids.get(x.dxf.linetype,2))+','+str(x.dxf.get('plot',1))+'}' for x in layers)+'};}\n')
 meta.append(f'inline std::vector<RefStyle> styles{typ}(){{return {{'+','.join('{'+','.join([q(x.dxf.name),q(x.dxf.font),q(x.dxf.bigfont),str(x.dxf.width),str(x.dxf.height),str(x.dxf.oblique),str(x.dxf.last_height)])+'}' for x in styles)+'};}\n')
 meta.append(f'inline std::vector<RefLtype> ltypes{typ}(){{return {{'+','.join('{'+q(x.dxf.name)+','+q(x.dxf.description)+','+vec([t.value for t in x.pattern_tags.tags if t.code==49])+'}' for x in ltypes)+'};}\n')
 # Generate native DIMSTYLE field assignments for every supported field.
 header_path=ROOT/'third_party/libredwg/include/dwg.h'
 if not header_path.exists():header_path=Path('/workspace/saddle-tools/libredwg/include/dwg.h')
 body=header_path.read_text().split('typedef struct _dwg_object_DIMSTYLE\n')[1].split('} Dwg_Object_DIMSTYLE;')[0]
 fieldtypes=dict((name,kind) for kind,name in re.findall(r'(BITCODE_\w+)\s+(DIM\w+)\s*;',body))
 native.append(f'inline void dimstyles{typ}(Dwg_Data*dwg){{\n')
 for style in doc.dimstyles:
  name=style.dxf.name;native.append('{auto* s=getDimstyle(dwg,'+q(name)+');\n')
  for name,kind in fieldtypes.items():
   key=name.lower()
   if not style.dxf.is_supported(key):continue
   value=getattr(style.dxf,key,None)
   if value is None:continue
   if not kind:continue
   if kind in ['BITCODE_T','BITCODE_TV']:native.append('s->'+name+'=dwg_add_u8_input(dwg,'+q(value)+');\n')
   elif kind=='BITCODE_CMC':native.append('s->'+name+'.index='+str(value if 0<=value<=256 else (256 if (int(value)&0xff000000)==0xc0000000 else 3))+';\n')
   elif kind=='BITCODE_H':
    if key=='dimtxsty':native.append('s->DIMTXSTY=tableRef(dwg,'+q(value)+',"STYLE");\n')
    elif key in ['dimltype','dimltex1','dimltex2']:native.append('s->'+name+'=tableRef(dwg,'+q(value)+',"LTYPE");\n')
    elif value:native.append('s->'+name+'=blockRef(dwg,'+q(value)+');\n')
   elif isinstance(value,(int,float)):native.append('s->'+name+'='+str(value)+';\n')
  native.append('}\n')
 native.append('}\n')
 (ROOT/f'tools/reference-records{typ}.json').write_text(json.dumps(records,ensure_ascii=True))
 manifest.append({'type':typ,'layers':len(layers),'styles':len(styles),'dimstyles':len(doc.dimstyles),'entities':len(records),'origin':[ox,oy]})
headers.append('}\n');meta.append('}\n');native.append('}\n');(OUT/'reference_native.hpp').write_text(''.join(native));(OUT/'reference_data.hpp').write_text(''.join(headers));(OUT/'reference_styles.hpp').write_text(''.join(meta));(ROOT/'tools/reference-manifest.json').write_text(json.dumps(manifest,indent=2));print(manifest)

exec((ROOT/"tools/compact_reference.py").read_text())
