# Only the ASCII DXF exporter needs the extended-class serializer.
# The application emits LARGE_RADIAL_DIMENSION; other experimental classes are unused.
set_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/src/out_dxf.c"
             APPEND PROPERTY COMPILE_DEFINITIONS DEBUG_CLASSES)
