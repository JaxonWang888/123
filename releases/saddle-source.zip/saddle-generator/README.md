# Saddle drawing generator

Native Windows x64 offline single executable. Application and corresponding sources are GPL-3.0-or-later. Read dist/使用说明.md for supported geometry and limitations.

## Build

Build host tested: Linux x86_64; Zig 0.13.0; CMake 4.4.4; GNU Make. Runtime target: Windows 10/11 x64.

The source bundle includes third_party/libredwg and its jsmn submodule. No package downloads are performed by the build script. Install the build tools separately, then:

```sh
export ZIG=/absolute/path/to/zig
export CMAKE=/absolute/path/to/cmake
export JOBS=2
bash tools/build.sh
```

The script writes build outputs outside third_party and links LibreDWG and the C++ runtime statically. Windows system DLLs remain system dependencies. `src/template.hpp` contains the complete generated DXF document template; regeneration is not needed to build or run.

LibreDWG commit: f860b0fb76d5f8effb5a70769a3389cb1e0308c8 (unmodified source).
jsmn commit: 85695f3d5903b1cd5b4030efe50db3b4f5f3c928.
The DWG writer uses the library object-construction API and writes R2000, not a relabelled DXF.

## Checks

Portable geometry tests:

```sh
g++ -std=c++17 -O2 -Isrc tests/model_test.cpp -o build/model-test
build/model-test
```

Windows built-in acceptance check (use an existing directory):

```powershell
New-Item -ItemType Directory -Force .\acceptance
& '.\dist\鞍座图纸生成器.exe' --self-test "$((Resolve-Path .\acceptance).Path)"
```

This performs UI state checks and generates 32 DWG/DXF test pairs. `smoke.json` reports the result. `tests/verify_roundtrip.py` independently compares them using ezdxf and a locally built LibreDWG dwg2dxf executable:

```sh
python tests/verify_roundtrip.py /path/to/acceptance /path/to/dwg2dxf
```

The EXE itself does not require Python, Wine, ezdxf, CMake, Zig, or a network connection. Wine and the independent Python parser are only used by the validation host.
