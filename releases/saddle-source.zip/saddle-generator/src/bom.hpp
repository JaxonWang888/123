// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <queue>
#include "native_bom_job.hpp"
namespace saddle {
inline std::vector<BomItem> bomItems(const Params&p){
 std::vector<BomItem> rows;auto add=[&](std::string cn,std::string en,int qty,double station=0){BomItem r;r.number=rows.size()+1;r.cn=cn;r.en=en;r.quantity=qty;r.station=station;rows.push_back(r);};
 add("固定底板","FIXED BASE PLATE",1);add("垫板","WEAR PLATE",2);add("滑动底板","SLIDING BASE PLATE",1);add("腹板","WEB PLATE",2);
 auto ribs=ribShapes(p);std::vector<RibShape> groups;std::vector<int> counts;
 for(size_t i=1;i+1<ribs.size();i++){auto r=ribs[i];size_t j=0;for(;j<groups.size();j++)if(fabs(groups[j].top[0].y-r.top[0].y)<1e-7)break;if(j==groups.size()){groups.push_back(r);counts.push_back(0);}counts[j]+=p.type?2:4;if(r.station>=0)groups[j]=r;}
 std::vector<size_t> order;for(size_t i=0;i<groups.size();i++)order.push_back(i);std::sort(order.begin(),order.end(),[&](size_t a,size_t b){return fabs(groups[a].station)<fabs(groups[b].station);});
 int n=0;for(auto i:order){n++;add("筋板"+std::to_string(n),"RIB PLATE"+std::to_string(n),counts[i],groups[i].station);}
 add("外筋板","OUTSIDE RIB PLATE",4);add("接地板","EARTH LUG",2);auto&r=rows.back();r.code="93201-2406362";r.standard="ASME-EB-04";r.material="SA-240 316/316L";r.unitMass="0.16";r.totalMass="0.32";r.remark="General";return rows;
}
struct BomSegment{Point a,b;bool text=false;bool soft=false;bool earthHeightLine=false;};
inline double bomPointDistance(Point p,Point a,Point b){Point v=b-a;double t=dot(p-a,v)/std::max(1e-12,dot(v,v));return magnitude(p-(a+v*std::max(0.,std::min(1.,t))));}
inline double bomSegmentDistance(Point a,Point b,Point c,Point d){auto cross=[](Point x,Point y){return x.x*y.y-x.y*y.x;};double v=cross(b-a,d-c);if(fabs(v)>1e-9){double t=cross(c-a,d-c)/v,u=cross(c-a,b-a)/v;if(t>=0&&t<=1&&u>=0&&u<=1)return 0;}return std::min({bomPointDistance(a,c,d),bomPointDistance(b,c,d),bomPointDistance(c,a,b),bomPointDistance(d,a,b)});}
inline double bomTextWidth(const Entity&e){bool cn=false;for(auto c:cadCodepoints(e.text))if(c>=0x2e80)cn=true;return cn?cadCodepoints(e.text).size()*e.a*1.1:cadDimensionTextWidth(e);}
inline std::vector<BomSegment> bomObstacles(const Drawing&d){std::vector<BomSegment> out;auto seg=[&](Point a,Point b,bool t=false){out.push_back({a,b,t,false});};for(auto&e:displayEntities(d)){size_t begin=out.size();
 if(e.kind==0)seg({e.x,e.y},{e.a,e.b});
 else if(e.kind==1||e.kind==2){double start=e.kind==1?0:e.b,sweep=e.kind==1?360:fmod(e.c-e.b+720.,360.);if(!sweep)sweep=360;int n=std::max(8,(int)ceil(sweep/4));Point prev={e.x+e.a*cos(start*PI/180),e.y+e.a*sin(start*PI/180)};for(int i=1;i<=n;i++){double a=(start+sweep*i/n)*PI/180;Point q={e.x+e.a*cos(a),e.y+e.a*sin(a)};seg(prev,q);prev=q;}}
 else if(e.kind==3){double w=bomTextWidth(e),h=e.a;Point u={cos(e.rotation*PI/180),sin(e.rotation*PI/180)},v=normal(u),a={e.x,e.y};Point q[4]={a,a+u*w,a+u*w+v*h,a+v*h};for(int i=0;i<4;i++)seg(q[i],q[(i+1)%4],true); // Fill the text box so a leader cannot pass through its interior.
 for(double y=0;y<=h;y+=std::max(h/5,1.))seg(a+v*y,a+v*y+u*w,true);
 }else if(e.kind==5){for(size_t i=2;i+1<e.points.size();i+=2)seg({e.points[i-2],e.points[i-1]},{e.points[i],e.points[i+1]});}
 else if(e.kind==6){auto pts=splineSamples(e);for(size_t i=2;i+1<pts.size();i+=2)seg({pts[i-2],pts[i-1]},{pts[i],pts[i+1]});}
 for(size_t i=begin;i<out.size();i++){out[i].soft=!out[i].text&&e.layer!=2&&e.layer!=4;if(e.kind==0)for(auto&q:d.dimensions)if(q.key=="earth-detail-height")for(auto&g:q.graphics)if(g.kind==0&&g.x==e.x&&g.y==e.y&&g.a==e.a&&g.b==e.b)out[i].earthHeightLine=true;}
 }return out;}
inline saddlecad::NativeBomJob nativeBomJob(const Drawing&d){saddlecad::NativeBomJob j;double F=std::min(1.,d.sheetW*.60/334.9950884538484);j.scale=F*d.ratio;j.x=(d.sheetW-5-334.9950884538484*F)*d.ratio;j.y=(d.sheetH-5-(16.2533333333+8*d.bom.size())*F)*d.ratio;for(auto&r:d.bom)j.rows.push_back({std::to_string(r.number),r.code,r.standard,r.cn+" "+r.en,std::to_string(r.quantity),r.material,"ZD",r.unitMass,r.totalMass,r.remark=="General"?"通用图 General":r.remark,"",""});return j;}
// Display cache only. These primitives are never written to a DWG/DXF.
inline void addBomTable(Drawing&d,const Params&p){
 const double S=d.ratio,F=std::min(1.,d.sheetW*.60/334.9950884538484),K=F*S,T=334.9950884538484;double height=16.2533333333+8*d.bom.size();Point origin={(d.sheetW-5-T*F)*S,(d.sheetH-5-height*F)*S};int layer=0;auto layers=refLayers(p.type);for(size_t i=0;i<layers.size();i++)if(layers[i].name.find("2 明细栏")==0)layer=i;
 auto line=[&](double x,double y,double xx,double yy){Entity e={0,origin.x+x*K,origin.y+y*K,origin.x+xx*K,origin.y+yy*K,0,"",layer};e.role=200;d.e.push_back(e);};
 auto text=[&](double x,double y,std::string value,double h,int role=200){if(value.empty())return;Entity e={3,0,0,h*K,0,0,value,layer};e.widthFactor=.7;e.role=role;e.x=origin.x+x*K-bomTextWidth(e)/2;e.y=origin.y+y*K-e.a/2;d.e.push_back(e);};
 for(double y:{0.,.2533333333,16.2533333333})line(0,y,T,y);for(size_t i=1;i<=d.bom.size();i++)line(0,16.2533333333+8*i,T,16.2533333333+8*i);
 for(double x:{0.,20.,55.,115.,205.,215.,250.,260.,270.,280.,314.9950884538484,324.9950884538484,334.9950884538484})line(x,x==270?8.2533333333:0,x,height);line(260,8.2533333333,280,8.2533333333);
 const double xs[]={10,37.5,85,160,210,232.5,255,297.497544,319.995088,329.995088};const char*cn[]={"件号","代号","图号或标准号","名称及规格","数量","材料","属性","备注","BL","TC"};const char*en[]={"ITEM. NO.","DESCRIPTION","DRAW/STAND.","NAME & SPECIFICATION","QTY","MATERIAL","PTY","REMARK","",""};for(int i=0;i<10;i++){text(xs[i],10.8,cn[i],i==4||i==6?3:4);text(xs[i],5.6,en[i],i==4||i==6?2:3);}text(270,5.6,"质量(kg)",2.5);text(270,2.5,"MASS",2.5);text(265,13.8,"单",2.5);text(265,10.5,"EA",2.5);text(275,13.8,"总",2.5);text(275,10.5,"TOL",2.5);
 for(auto&r:d.bom){double y=16.2533333333+8*(r.number-.5);int role=200+r.number;text(10,y,std::to_string(r.number),3.5,role);text(37.5,y,r.code,3.5,role);text(85,y,r.standard,3.5,role);text(160,y+1.9,r.cn,3.5,role);d.e.back().x=origin.x+115*K+2*S;text(160,y-1.9,r.en,3.5,role);d.e.back().x=origin.x+115*K+2*S;text(210,y,std::to_string(r.quantity),3.5,role);text(232.5,y,r.material,3.5,role);text(255,y,"ZD",3.5,role);text(265,y,r.unitMass,3.5,role);text(275,y,r.totalMass,3.5,role);if(r.remark=="General")text(297.497544,y+1.9,"通用图",3.5,role);text(297.497544,y-(r.remark=="General"?1.9:0),r.remark,3.5,role);}
}
// Route around annotation and dimension obstacles on a one-millimetre paper grid.
inline std::vector<Point> bomRoute(Point start,Point goal,const std::vector<BomSegment>&obs,double S,double W,double H){
 int nx=(int)(W/S)+1,ny=(int)(H/S)+1;std::vector<unsigned char> blocked(nx*ny);auto index=[&](int x,int y){return y*nx+x;};
 for(auto&o:obs)if(!o.soft){int x0=std::max(0,(int)floor(std::min(o.a.x,o.b.x)/S-1)),x1=std::min(nx-1,(int)ceil(std::max(o.a.x,o.b.x)/S+1)),y0=std::max(0,(int)floor(std::min(o.a.y,o.b.y)/S-1)),y1=std::min(ny-1,(int)ceil(std::max(o.a.y,o.b.y)/S+1));for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++)if(bomPointDistance({x*S,y*S},o.a,o.b)<.9*S)blocked[index(x,y)]=1;}
 int ax=std::max(0,std::min(nx-1,(int)round(start.x/S))),ay=std::max(0,std::min(ny-1,(int)round(start.y/S))),bx=std::max(0,std::min(nx-1,(int)round(goal.x/S))),by=std::max(0,std::min(ny-1,(int)round(goal.y/S))),a=index(ax,ay),b=index(bx,by);
 // The first arrow segment is allowed to touch the selected part.
 for(int y=std::max(ay-2,0);y<=std::min(ay+2,ny-1);y++)for(int x=std::max(ax-2,0);x<=std::min(ax+2,nx-1);x++)blocked[index(x,y)]=0;
 blocked[b]=0;std::vector<double> cost(nx*ny,1e30);std::vector<int> prev(nx*ny,-1);using Node=std::pair<double,int>;std::priority_queue<Node,std::vector<Node>,std::greater<Node>> queue;cost[a]=0;queue.push({0,a});int steps=0;
 while(!queue.empty()&&steps++<nx*ny*3){int u=queue.top().second;queue.pop();if(u==b)break;int x=u%nx,y=u/nx;for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++){if(!dx&&!dy)continue;int xx=x+dx,yy=y+dy;if(xx<3||xx>=nx-3||yy<3||yy>=ny-3)continue;int v=index(xx,yy);if(blocked[v]||(dx&&dy&&(blocked[index(xx,y)]||blocked[index(x,yy)])))continue;double next=cost[u]+(dx&&dy?1.41421356237:1);if(next<cost[v]){cost[v]=next;prev[v]=u;queue.push({next+hypot(xx-bx,yy-by),v});}}}
 if(prev[b]<0)return {};std::vector<Point> path={goal};for(int i=b;i!=a&&i>=0;i=prev[i])path.push_back({(i%nx)*S,(i/nx)*S});path.push_back(start);std::reverse(path.begin(),path.end());
 auto clear=[&](Point aa,Point bb,bool first){if(first)aa=aa+unit(bb-aa)*std::min(2.8*S,magnitude(bb-aa)*.8);for(auto&o:obs)if(!o.soft&&bomSegmentDistance(aa,bb,o.a,o.b)<.25*S)return false;return true;};std::vector<Point> simple={start};size_t i=0;while(i+1<path.size()){size_t j=path.size()-1;while(j>i+1&&!clear(path[i],path[j],i==0))j--;if(!clear(path[i],path[j],i==0))return {};simple.push_back(path[j]);i=j;}return simple;
}
inline void addBomBalloons(Drawing&d,const Params&p){
 double S=d.ratio,W=d.sheetW*S,H=d.sheetH*S,fx=.19*W,sx=.405*W,fy=.52*H,px=.72*W,py=.245*H-8*S;auto obs=bomObstacles(d);int layer=0;auto layers=refLayers(p.type);for(size_t i=0;i<layers.size();i++)if(layers[i].name.find("2 明细栏")==0)layer=i;
 auto placement=d.bom;if(placement.size()>6)std::reverse(placement.begin()+4,placement.end()-1);
 for(auto&r:placement){Point tip,preferred;std::vector<Point> bends;int id=r.number;
 if(id==1){tip={fx-p.depth*.4,fy};preferred=tip+Point{-13*S,-6*S};}
 else if(id==2){double ro=p.diameter/2+p.pad;tip={fx-p.padWidth/2,fy+p.height-ro*(1+cos(p.padAngle*PI/360))/2};preferred=tip+Point{-14*S,0};}
 else if(id==3){tip={sx+p.depth*.4,fy};preferred=tip+Point{13*S,-6*S};}
 else if(id==4){double station=p.length*.1;auto ribs=innerRibPositions(p);std::vector<double> edges={-p.length/2};edges.insert(edges.end(),ribs.begin(),ribs.end());edges.push_back(p.length/2);for(size_t i=1;i<edges.size();i++)if(station>=edges[i-1]&&station<=edges[i]){station=(edges[i-1]+edges[i])/2;break;}tip={fx+webAxialCentre(p,0)+p.web/2,py+station};preferred={fx+(p.type?(p.depth/2-p.edgeY)/2:p.holeRowSpacing/4),tip.y};}
 else if(id==(int)d.bom.size()){Point origin={.78*W,.19*H};double G=S/p.earthScale,bw=p.earthWidth*G,bh=p.earthHeight*G,rr=p.earthRadius*G;tip=origin+Point{bw,bh/2+(bh/2-rr)*.6};preferred=tip+Point{20*S,0};}
 else if(id==(int)d.bom.size()-1){auto rib=ribShapes(p).back();tip={px+(rib.base[1].x+rib.top[1].x)/2,fy+(rib.base[1].y+rib.top[1].y)/2};preferred=tip+Point{14*S,0};}
 else {auto ribs=ribShapes(p);auto it=std::min_element(ribs.begin()+1,ribs.end()-1,[&](const RibShape&a,const RibShape&b){return fabs(a.station-r.station)<fabs(b.station-r.station);});tip={px+it->top[1].x,fy+p.base+(it->top[1].y-p.base)*.78};preferred=tip+Point{12*S,-2*S};}
 auto clearCircle=[&](Point c){if(id==4&&magnitude(c-tip)>p.depth/2+20*S)return false;if(id==(int)d.bom.size()&&c.x<tip.x+14*S)return false;if(c.x<8*S||c.y<8*S||c.x>W-8*S||c.y>H-8*S)return false;for(auto&o:obs)if(bomPointDistance(c,o.a,o.b)<5.8*S)return false;return true;};
 auto clearRoute=[&](const std::vector<Point>&route,bool soft){for(size_t i=1;i<route.size();i++){Point a=route[i-1],b=route[i];if(i==1)a=a+unit(b-a)*std::min(2.8*S,magnitude(b-a)*.8);for(auto&o:obs)if(!(id==(int)d.bom.size()&&o.earthHeightLine)&&(!soft||!o.soft)&&bomSegmentDistance(a,b,o.a,o.b)<.25*S)return false;}return true;};
 Point chosen;std::vector<Point> route;bool found=false;for(int trial=0;trial<(id==4?3:1)&&!found;trial++){if(id==4&&trial){tip.y=py+p.length*.45;preferred={fx+(trial==1?1:-1)*(p.depth/2+11*S),py+p.length/2+9*S};}
 for(int attempt=0;attempt<2400&&!found;attempt++){Point c=preferred;if(attempt%1200){int k=attempt%1200-1;double rad=(10+4*(k/48))*S,ang=(k%48)*2*PI/48;c=tip+Point{rad*cos(ang),rad*sin(ang)};}if(!clearCircle(c))continue;Point from=bends.empty()?tip:bends.back(),edge=c-unit(c-from)*(5*S);std::vector<Point> test={tip};test.insert(test.end(),bends.begin(),bends.end());test.push_back(edge);if(clearRoute(test,attempt>=1200)){chosen=c;route=test;found=true;}else if(attempt>=1200&&bends.empty()){for(double step:{6.,12.,24.}){for(int k=0;k<8&&!found;k++){double a=k*PI/4;Point bend=tip+Point{step*S*cos(a),step*S*sin(a)};std::vector<Point> elbow={tip,bend,c-unit(c-bend)*(5*S)};if(clearRoute(elbow,true)){chosen=c;route=elbow;found=true;}}if(found)break;}}}
 if(!found){for(int k=0;k<320&&!found;k++){double ang=(k%32)*2*PI/32,rad=(18+12*(k/32))*S;Point c=tip+Point{rad*cos(ang),rad*sin(ang)};if(!clearCircle(c))continue;Point edge=c-unit(c-tip)*(5*S);auto routeObs=obs;if(id==(int)d.bom.size())for(auto&o:routeObs)if(o.earthHeightLine)o.soft=true;auto path=bomRoute(tip,edge,routeObs,S,W,H);if(!path.empty()&&clearRoute(path,true)){chosen=c;route=path;found=true;}}}
 }
 if(!found)throw std::runtime_error("BOM balloon "+std::to_string(id)+" layout needs more free space; increase the drawing ratio or paper size.");
 Entity circle={1,chosen.x,chosen.y,5*S,0,0,"",layer};circle.role=100+id;d.e.push_back(circle);Entity text={3,0,chosen.y-2.5*S,5*S,0,0,std::to_string(id),layer};text.role=100+id;text.x=chosen.x-cadDimensionTextWidth(text)/2;text.points={chosen.x,chosen.y};d.e.push_back(text);Entity leader={9,tip.x,tip.y,std::min(2.5*S,magnitude(route[1]-tip)*.8),0,0,"",layer};leader.role=100+id;for(auto q:route){leader.points.push_back(q.x);leader.points.push_back(q.y);}auto g=leaderGraphics(leader);d.e.insert(d.e.end(),g.begin(),g.end());d.balloons.push_back({id,chosen,tip,route});
 // Add only the new geometry to the obstacle set.
 Drawing extra;extra.e.push_back(circle);extra.e.push_back(text);extra.e.insert(extra.e.end(),g.begin(),g.end());auto more=bomObstacles(extra);obs.insert(obs.end(),more.begin(),more.end());
 }
}
inline Drawing generate(const Params&p){auto rows=bomItems(p);auto base=generateGeometry(p);double F=std::min(1.,base.sheetW*.60/334.9950884538484),bottom=base.sheetH-5-(16.2533333333+8*rows.size())*F;double free=bottom-.52*base.sheetH-18;double need=std::max(base.requiredRatio,free>0?p.height/free:1000.);const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};double recommended=1000;for(double s:scales)if(s>=need){recommended=s;break;}std::string last;std::vector<double> candidates;if(p.scale)candidates={p.scale};else candidates.assign(std::begin(scales),std::end(scales));for(double s:candidates){if(s<(p.scale?p.scale:recommended))continue;if(p.scale&&s!=p.scale)continue;try{Params q=p;q.scale=s;Drawing d=generateGeometry(q);d.requiredRatio=need;d.recommended=p.scale?recommended:s;d.bom=rows;addBomTable(d,p);addBomBalloons(d,p);d.modelCount=d.e.size()+d.dimensions.size()-std::count_if(d.e.begin(),d.e.end(),[](const Entity&e){return e.role>=200&&e.role<300;});return d;}catch(const std::runtime_error&e){last=e.what();}}throw std::runtime_error(last.empty()?"BOM layout exceeds paper area.":last);}
}
