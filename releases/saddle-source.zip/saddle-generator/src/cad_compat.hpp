// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <cstdio>
#include <string>
#include <vector>
namespace saddle {
inline std::vector<unsigned> cadCodepoints(const std::string&s){std::vector<unsigned> out;for(size_t i=0;i<s.size();){unsigned c=(unsigned char)s[i++];if(c>=128){int n=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:3;c&=n==1?31:n==2?15:7;while(n--&&i<s.size())c=(c<<6)|((unsigned char)s[i++]&63);}out.push_back(c);}return out;}
inline bool cadHasChinese(const std::string&s){for(unsigned c:cadCodepoints(s))if((c>=0x2e80&&c<=0x9fff)||(c>=0xf900&&c<=0xfaff))return true;return false;}
// ASCII Unicode escapes are interpreted by AutoCAD TEXT/MTEXT independently
// of the machine's ANSI codepage or the file's legacy DWG container.
inline std::string cadUnicodeText(const std::string&s){std::string out;for(unsigned c:cadCodepoints(s)){if(c<128)out+=(char)c;else{char escaped[16];if(c>0xffff){unsigned high=0xd800+((c-0x10000)>>10),low=0xdc00+((c-0x10000)&1023);snprintf(escaped,sizeof(escaped),"\\U+%04X",high);out+=escaped;c=low;}snprintf(escaped,sizeof(escaped),"\\U+%04X",c);out+=escaped;}}return out;}
// Arial regular advance widths (1000 units/em, cap height 716). Dimension
// cache TEXT is baseline-left; native DIMENSION stores a text-box centre.
inline double cadDimensionTextWidth(const Entity&e){double sum=0;for(unsigned c:cadCodepoints(plainMtext(e.text))){if(c>='0'&&c<='9')sum+=556;else if(c=='.'||c==' ')sum+=278;else if(c=='('||c==')'||c=='-')sum+=333;else if(c=='R')sum+=722;else if(c==0x00d7||c==0x00b1)sum+=584;else if(c==0x00b0)sum+=400;else if(c==0x00d8)sum+=778;else sum+=556;}return sum/716*e.a*e.widthFactor;}
inline Point cadDimensionTextCentre(const Dimension&q){for(auto it=q.graphics.rbegin();it!=q.graphics.rend();++it)if(it->kind==3){double a=it->rotation*PI/180,w=cadDimensionTextWidth(*it);return {it->x+cos(a)*w/2-sin(a)*it->a/2,it->y+sin(a)*w/2+cos(a)*it->a/2};}return q.textAt;}
}
