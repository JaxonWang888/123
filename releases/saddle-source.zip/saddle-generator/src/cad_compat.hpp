// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "dimension_job.hpp"
#include <cstdio>
#include <string>
#include <vector>
namespace saddle {
inline bool cadHasChinese(const std::string&s){for(unsigned c:cadCodepoints(s))if((c>=0x2e80&&c<=0x9fff)||(c>=0xf900&&c<=0xfaff))return true;return false;}
// ASCII Unicode escapes are interpreted by AutoCAD TEXT/MTEXT independently
// of the machine's ANSI codepage or the file's legacy DWG container.
inline std::string cadUnicodeText(const std::string&s){std::string out;for(unsigned c:cadCodepoints(s)){if(c<128)out+=(char)c;else{char escaped[16];if(c>0xffff){unsigned high=0xd800+((c-0x10000)>>10),low=0xdc00+((c-0x10000)&1023);snprintf(escaped,sizeof(escaped),"\\U+%04X",high);out+=escaped;c=low;}snprintf(escaped,sizeof(escaped),"\\U+%04X",c);out+=escaped;}}return out;}
// Arial regular advance widths (1000 units/em, cap height 716). Dimension
// cache TEXT is baseline-left; native DIMENSION stores a text-box centre.
inline Point cadDimensionTextCentre(const Dimension&q){for(auto it=q.graphics.rbegin();it!=q.graphics.rend();++it)if(it->kind==3){double a=it->rotation*PI/180,w=cadDimensionTextWidth(*it);return {it->x+cos(a)*w/2-sin(a)*it->a/2,it->y+sin(a)*w/2+cos(a)*it->a/2};}return q.textAt;}
inline saddlecad::DimensionJob nativeDimensionJob(const Drawing&d){saddlecad::DimensionJob j;j.dimensions=(unsigned)d.dimensions.size();for(auto&q:d.dimensions)if(q.tolerance>0||q.textPositionExplicit){auto c=cadDimensionTextCentre(q);saddlecad::DimensionTask t;t.key=q.key;t.first={q.first.x,q.first.y,0};t.second={q.second.x,q.second.y,0};t.text={c.x,c.y,0};t.tolerance=q.tolerance;t.position=q.textPositionExplicit;j.tasks.push_back(t);}return j;}
}
