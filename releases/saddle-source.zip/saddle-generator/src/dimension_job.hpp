// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <array>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <stdexcept>
namespace saddlecad {
struct DimensionTask {std::string key;std::array<double,3> first{},second{},text{};double tolerance=0;bool position=false;};
struct DimensionJob {unsigned dimensions=0;std::vector<DimensionTask> tasks;};
inline std::string writeDimensionJob(const DimensionJob&j){std::ostringstream s;s<<"SADDLE_DIMENSIONS_V34\n"<<j.dimensions<<' '<<j.tasks.size()<<'\n'<<std::setprecision(17);for(auto&t:j.tasks){s<<std::quoted(t.key)<<' '<<t.tolerance<<' '<<t.position;for(auto*p:{&t.first,&t.second,&t.text})for(double v:*p)s<<' '<<v;s<<'\n';}return s.str();}
inline DimensionJob readDimensionJob(const std::string&data){std::istringstream s(data);std::string magic;std::getline(s,magic);DimensionJob j;unsigned n=0;if(magic!="SADDLE_DIMENSIONS_V34"||!(s>>j.dimensions>>n)||!j.dimensions||j.dimensions>10000||n>j.dimensions)throw std::runtime_error("Invalid dimension job header");for(unsigned i=0;i<n;i++){DimensionTask t;if(!(s>>std::quoted(t.key)>>t.tolerance>>t.position)||t.key.empty()||t.key.size()>80||!std::isfinite(t.tolerance)||t.tolerance<0||t.tolerance>100)throw std::runtime_error("Invalid dimension task");for(auto*p:{&t.first,&t.second,&t.text})for(double&v:*p)if(!(s>>v)||!std::isfinite(v)||std::abs(v)>1e9)throw std::runtime_error("Invalid dimension point");if(!t.position&&t.tolerance==0)throw std::runtime_error("Empty dimension task");j.tasks.push_back(t);}s>>std::ws;if(!s.eof())throw std::runtime_error("Unexpected dimension task data");return j;}
inline bool sameDimensionPoint(const std::array<double,3>&a,const std::array<double,3>&b){for(int i=0;i<3;i++)if(std::abs(a[i]-b[i])>1e-5)return false;return true;}
inline bool matchesDimensionTask(const DimensionTask&t,const std::array<double,3>&a,const std::array<double,3>&b){return (sameDimensionPoint(t.first,a)&&sameDimensionPoint(t.second,b))||(sameDimensionPoint(t.first,b)&&sameDimensionPoint(t.second,a));}
}
