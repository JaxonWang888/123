// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "model.hpp"
extern "C" {
#include "dwg.h"
#include "dwg_api.h"
}
namespace saddle {
inline void writeDWG(const Drawing&d,const std::string&path){
 Dwg_Data*dwg=dwg_new_Document(R_2000,0,0);if(!dwg)throw std::runtime_error("DWG allocation failed");
 try {
 dwg->header_vars.INSUNITS=4;dwg->header_vars.MEASUREMENT=1;
 dwg->header_vars.EXTMIN={d.minX,d.minY,0};dwg->header_vars.EXTMAX={d.maxX,d.maxY,0};
 auto* center=dwg_add_LTYPE(dwg,"CENTER");center->description=dwg_add_u8_input(dwg,"Center line");center->alignment=65;center->pattern_len=20;center->numdashes=4;center->dashes=(Dwg_LTYPE_dash*)calloc(4,sizeof(Dwg_LTYPE_dash));double lengths[]={12,-3,2,-3};
 for(int i=0;i<4;i++){center->dashes[i].parent=center;center->dashes[i].length=lengths[i];center->dashes[i].scale=1;}
 unsigned long centerHandle=dwg->object[center->parent->objid].handle.value;
 const char* names[]={"OUTLINE","CENTER","DIMENSION","BORDER"};unsigned long handles[4];
 for(int i=0;i<4;i++){auto*l=dwg_add_LAYER(dwg,names[i]);if(!l)throw std::runtime_error("DWG layer allocation failed");l->color.index=i==1?3:i==2?2:7;l->ltype=dwg_add_handleref(dwg,5,i==1?centerHandle:dwg->header_vars.LTYPE_CONTINUOUS->absolute_ref,nullptr);handles[i]=dwg->object[l->parent->objid].handle.value;}
 for(const auto&e:d.e){
  auto*obj=dwg_model_space_object(dwg);auto*b=obj->tio.object->tio.BLOCK_HEADER;
  dwg_point_3d p={e.x,e.y,0},q={e.a,e.b,0};Dwg_Object_Entity*parent=nullptr;
  if(e.kind==0){auto*x=dwg_add_LINE(b,&p,&q);if(x)parent=x->parent;}
  if(e.kind==1){auto*x=dwg_add_CIRCLE(b,&p,e.a);if(x)parent=x->parent;}
  if(e.kind==2){auto*x=dwg_add_ARC(b,&p,e.a,e.b*PI/180,e.c*PI/180);if(x)parent=x->parent;}
  if(e.kind==3){auto*x=dwg_add_TEXT(b,e.text.c_str(),&p,e.a);if(x)parent=x->parent;}
  if(!parent)throw std::runtime_error("DWG entity allocation failed");
  parent->layer=dwg_add_handleref(dwg,5,handles[e.layer],nullptr);
 }
 int err=dwg_write_file(path.c_str(),dwg);if(err)throw std::runtime_error("DWG write failed, code="+std::to_string(err));
 dwg_free(dwg);free(dwg);
 }catch(...){dwg_free(dwg);free(dwg);throw;}
}
}
