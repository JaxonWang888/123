// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <stdexcept>
namespace saddle {
// LibreDWG's binary jogged-radius fields are correct. Its ASCII DXF writer swaps
// the chord (13) and jog (15) point codes; normalize only that subclass.
inline void normalizeJoggedDXF(const std::string&path){
 std::ifstream in(path,std::ios::binary);if(!in)throw std::runtime_error("Cannot read DXF");std::vector<std::string> lines;std::string line;while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();lines.push_back(line);}in.close();bool active=false,version=false,found=false;
 for(size_t i=0;i+1<lines.size();i+=2){int code=std::stoi(lines[i]);auto&value=lines[i+1];if(version){if(value<"AC1018")value="AC1018";version=false;}if(code==9&&value=="$ACADVER")version=true;if(code==0)active=false;if(code==100&&value=="AcDbRadialDimensionLarge"){active=true;found=true;}if(active){if(code==13||code==23||code==33)lines[i]=std::to_string(code+2);else if(code==15||code==25||code==35)lines[i]=std::to_string(code-2);}}
 if(!found)throw std::runtime_error("Jogged radius missing from DXF export");std::ofstream out(path,std::ios::binary|std::ios::trunc);for(auto&s:lines)out<<s<<"\r\n";if(!out)throw std::runtime_error("Cannot save DXF");
}
}
