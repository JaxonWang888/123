// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
inline std::wstring localError(const std::string&s){
 const std::pair<const char*,const wchar_t*> messages[]={
 {"Re-enter inner rib centre spacings after changing the rib count.",L"筋板数量已改变，请重新填写内筋板中心距。"},
 {"Inner rib centre spacing must exceed rib thickness.",L"内筋板中心距必须大于筋板厚度。"},
 {"Wear plate angle must be between contact angle and 180 degrees.",L"垫板包角 θw 不得小于外筋板包角 θ，且不超过 180°。"},
 {"Wear plate corner radius must fit within its width.",L"垫板圆角半径须大于零，且直径须小于垫板宽度。"},
 {"Vent offset must lie between the hole radius and half the wear plate width.",L"排气孔距边缘 a1 须大于孔半径、小于垫板半宽。"},
 {"Vent end offset is invalid.",L"排气孔端部偏移 B 超出可布置范围。"},
 {"Outer rib setback is invalid.",L"外筋板边缘 X 超出可布置范围。"},
 {"Inner rib positions must fit between the outer ribs and under the wear plate.",L"内筋板位置超出外筋板之间或垫板下方的范围，请减小 di。"},
 {"Rib does not intersect wear plate.",L"筋板无法与垫板相交，请调整高度、包角或间距。"},
 {"All parameters must be finite.",L"请输入有效的有限数字。"},
 {"Vessel diameter must be 100..20000 mm.",L"容器外径须为 100～20000 mm。"},
 {"Centre height must exceed R + base + wear plate.",L"中心高度须大于容器半径 + 底板厚度 + 垫板厚度，且不超过外径的三倍。"},
 {"Contact angle must be 60..160 degrees.",L"鞍座包角须为 60～160 度。"},
 {"Base length must be 0.4..1.5 times vessel diameter.",L"底板长度须在容器外径的 0.4～1.5 倍内。"},
 {"Base depth must be 80..5000 mm.",L"底板轴向宽度须为 80～5000 mm。"},
 {"Plate thickness is out of range.",L"板厚超出支持范围：底板 4～200，腹板/筋板 4～100，垫板 3～100 mm。"},
 {"Body width plus weld clearance must fit base.",L"本体宽度须大于腹板厚度 + 20，且底板宽度须容纳本体宽度 + 两侧焊脚 + 20 mm。"},
 {"Weld leg must be 3..30 mm.",L"焊脚高度须为 3～30 mm。"},
 {"Wear plate width must be at least body width + 2*weld + 40.",L"垫板宽度不得小于本体宽度 + 2 × 焊脚高度 + 40 mm，且不超过底板宽度。"},
 {"Anchor rows need more clearance from rib/weld (increase base width or reduce edge distance/body width).",L"地脚孔与筋板/焊脚间隙不足：请增大底板宽度，或减小侧边距/本体宽度。"},
 {"Rib count must be 2..20 (total transverse stations).",L"筋板数量须为 2～20（横向总片数）。"},
 {"Hole count per row must be 2..40.",L"每排孔数须为 2～40；中置腹板总数为输入值 × 2。"},
 {"Hole diameter must be 6..150; slot length >= diameter.",L"孔径须为 6～150 mm，滑动孔总长不得小于孔径。"},
 {"Anchor edge distance is invalid.",L"孔边距无效：中心边距须大于对应孔半径/半长 + 5，且小于相应底板半长/半宽。"},
 {"Anchor holes overlap along base length.",L"孔沿底板长度方向重叠或间距不足，请减小孔数/孔径或增大底板长度。"},
 {"Anchor rows overlap.",L"地脚孔排间距不足。"},
 {"Rib count/thickness does not fit base.",L"筋板数量/厚度超出底板可布置范围。"},
 {"Scale denominator must be 1..1000, or automatic.",L"比例分母须为 1～1000，或选择自动推荐。"}};
 for(auto&m:messages)if(s==m.first)return m.second;return wide(s);
}
