// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "text_metrics.hpp"
namespace saddle {
inline Point operator+(Point a,Point b){return {a.x+b.x,a.y+b.y};}
inline Point operator-(Point a,Point b){return {a.x-b.x,a.y-b.y};}
inline Point operator*(Point a,double b){return {a.x*b,a.y*b};}
inline double dot(Point a,Point b){return a.x*b.x+a.y*b.y;}
inline double magnitude(Point a){return hypot(a.x,a.y);}
inline Point unit(Point a){double l=magnitude(a);return l?a*(1/l):Point{1,0};}
inline Point normal(Point a){return {-a.y,a.x};}
inline std::vector<Entity> leaderGraphics(const Entity&e){
 std::vector<Entity> out;for(size_t i=2;i+1<e.points.size();i+=2){Entity line={0,e.points[i-2],e.points[i-1],e.points[i],e.points[i+1],0,"",e.layer};line.lw=e.lw;line.role=e.role;out.push_back(line);}
 if(e.points.size()>=4){Point p={e.points[0],e.points[1]},direction=unit(Point{e.points[2],e.points[3]}-p),back=p+direction*e.a,side=normal(direction)*(e.a*.2);Entity arrow={5,p.x,p.y,0,0,0,"",e.layer};arrow.points={p.x,p.y,back.x+side.x,back.y+side.y,back.x-side.x,back.y-side.y,back.x-side.x,back.y-side.y};arrow.role=e.role;out.push_back(arrow);}return out;
}
inline std::vector<Entity> displayEntities(const Drawing&d){std::vector<Entity> out;for(const auto&e:d.e){if(e.kind==9){auto graphics=leaderGraphics(e);out.insert(out.end(),graphics.begin(),graphics.end());}else out.push_back(e);}for(auto&dim:d.dimensions)out.insert(out.end(),dim.graphics.begin(),dim.graphics.end());return out;}
inline const std::vector<std::string>& boltSpecs(){static const std::vector<std::string> v={"M16","M20","M24","M27","M30","M36","M42","M48","M52","M56","M64","M72","M80","M90","M100"};return v;}
inline const std::vector<std::string>& boltMaterials(){static const std::vector<std::string> v={"Q235B","Q355B","35","45","40Cr","ASTM A193 B7","ASTM A193 B8","ASTM A193 B8M","ASTM F1554 Gr.55"};return v;}
inline const std::vector<std::string>& boltCoatings(){static const std::vector<std::string> v={"无涂层","热浸镀锌","电镀锌","锌铝涂层（达克罗）","发黑","磷化"};return v;}
inline const std::vector<std::string>& boltCoatingsEnglish(){static const std::vector<std::string> v={"Uncoated","Hot-dip galvanized","Zinc plated","Zinc-aluminium coating","Black oxide","Phosphated"};return v;}
inline std::vector<double> splineSamples(const Entity&e){
 int p=e.degree,n=(int)e.points.size()/2-1;std::vector<double> out;
 for(int step=0;step<=100;step++){double u=e.knots[p]+(e.knots[n+1]-e.knots[p])*step/100.;int k=n;if(step<100){k=p;while(k<n&&u>=e.knots[k+1])k++;}std::vector<Point> d(p+1);for(int j=0;j<=p;j++)d[j]={e.points[2*(k-p+j)],e.points[2*(k-p+j)+1]};for(int r=1;r<=p;r++)for(int j=p;j>=r;j--){int i=k-p+j;double denom=e.knots[i+p-r+1]-e.knots[i],a=denom?(u-e.knots[i])/denom:0;d[j]=d[j-1]*(1-a)+d[j]*a;}out.insert(out.end(),{d[p].x,d[p].y});}return out;
}
inline int spacingCount(int ribs){return std::max(0,(ribs-2)/2);}
inline std::vector<double> innerRibPositions(const Params&p){
 const int n=p.ribs-2;std::vector<double> v;if(n<=0)return v;
 if((int)p.ribSpacings.size()!=spacingCount(p.ribs))throw std::runtime_error("Re-enter inner rib centre spacings after changing the rib count.");
 for(double x:p.ribSpacings)if(!std::isfinite(x)||x<=p.rib)throw std::runtime_error("Inner rib centre spacing must exceed rib thickness.");
 double x=0;int start=0;if(n%2)v.push_back(0);else {x=p.ribSpacings[0]/2;start=1;v.push_back(-x);v.push_back(x);}
 for(int i=start;i<(int)p.ribSpacings.size();i++){x+=p.ribSpacings[i];v.push_back(-x);v.push_back(x);}
 std::sort(v.begin(),v.end());return v;
}
struct RibShape {Point base[2],top[2],contact,direction;double station=0,footThickness=0;};
inline std::vector<double> anchorStations(const Params&p){
 if((int)p.holeDistances.size()!=p.holes/2)throw std::runtime_error("Enter one positive centre distance for each symmetric hole pair.");
 std::vector<double> out;if(p.holes%2)out.push_back(0);double previous=0;
 for(double x:p.holeDistances){if(!std::isfinite(x)||x<=previous)throw std::runtime_error("Hole centre distances must be positive and strictly increasing.");out.push_back(-x);out.push_back(x);previous=x;}
 std::sort(out.begin(),out.end());return out;
}
inline double ribAxialWidth(const Params&p){return p.supportWidth-(p.type?p.web:0);}
inline double ribAxialCentre(const Params&p,int view){return p.type?(view?-1:1)*p.web/2:0;}
inline double webAxialCentre(const Params&p,int view){return p.type?(view?1:-1)*ribAxialWidth(p)/2:0;}
inline void upgradeLegacySaddleWidth(Params&p){if(p.type)p.supportWidth+=p.web;}
inline std::vector<RibShape> ribShapes(const Params&p){
 double ro=p.diameter/2+p.pad,theta=p.angle*PI/360,top=p.height-ro*cos(theta),outerFace=p.length/2-p.outerSetback;
 Point contact={ro*sin(theta),top};double innerX=outerFace-p.rib;
 for(int i=0;i<30;i++){Point direction=unit(contact-Point{innerX,p.base});innerX=outerFace-p.rib/direction.y;}
 Point innerBase={innerX,p.base},direction=unit(contact-innerBase),outerTop=contact-normal(direction)*p.rib;
 RibShape right;right.base[0]=innerBase;right.base[1]={outerFace,p.base};right.top[0]=contact;right.top[1]=outerTop;right.contact=contact;right.direction=direction;right.station=(innerX+outerFace)/2;right.footThickness=outerFace-innerX;
 RibShape left=right;for(int j=0;j<2;j++){left.base[j].x*=-1;left.top[j].x*=-1;}left.contact.x*=-1;left.direction.x*=-1;left.station*=-1;
 std::vector<RibShape> out={left};
 for(double x:innerRibPositions(p)){double x0=x-p.rib/2,x1=x+p.rib/2,y0=p.height-sqrt(std::max(0.,ro*ro-x0*x0)),y1=p.height-sqrt(std::max(0.,ro*ro-x1*x1));double y=std::min(y0,y1);RibShape q;q.base[0]={x0,p.base};q.base[1]={x1,p.base};q.top[0]={x0,y};q.top[1]={x1,y};q.contact=y0<y1?q.top[0]:q.top[1];q.direction={0,1};q.station=x;q.footThickness=p.rib;out.push_back(q);}
 out.push_back(right);return out;
}
inline std::vector<std::string> validateV3(const Params&p){
 std::vector<std::string> errors;auto chk=[&](bool ok,const char*text){if(!ok)errors.push_back(text);};
 chk(p.boltSpecIndex>=0&&p.boltSpecIndex<(int)boltSpecs().size()&&p.boltMaterialIndex>=0&&p.boltMaterialIndex<(int)boltMaterials().size()&&p.boltCoatingIndex>=0&&p.boltCoatingIndex<(int)boltCoatings().size(),"Select a bolt specification, material and coating.");
 for(double x:{p.padShellWeld,p.diameter,p.height,p.length,p.depth,p.base,p.web,p.rib,p.pad,p.padWidth,ribAxialWidth(p),p.hole,p.slot,p.scale,p.angle,p.padAngle,p.fillet,p.ventOffset,p.ventDiameter,p.outerSetback,p.holeRowSpacing})if(!std::isfinite(x)){errors.push_back("All parameters must be finite.");return errors;}
 chk(p.padShellWeld>0&&p.padShellWeld<=1000,"Enter a positive wear-plate to shell weld size.");
 chk(p.type==0||p.type==1,"Unknown saddle type.");chk(p.ribs>=2&&p.ribs<=20,"Rib count must be 2..20 (total transverse stations).");chk(p.holes>=1&&p.holes<=40,"Hole count per row must be 1..40.");
 chk(p.diameter>=100&&p.diameter<=20000,"Vessel diameter must be 100..20000 mm.");chk(p.height>p.diameter/2+p.pad+p.base,"Centre height must exceed R + base + wear plate.");
 chk(p.angle>=60&&p.angle<=160,"Contact angle must be 60..160 degrees.");chk(p.padAngle>=p.angle&&p.padAngle<=180,"Wear plate angle must be between contact angle and 180 degrees.");
 chk(p.length>p.rib*3&&p.length<=30000&&p.depth>p.web&&p.depth<=5000,"Base dimensions are invalid.");chk(p.base>0&&p.web>0&&p.rib>0&&p.pad>0,"Plate thickness is out of range.");
 chk(p.supportWidth>p.web&&p.supportWidth<p.depth,"Body width plus weld clearance must fit base.");chk(p.padWidth>=p.supportWidth&&p.padWidth<=p.depth,"Wear plate width must contain the rib and web projections.");
 chk(p.fillet>0&&2*p.fillet<p.padWidth,"Wear plate corner radius must fit within its width.");chk(p.ventDiameter>0&&p.ventOffset>p.ventDiameter/2&&p.ventOffset<p.padWidth/2,"Vent offset must lie between the hole radius and half the wear plate width.");
 chk(p.outerSetback>=0&&p.outerSetback+p.rib<p.length/2,"Outer rib setback is invalid.");chk(p.hole>0&&p.slot>=p.hole,"Hole diameter must be 6..150; slot length >= diameter.");chk(p.paper>=0&&p.paper<5,"Unknown paper.");chk(p.scale==0||(p.scale>=1&&p.scale<=1000),"Scale denominator must be 1..1000, or automatic.");
 if(!errors.empty())return errors;
 try{
  auto ribs=ribShapes(p);auto ys=anchorStations(p);auto inner=innerRibPositions(p);
  double limit=std::min(ribs.back().base[0].x,p.diameter/2*sin(p.angle*PI/360))-p.rib;
  chk(inner.empty()||inner.back()<limit,"Inner rib positions must fit between the outer ribs and under the wear plate.");
  std::vector<double> rows=p.type?std::vector<double>{0}:std::vector<double>{-p.holeRowSpacing/2,p.holeRowSpacing/2};
  chk(p.type||p.holeRowSpacing>p.slot,"Anchor rows overlap.");
  for(double x:rows)for(double y:ys){
   chk(std::abs(x)+p.slot/2<p.depth/2&&std::abs(y)+p.hole/2<p.length/2,"Anchor hole extends outside the base.");
   double halfStraight=(p.slot-p.hole)/2;
   auto collision=[&](double loX,double hiX,double loY,double hiY){double dx=std::max({loX-(x+halfStraight),(x-halfStraight)-hiX,0.}),dy=std::max({loY-y,y-hiY,0.});return hypot(dx,dy)<p.hole/2-1e-7;};
   double wx=webAxialCentre(p,0),rx=ribAxialCentre(p,0);
   double webEnd=ribs.back().base[0].x;
   chk(!collision(wx-p.web/2,wx+p.web/2,-webEnd,webEnd),"Anchor hole interferes with the web.");
   for(auto&r:ribs)chk(!collision(rx-ribAxialWidth(p)/2,rx+ribAxialWidth(p)/2,r.station-r.footThickness/2,r.station+r.footThickness/2),"Anchor hole interferes with a rib.");
  }
  for(size_t i=1;i<ys.size();i++)chk(ys[i]-ys[i-1]>=p.hole,"Anchor holes overlap along base length.");
 }catch(const std::exception&e){errors.push_back(e.what());}return errors;
}
inline void dimensionGraphics(Dimension&dim,double h,int layer){
 auto line=[&](Point a,Point b){dim.graphics.push_back({0,a.x,a.y,b.x,b.y,0,"",layer});};
 auto arrow=[&](Point tip,Point dir){dir=unit(dir);Point side=normal(dir)*(h*.19),back=tip+dir*(h*2.5/3.5);
  Entity e={5,tip.x,tip.y,0,0,0,"",layer};e.points={tip.x,tip.y,back.x+side.x,back.y+side.y,back.x-side.x,back.y-side.y,back.x-side.x,back.y-side.y};dim.graphics.push_back(e);};
 Point a=dim.first,b=dim.second;std::ostringstream formatted;formatted<<std::fixed<<std::setprecision(1)<<(dim.measurement*dim.measurementScale);std::string value=formatted.str();if(value.size()>2&&value.substr(value.size()-2)==".0")value.resize(value.size()-2);
 if(dim.type==2||dim.type==3)value=(dim.type==2?"R":"%%c")+value;
 if(dim.type==4)value+="°";
 if(dim.tolerance>0)value+="%%p"+num(dim.tolerance)+".0";
 value=dim.prefix+value+dim.suffix;
 Entity text={3,0,0,h,0,0,value,layer};text.previewText=plainMtext(value);text.widthFactor=.7;text.style=9;
 const double width=cadDimensionTextWidth(text),gap=h/3.5,arrowLength=h*2.5/3.5;
 double rot=0;Point baselineCentre;
 auto readable=[&](Point dir){double angle=atan2(dir.y,dir.x)*180/PI;if(angle>90)angle-=180;if(angle<-90)angle+=180;return angle;};
 if(dim.type<=1){
  Point u=dim.type==0?Point{cos(dim.rotation*PI/180),sin(dim.rotation*PI/180)}:unit(b-a),n=normal(u);
  Point aa=a+n*dot(dim.at-a,n),bb=b+n*dot(dim.at-b,n);
  auto ext=[&](Point start,Point end){Point dir=unit(end-start);line(start+dir*(h*.625/3.5),end+dir*(h/3.5));};ext(a,aa);ext(b,bb);
  rot=readable(bb-aa);Point reading={cos(rot*PI/180),sin(rot*PI/180)},above=normal(reading),along=unit(bb-aa);
  double span=magnitude(bb-aa);
  if(span>=width+2*gap+2*arrowLength){line(aa,bb);arrow(aa,along);arrow(bb,along*-1);baselineCentre=(aa+bb)*.5+above*gap;}
  else{
   Point low=dot(aa,reading)<dot(bb,reading)?aa:bb,high=dot(aa,reading)<dot(bb,reading)?bb:aa;
   line(low-reading*(width+2*gap+arrowLength),high+reading*(arrowLength*1.7));arrow(aa,along*-1);arrow(bb,along);
   baselineCentre=low-reading*(width/2+gap+arrowLength)+above*gap;
  }
 }else if(dim.type==2||dim.type==3){
  Point c=dim.type==2?a:(a+b)*.5,tip=b;
  if(dim.jogged){Point dir=unit(dim.at-tip);Point side=normal(dir)*(h*.55),before=dim.jogPoint-dir*(h*.65),after=dim.jogPoint+dir*(h*.65);line(tip,before);line(before,dim.jogPoint+side);line(dim.jogPoint+side,dim.jogPoint-side);line(dim.jogPoint-side,after);line(after,dim.overrideCentre);arrow(tip,dir);rot=readable(dir);Point reading={cos(rot*PI/180),sin(rot*PI/180)};baselineCentre=tip+dir*(width/2+gap)+normal(reading)*gap;}
  else{
   // A radius dimension must be collinear with its true arc centre and chord.
   Point radial=unit(tip-c);double length=std::max(dot(dim.at-tip,radial),width+2*gap+arrowLength);
   Point end=tip+radial*length;dim.at=end;line(c,end);arrow(tip,radial);rot=readable(radial);Point reading={cos(rot*PI/180),sin(rot*PI/180)};
   baselineCentre=tip+radial*(length/2)+normal(reading)*gap;
  }
  if(dim.type==3){line(a,b);arrow(a,unit(b-a));}
 }else{
  Point c=dim.centre;double radius=magnitude(dim.at-c),s=atan2(a.y-c.y,a.x-c.x),end=atan2(b.y-c.y,b.x-c.x);while(end<s)end+=2*PI;
  Entity e={2,c.x,c.y,radius,s*180/PI,end*180/PI,"",layer};dim.graphics.push_back(e);
  Point aa=c+Point{cos(s),sin(s)}*radius,bb=c+Point{cos(end),sin(end)}*radius;
  line(a,aa+unit(aa-c)*h*.5);line(b,bb+unit(bb-c)*h*.5);arrow(aa,{-sin(s),cos(s)});arrow(bb,{sin(end),-cos(end)});
  double mid=(s+end)/2;baselineCentre=c+Point{cos(mid),sin(mid)}*radius+Point{0,gap};
 }
 Point reading={cos(rot*PI/180),sin(rot*PI/180)};dim.textAt=baselineCentre-reading*(width/2);
 text.x=dim.textAt.x;text.y=dim.textAt.y;text.rotation=rot;dim.graphics.push_back(text);
}
inline Drawing generate(const Params&p){
 auto errors=validateV3(p);if(!errors.empty())throw std::runtime_error(errors.front());
 Drawing d;d.type=p.type;auto layers=refLayers(p.type);auto layer=[&](const std::string&s){for(size_t i=0;i<layers.size();i++)if(layers[i].name==s)return (int)i;throw std::runtime_error("Missing reference layer");};
 int visible=layer("可见 (Himile)"),centre=layer("中心线 (Himile)"),dimLayer=layer("6 尺寸线-管口号外圆（细实线）"),hidden=layer("4 不可见线（虚线）"),noteLayer=layer("2 明细栏-技术特性表-剖面线-管口表-管口载荷表（细实线）"),breakLayer=layer("5 断开线（双点划线）"),hatchLayer=layer("剖面线 (Himile)");
 const double papers[][2]={{1189,841},{841,594},{594,420},{420,297},{297,210}};d.sheetW=papers[p.paper][0];d.sheetH=papers[p.paper][1];
 double need=std::max({p.height/(135*d.sheetH/420),p.length/(130*d.sheetH/420),p.depth/(55*d.sheetW/594),(p.diameter+2*p.pad)*sin(p.padAngle*PI/360)/(170*d.sheetW/594)});
 const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};d.recommended=1000;for(double s:scales)if(s>=need){d.recommended=s;break;}
 d.requiredRatio=need;d.ratio=p.scale?p.scale:d.recommended;double S=d.ratio;d.plotFactor=S;double W=d.sheetW*S,H=d.sheetH*S,h=3.5*S,offset=8*S;
 auto line=[&](Point a,Point b,int l,int role=0){Entity e={0,a.x,a.y,b.x,b.y,0,"",l};e.role=role;if(l==breakLayer)e.ltscale=.12;if(l==hidden)e.ltscale=std::min(.08,magnitude(b-a)/(S*19.05*3));d.e.push_back(e);};
 auto rect=[&](double x,double y,double w,double ht,int role=0){line({x,y},{x+w,y},visible,role);line({x+w,y},{x+w,y+ht},visible,role);line({x+w,y+ht},{x,y+ht},visible,role);line({x,y+ht},{x,y},visible,role);};
 auto arc=[&](Point c,double r,double s,double end,int role=0){Entity e={2,c.x,c.y,r,s,end,"",visible};e.role=role;d.e.push_back(e);};
 auto circle=[&](Point c,double r,int role=0){Entity e={1,c.x,c.y,r,0,0,"",visible};e.role=role;d.e.push_back(e);};
 auto label=[&](Point a,std::string text,bool chinese=false){Entity e={3,a.x,a.y,h,0,0,text,noteLayer};e.previewText=text;if(chinese)e.style=refStyles(p.type).size()-1;d.e.push_back(e);};
 auto annotationText=[&](Point a,const std::string&text,bool chinese=false){Entity e={3,a.x,a.y,2.5*S,0,0,text,noteLayer};e.previewText=plainMtext(text);e.style=chinese?(int)refStyles(p.type).size()-1:0;d.e.push_back(e);};
 auto annotationWidth=[&](const std::string&value){double nh=2.5*S;bool cjk=false;for(unsigned c:cadCodepoints(plainMtext(value)))if(c>=0x2e80&&c<=0x9fff)cjk=true;
  if(cjk){double width=0;for(unsigned c:cadCodepoints(plainMtext(value)))width+=nh*(c>=0x2e80?1.45:.725);return width;}
  Entity text={3,0,0,nh,0,0,value,noteLayer};return cadDimensionTextWidth(text);
 };
 auto addLeader=[&](Point tip,Point anchor,double width,int role=30,bool connectLeft=false){bool leftEnd=connectLeft||anchor.x>tip.x;double elbow=leftEnd?anchor.x:anchor.x+width,other=leftEnd?anchor.x+width:anchor.x;Entity e={9,tip.x,tip.y,2.5*S,0,0,"",noteLayer};e.role=role;e.points={tip.x,tip.y,elbow,anchor.y,other,anchor.y};auto graphics=leaderGraphics(e);d.e.insert(d.e.end(),graphics.begin(),graphics.end());};
 auto roughness=[&](Point a){line(a,{a.x-4*S,a.y-7*S},noteLayer,39);line(a,{a.x+2.3*S,a.y-4*S},noteLayer,39);line({a.x-2.3*S,a.y-4*S},{a.x+2.3*S,a.y-4*S},noteLayer,39);annotationText({a.x-1.7*S,a.y-8*S},"12.5");};
 auto note=[&](Point tip,Point anchor,const std::string&chinese,const std::string&english,const std::string&suffix="",int role=30,bool connectLeft=false,double blockWidth=0){size_t han=0;for(unsigned char ch:chinese)if((ch&0xc0)!=0x80)han++;
  // CJK advance can exceed the nominal cap height in AutoCAD's SimSun MTEXT.
  // Keep the diameter suffix beyond the complete Chinese text, with a clear gap.
  double nh=2.5*S,chineseWidth=annotationWidth(chinese),suffixX=chineseWidth+nh*.3;
  double width=std::max({suffix.empty()?chineseWidth:suffixX+annotationWidth(suffix),annotationWidth(english),blockWidth})+2*S;
  addLeader(tip,anchor,width,role,connectLeft);annotationText({anchor.x,anchor.y+nh*.35},chinese,true);
  if(!suffix.empty())annotationText({anchor.x+suffixX,anchor.y+nh*.35},suffix);
  if(!english.empty())annotationText({anchor.x,anchor.y-nh*1.5},english);
 };
 auto dim=[&](std::string key,int type,Point a,Point b,Point at,double rotation=0,Point c=Point{},std::string prefix="",double tolerance=0,double measurementScale=1,std::string suffix=""){
  Dimension q;q.type=type;q.key=key;q.first=a;q.second=b;q.centre=c;q.at=at;q.rotation=rotation;q.prefix=prefix;if(key=="wear-inner-radius"){q.jogged=true;q.jogPoint=b+(at-b)*.72;q.overrideCentre=at;}q.tolerance=tolerance;q.measurementScale=measurementScale;q.suffix=suffix;
  if(type==0)q.measurement=std::abs(dot(b-a,{cos(rotation*PI/180),sin(rotation*PI/180)}));
  else if(type==1||type==3)q.measurement=magnitude(b-a);else if(type==2)q.measurement=magnitude(b-a);
  else {double ang=atan2(b.y-c.y,b.x-c.x)-atan2(a.y-c.y,a.x-c.x);while(ang<0)ang+=2*PI;q.measurement=ang*180/PI;}
  if(q.measurement<1e-7)return;dimensionGraphics(q,h,dimLayer);for(auto&text:q.graphics)if(text.kind==3)text.layer=noteLayer;d.dimensions.push_back(q);
 };
 auto dh=[&](std::string key,Point a,Point b,double y){dim(key,0,a,b,{(a.x+b.x)/2,y});};
 auto dv=[&](std::string key,Point a,Point b,double x){dim(key,0,a,b,{x,(a.y+b.y)/2},90);};
 const double R=p.diameter/2,ro=R+p.pad,theta=p.angle*PI/360,wear=p.padAngle*PI/360;
 const double frontX=W*.72,frontY=H*.52,sideY=frontY,planY=H*.245,fixedX=W*.19,slidingX=W*.405;
 Point c={frontX,frontY+p.height};double left=frontX-p.length/2,right=frontX+p.length/2,baseTop=frontY+p.base;
 rect(left,frontY,p.length,p.base,1);arc(c,R,270-p.padAngle/2,270+p.padAngle/2,1);arc(c,ro,270-p.padAngle/2,270+p.padAngle/2,1);
 for(int sign:{-1,1})line(c+Point{sign*sin(wear),-cos(wear)}*R,c+Point{sign*sin(wear),-cos(wear)}*ro,visible,1);
 line({frontX,frontY-offset},{frontX,c.y+offset},centre);line({left-offset,c.y},{right+offset,c.y},centre);
 auto inner=innerRibPositions(p);auto ribs=ribShapes(p);const auto&outer=ribs.back();
 std::vector<double> ribBases;for(auto&r:ribs)ribBases.push_back(r.station);
 Point outerDir=outer.direction,innerFace={frontX+outer.base[0].x,frontY+outer.base[0].y},innerContact={frontX+outer.contact.x,frontY+outer.contact.y},fromCentre=innerFace-c;
 double projection=dot(fromCentre,outerDir);Point radial=unit(innerContact-c),tangent=normal(radial);
 d.deg3=acos(std::clamp(std::abs(dot(outerDir,tangent)),0.,1.))*180/PI;d.webNotched=d.deg3<20;
 for(size_t i=0;i<ribs.size();i++){
  auto&r=ribs[i];for(int edge=0;edge<2;edge++)line(r.base[edge]+Point{frontX,frontY},r.top[edge]+Point{frontX,frontY},visible,2);
  line(r.top[0]+Point{frontX,frontY},r.top[1]+Point{frontX,frontY},visible,15);
  Point middle=(r.base[0]+r.base[1])*.5+r.direction*((r.top[0].y-p.base)*.3/r.direction.y)+Point{frontX,frontY},perp=normal(r.direction);
  if(i==0||i==ribs.size()/2)dim("tw",1,middle-perp*(p.rib/2),middle+perp*(p.rib/2),middle+perp*offset);
 }
 // Web profile: the 50 mm end relief follows a radius through the vessel centre.
 double endRadius=d.webNotched?ro+50:ro;
 double endIntersection=-projection-sqrt(std::max(0.,projection*projection-dot(fromCentre,fromCentre)+endRadius*endRadius));
 Point rightNotch=innerFace+outerDir*endIntersection,rightArc=c+unit(rightNotch-c)*ro;
 Point leftNotch={2*c.x-rightNotch.x,rightNotch.y},leftArc={2*c.x-rightArc.x,rightArc.y};
 Point webBase=innerFace-outerDir*((innerFace.y-baseTop)/outerDir.y);
 line({2*c.x-webBase.x,baseTop},leftNotch,visible,7);if(d.webNotched)line(leftNotch,leftArc,visible,7);
 double webHalfAngle=atan2(rightArc.x-c.x,c.y-rightArc.y)*180/PI;
 arc(c,ro,270-webHalfAngle,270+webHalfAngle,7);if(d.webNotched)line(rightArc,rightNotch,visible,7);line(rightNotch,webBase,visible,7);

 dv("Hs",{left,frontY},{frontX,c.y},left-offset*2);dh("E",{left,frontY},{right,frontY},frontY-offset*2.7);
 dv("tb",{right,frontY},{right,baseTop},right+offset);dh("X",{left,baseTop},{left+p.outerSetback,baseTop},frontY-offset);
 for(size_t i=1;i<inner.size();i++)dh("di",{frontX+inner[i-1],baseTop},{frontX+inner[i],baseTop},frontY-offset);
 dim("theta",4,{2*c.x-innerContact.x,innerContact.y},innerContact,c+Point{0,-R*.45},0,c);
 dim("theta-w",4,c+Point{-sin(wear),-cos(wear)}*R,c+Point{sin(wear),-cos(wear)}*R,c+Point{0,-R*.65},0,c);
 Point padDirection={-sin(wear*.8),-cos(wear*.8)};dim("tp",1,c+padDirection*R,c+padDirection*ro,c+padDirection*(R+p.pad/2)+normal(padDirection)*offset*1.5);
 for(int sign:{-1,1}){line(c,c+Point{sign*sin(wear),-cos(wear)}*(ro+offset),centre,16);line(c,{frontX+sign*outer.contact.x,frontY+outer.contact.y},centre,16);}
 if(d.webNotched){line(c,leftNotch,centre,16);line(c,rightNotch,centre,16);}
 Point radiusDirection={cos(240*PI/180),sin(240*PI/180)};dim("wear-inner-radius",2,c,c+radiusDirection*R,c+radiusDirection*(R*.72));
 if(d.webNotched){Point edge=unit(rightArc-rightNotch),outward=normal(edge);if(dot(outward,(rightArc+rightNotch)*.5-c)<0)outward=outward*-1;
  dim("web-gap-50",1,rightNotch,rightArc,(rightNotch+rightArc)*.5-outward*offset*2.3);
  Point chord=unit(rightArc-innerContact),outside=normal(chord);if(dot(outside,(rightArc+innerContact)*.5-c)<0)outside=outside*-1;
  dim("web-gap-reference",1,innerContact,rightArc,(innerContact+rightArc)*.5-outside*offset*1.5,0,{},"(",0,1,")");
  double noteX=std::max({right,c.x+ro*sin(wear),rightNotch.x,rightArc.x,innerContact.x})+offset*.9;
  note((rightNotch+rightArc)*.5,{noteX,rightNotch.y-offset*.75},"腹板缺口","WEB GAP","",30,true);
 }
 // Hidden radial vent drilling through the bottom wear-plate thickness.
 for(int sign:{-1,1}){double x=sign*p.ventDiameter/2;line({c.x+x,c.y-sqrt(ro*ro-x*x)},{c.x+x,c.y-sqrt(R*R-x*x)},hidden,31);}
 // Place the vent note inside the lower-right free area, above the pad arc
 // and below the wrap-angle dimensions, clear of the left jogged radius.
 note({c.x,c.y-ro+p.pad/2},{c.x+offset*.6,c.y-R+offset*1.9},"排气孔","Vent Hole","%%c"+num(p.ventDiameter),30,true);
 // Elevations use the transverse rib/web heights and the actual bottom pad thickness.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,by=sideY,top=by+p.height-ro*cos(wear),padBottom=by+p.height-ro,padInside=by+p.height-R;
  double pw=p.padWidth,r=p.fillet,wx=webAxialCentre(p,view),rx=ribAxialCentre(p,view);
  rect(px-p.depth/2,by,p.depth,p.base,10);
  for(double x:(p.type?std::vector<double>{0}:std::vector<double>{-p.holeRowSpacing/2,p.holeRowSpacing/2})){
   double half=view?p.slot/2:p.hole/2;for(int sign:{-1,1})line({px+x+sign*half,by},{px+x+sign*half,by+p.base},hidden,17);
  }
  line({px-pw/2,padBottom},{px-pw/2,top-r},visible,11);arc({px-pw/2+r,top-r},r,90,180,11);
  line({px-pw/2+r,top},{px+pw/2-r,top},visible,11);arc({px+pw/2-r,top-r},r,0,90,11);line({px+pw/2,top-r},{px+pw/2,padBottom},visible,11);
  double ribHeight=by+std::max(outer.top[0].y,outer.top[1].y),webHeight=rightArc.y;
  auto padLine=[&](double y,bool wholeHidden=false){if(wholeHidden){line({px-pw/2,y},{px+pw/2,y},hidden,18);return;}double lo=rx-ribAxialWidth(p)/2,hi=rx+ribAxialWidth(p)/2;if(p.type&&y<=webHeight){lo=std::min(lo,wx-p.web/2);hi=std::max(hi,wx+p.web/2);}line({px-pw/2,y},{px+lo,y},visible,11);line({px+lo,y},{px+hi,y},hidden,18);line({px+hi,y},{px+pw/2,y},visible,11);};
  padLine(padBottom);padLine(padInside,true);
  rect(px+rx-ribAxialWidth(p)/2,by+p.base,ribAxialWidth(p),ribHeight-by-p.base,12);
  int webLayer=p.type?visible:hidden;
  line({px+wx-p.web/2,by+p.base},{px+wx-p.web/2,webHeight},webLayer,13);line({px+wx+p.web/2,by+p.base},{px+wx+p.web/2,webHeight},webLayer,13);line({px+wx-p.web/2,webHeight},{px+wx+p.web/2,webHeight},webLayer,13);
  line({px,by-offset},{px,top+offset},centre);
  double ventX=px+(view?-1:1)*(pw/2-p.ventOffset),ventY=(padBottom+padInside)/2;
  for(int sign:{-1,1})line({ventX+sign*p.ventDiameter/2,padBottom},{ventX+sign*p.ventDiameter/2,padInside},hidden,14);
  line({ventX,padBottom-offset*.5},{ventX,padInside+offset*.5},centre,14);
  note({ventX,ventY},{view?px+p.depth/2+offset*.8:px-p.depth/2-offset*3,ventY-offset*.8},"排气孔","Vent Hole","%%c"+num(p.ventDiameter));
  dh("Wp",{px-pw/2,top},{px+pw/2,top},top+offset*2);
  double bodyLo=std::min(rx-ribAxialWidth(p)/2,wx-p.web/2),bodyHi=std::max(rx+ribAxialWidth(p)/2,wx+p.web/2),bLineY=std::max(ribHeight,webHeight)+offset;
  dh("b",{px+bodyLo,ribHeight},{px+bodyHi,ribHeight},bLineY);
  if(p.type&&!view)dh("pad-to-web-outer",{px-pw/2,top},{px+wx-p.web/2,webHeight},bLineY);
  dh("a1",{ventX,ventY},{px+(view?-1:1)*pw/2,ventY},ventY+offset*.7);
  Point fc={px+pw/2-r,top-r},fp=fc+Point{cos(20*PI/180),sin(20*PI/180)}*r;dim("R1",2,fc,fp,{px+pw/2+offset*2,top+offset*.5},0,{},"4×");
  label({px-p.depth/2,by-offset*2},view?"滑动鞍座":"固定鞍座",true);label({px-p.depth/2,by-offset*3},view?"Sliding Saddle":"Fixed Saddle");
 }
 // Vessel outline is schematic; the saddle itself remains at full physical size.
 {
  double baseline=sideY+p.height-R,top=sideY+p.height-ro*cos(wear)+28*S,x0=fixedX-p.depth/2-18*S,x1=slidingX+p.depth/2+18*S;
  Entity vessel={6,x0,baseline,0,0,0,"",breakLayer};vessel.degree=3;vessel.role=50;vessel.ltscale=.12;
  vessel.points={x0,baseline,x0-10*S,top,x0+12*S,top+12*S,fixedX+8*S,top-8*S,slidingX-8*S,top+8*S,x1-10*S,top+4*S,x1+10*S,top,x1,baseline};vessel.knots={0,0,0,0,1,2,3,4,5,5,5,5};vessel.samples=splineSamples(vessel);d.e.push_back(vessel);
  line({x0,baseline},{fixedX-p.padWidth/2,baseline},breakLayer,50);line({fixedX+p.padWidth/2,baseline},{slidingX-p.padWidth/2,baseline},breakLayer,50);line({slidingX+p.padWidth/2,baseline},{x1,baseline},breakLayer,50);
  double middle=(fixedX+slidingX)/2;
  for(int sign:{-1,1}){double x=middle+sign*2*S;line({x,baseline-4*S},{x,top*.5+baseline*.5-2*S},breakLayer,50);line({x,top*.5+baseline*.5-2*S},{x+2*S,top*.5+baseline*.5-S},breakLayer,50);line({x+2*S,top*.5+baseline*.5-S},{x-2*S,top*.5+baseline*.5+S},breakLayer,50);line({x-2*S,top*.5+baseline*.5+S},{x,top*.5+baseline*.5+2*S},breakLayer,50);line({x,top*.5+baseline*.5+2*S},{x,top+8*S},breakLayer,50);}
  for(auto span:std::vector<std::pair<double,double>>{{x0,fixedX-p.padWidth/2},{fixedX+p.padWidth/2,slidingX-p.padWidth/2},{slidingX+p.padWidth/2,x1}})line({span.first,baseline-p.pad},{span.second,baseline-p.pad},breakLayer,50);
  for(int view=0;view<1;view++){
   double px=view?slidingX:fixedX;Point tip={px+(view?-1:1)*p.padWidth/2,baseline},ref={px+p.padWidth/2+5*S,baseline-8*S};
   Entity weldArrow={9,tip.x,tip.y,2.5*S,0,0,"",noteLayer};weldArrow.role=51;weldArrow.points={tip.x,tip.y,ref.x,ref.y,ref.x+19*S,ref.y};auto weldGraphics=leaderGraphics(weldArrow);d.e.insert(d.e.end(),weldGraphics.begin(),weldGraphics.end());circle(ref,.9*S,51);d.e.back().layer=noteLayer;
   line({ref.x+5*S,ref.y},{ref.x+5*S,ref.y+4*S},noteLayer,51);line({ref.x+5*S,ref.y+4*S},{ref.x+9*S,ref.y},noteLayer,51);
   for(int i=0;i<5;i++)line({ref.x+i*3*S,ref.y-1.2*S},{ref.x+(i*3+1.8)*S,ref.y-1.2*S},noteLayer,51);
   annotationText({ref.x+1.5*S,ref.y+.7*S},num(p.padShellWeld));line({ref.x+19*S,ref.y},{ref.x+21*S,ref.y+2*S},noteLayer,51);line({ref.x+19*S,ref.y},{ref.x+21*S,ref.y-2*S},noteLayer,51);annotationText({ref.x+21.5*S,ref.y-S},"2");
  }
 }
 auto hatch=[&](double x,double y,double width,double height,double angle,int role){
  if(width<=0||height<=0)return;Entity e={8,x,y,width,height,angle,"",hatchLayer};e.role=role;e.width=5*S;
  double slope=angle>0?1:-1,minV=std::min({y-slope*x,y+height-slope*x,y-slope*(x+width),y+height-slope*(x+width)}),maxV=std::max({y-slope*x,y+height-slope*x,y-slope*(x+width),y+height-slope*(x+width)});
  for(double v=floor(minV/(e.width*sqrt(2.)))*e.width*sqrt(2.);v<maxV;v+=e.width*sqrt(2.)){
   std::vector<Point> pts;auto add=[&](Point q){if(q.x>=x-1e-7&&q.x<=x+width+1e-7&&q.y>=y-1e-7&&q.y<=y+height+1e-7){for(auto&a:pts)if(magnitude(q-a)<1e-6)return;pts.push_back(q);}};
   add({x,slope*x+v});add({x+width,slope*(x+width)+v});add({(y-v)/slope,y});add({(y+height-v)/slope,y+height});if(pts.size()==2)e.samples.insert(e.samples.end(),{pts[0].x,pts[0].y,pts[1].x,pts[1].y});
  }d.e.push_back(e);
 };
 // Plans share the physical rib stations, not scaled or inferred annotation endpoints.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,py=planY,x0=px-p.depth/2,y0=py-p.length/2,wx=webAxialCentre(p,view),rx=ribAxialCentre(p,view);
  rect(x0,y0,p.depth,p.length,3);
  // Both web types end at the inner base faces of the two outer ribs.
  double webLength=2*outer.base[0].x,webY=py-webLength/2;
  rect(px+wx-p.web/2,webY,p.web,webLength,8);hatch(px+wx-p.web/2,webY,p.web,webLength,45,21);
  for(size_t i=0;i<ribs.size();i++){
   auto&r=ribs[i];double bottom=py+r.station-r.footThickness/2;bool split=!p.type&&i>0&&i+1<ribs.size();
   if(split){double width=(ribAxialWidth(p)-p.web)/2;rect(px-ribAxialWidth(p)/2,bottom,width,r.footThickness,4);rect(px+p.web/2,bottom,width,r.footThickness,4);hatch(px-ribAxialWidth(p)/2,bottom,width,r.footThickness,45,20);hatch(px+p.web/2,bottom,width,r.footThickness,-45,20);}
   else {rect(px+rx-ribAxialWidth(p)/2,bottom,ribAxialWidth(p),r.footThickness,4);hatch(px+rx-ribAxialWidth(p)/2,bottom,ribAxialWidth(p),r.footThickness,45,20);}
  }
  line({px,y0-offset},{px,y0+p.length+offset},centre);line({x0-offset,py},{x0+p.depth+offset,py},centre);
  std::vector<int> rows=p.type?std::vector<int>{0}:std::vector<int>{-1,1};auto stations=anchorStations(p);
  for(int row:rows)for(int i=0;i<p.holes;i++){
   double x=px+row*p.holeRowSpacing/2,y=py+stations[i],rad=p.hole/2,straight=view?p.slot-p.hole:0;
   if(straight<1e-8)circle({x,y},rad,view?6:5);else {arc({x-straight/2,y},rad,90,270,6);arc({x+straight/2,y},rad,270,450,6);line({x-straight/2,y+rad},{x+straight/2,y+rad},visible,6);line({x-straight/2,y-rad},{x+straight/2,y-rad},visible,6);}
   line({x-rad-h*.5,y},{x+rad+h*.5,y},centre);line({x,y-rad-h*.5},{x,y+rad+h*.5},centre);

  }
  for(int row:rows)line({px+row*p.holeRowSpacing/2,py+stations.front()-p.hole},{px+row*p.holeRowSpacing/2,py+stations.back()+p.hole},centre,44);
  for(double y:stations)line({px+(p.type?0:-p.holeRowSpacing/2)-p.slot,py+y},{px+(p.type?0:p.holeRowSpacing/2)+p.slot,py+y},centre,44);
  for(size_t i=0;i<p.holeDistances.size();i++){double x=px+(p.type?0:(view?1:-1)*p.holeRowSpacing/2),position=view?x0+p.depth+offset*(1.3+i*.9):x0-offset*(1.3+i*.9);dim("bolt-pair",0,{x,py-p.holeDistances[i]},{x,py+p.holeDistances[i]},{position,py},90,{},"",1);}
  dv("E",{x0,y0},{x0,y0+p.length},view?x0+p.depth+offset*(p.holeDistances.size()*.9+2.5):x0-offset*(p.holeDistances.size()*.9+2.5));
  dh("F",{x0,y0+p.length},{x0+p.depth,y0+p.length},y0+p.length+offset*2);
  if(p.type){double outside=px+wx+(view?1:-1)*p.web/2,edge=view?x0+p.depth:x0;
   dh("base-to-web-outer",{edge,y0+p.length},{outside,py+webLength/2},y0+p.length+offset*.9);
  }
  if(!p.type)dh("a3",{px-p.holeRowSpacing/2,py+stations.front()},{px+p.holeRowSpacing/2,py+stations.front()},y0-offset*1.5);
  dh("ts",{px+wx-p.web/2,py},{px+wx+p.web/2,py},py+offset*1.4);

 }
 // Anchor-bolt leaders use common selectable specification/material/coating values.
 const std::string spec=boltSpecs().at(p.boltSpecIndex),material=boltMaterials().at(p.boltMaterialIndex),coating=boltCoatings().at(p.boltCoatingIndex),coatingEn=boltCoatingsEnglish().at(p.boltCoatingIndex);
 auto boltText=[&](Point anchor){double nh=2.5*S;annotationText(anchor,"配",true);annotationText({anchor.x+annotationWidth("配")+nh*.3,anchor.y},spec+" "+material);annotationText({anchor.x,anchor.y-nh*1.5},coating+" 地脚螺栓",true);annotationText({anchor.x,anchor.y-nh*3},"For "+spec+" "+material);annotationText({anchor.x,anchor.y-nh*4.5},coatingEn+" Anchor Bolt");};
 auto stations=anchorStations(p);double column=p.type?0:p.holeRowSpacing/2;
 Point roundTip={fixedX+column,planY+stations.back()},roundNote={fixedX+p.depth/2+3*S,planY+p.length/2-2*S};
 double boltWidth=std::max({annotationWidth("配")+2.5*S*.3+annotationWidth(spec+" "+material),annotationWidth(coating+" 地脚螺栓"),annotationWidth("For "+spec+" "+material),annotationWidth(coatingEn+" Anchor Bolt")});
 double roundWidth=std::max(boltWidth,annotationWidth(std::to_string(totalHoles(p))+"×%%c"+num(p.hole)))+2*S;
 addLeader(roundTip,roundNote,roundWidth,52);annotationText({roundNote.x,roundNote.y+S},std::to_string(totalHoles(p))+"×%%c"+num(p.hole));boltText({roundNote.x,roundNote.y-4*S});roughness({roundNote.x+roundWidth,roundNote.y});
 // Enlarged slot detail: per-dimension DIMLFAC preserves true measurements.
 double G=1;for(double factor:{2.,3.,4.,5.,8.,10.,15.,20.})if(p.slot*factor<=36*S)G=factor;
 double rad=p.hole*G/2,half=(p.slot-p.hole)*G/2,crop=p.slot*G*.68;Point dc={slidingX+p.depth/2+crop+(p.holeDistances.size()*.9+3.5)*offset,planY-p.length*.28};
 arc({dc.x-half,dc.y},rad,90,270,60);arc({dc.x+half,dc.y},rad,270,450,60);line({dc.x-half,dc.y+rad},{dc.x+half,dc.y+rad},visible,60);line({dc.x-half,dc.y-rad},{dc.x+half,dc.y-rad},visible,60);circle(dc,crop,61);d.e.back().layer=noteLayer;
 line({dc.x-crop-3*S,dc.y},{dc.x+crop+3*S,dc.y},centre,60);line({dc.x,dc.y-crop-3*S},{dc.x,dc.y+crop+3*S},centre,60);
 dim("slot-detail-d",0,{dc.x+half,dc.y-rad},{dc.x+half,dc.y+rad},{dc.x+crop+6*S,dc.y},90,{},"",0,1/G);
 dim("slot-detail-straight",0,{dc.x-half,dc.y-rad},{dc.x+half,dc.y-rad},{dc.x,dc.y-crop-5*S},0,{},"",0,1/G);
 Point radiusTip={dc.x-half-rad*sqrt(.5),dc.y-rad*sqrt(.5)};dim("slot-detail-radius",2,{dc.x-half,dc.y},radiusTip,{dc.x-crop-9*S,dc.y-4*S},0,{},"2×",0,1/G);
 Point typ={dc.x+crop+8*S,dc.y+crop+7*S};std::string typText="TYP.("+std::to_string(totalHoles(p))+"Nos.)";addLeader({dc.x+half,dc.y+rad},typ,annotationWidth(typText)+2*S,62);annotationText({typ.x,typ.y+S},typText);roughness({typ.x+10*S,typ.y});
 Point mainSlot={slidingX+column,planY+stations.front()};double mainRing=.65*p.slot;circle(mainSlot,mainRing,61);d.e.back().layer=noteLayer;Point direction=unit(dc-mainSlot);line(mainSlot+direction*mainRing,dc-direction*crop,noteLayer,61);
 Point slotNote={dc.x-crop,dc.y-crop-16*S};note(mainSlot,slotNote,"长圆孔","Slotted Hole","",63,false,boltWidth);boltText({slotNote.x,slotNote.y-8*S});annotationText({dc.x-crop,dc.y-crop-11*S},"SCALE 1:"+num(S/G));
 label({W*.81,H*.93},"1 : "+num(d.ratio));
 d.modelCount=d.e.size()+d.dimensions.size();d.minX=d.minY=0;d.maxX=W;d.maxY=H;return d;
}
}
