// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
namespace saddle {
inline Point operator+(Point a,Point b){return {a.x+b.x,a.y+b.y};}
inline Point operator-(Point a,Point b){return {a.x-b.x,a.y-b.y};}
inline Point operator*(Point a,double b){return {a.x*b,a.y*b};}
inline double dot(Point a,Point b){return a.x*b.x+a.y*b.y;}
inline double magnitude(Point a){return hypot(a.x,a.y);}
inline Point unit(Point a){double l=magnitude(a);return l?a*(1/l):Point{1,0};}
inline Point normal(Point a){return {-a.y,a.x};}
inline int spacingCount(int ribs){return std::max(0,(ribs-2)/2);}
inline std::vector<double> innerRibPositions(const Params&p){
 const int n=p.ribs-2;std::vector<double> v;if(n<=0)return v;
 if((int)p.ribSpacings.size()!=spacingCount(p.ribs))throw std::runtime_error("Re-enter inner rib centre spacings after changing the rib count.");
 for(double x:p.ribSpacings)if(!std::isfinite(x)||x<=p.rib)throw std::runtime_error("Inner rib centre spacing must exceed rib thickness.");
 double x=0;int start=0;if(n%2)v.push_back(0);else {x=p.ribSpacings[0]/2;start=1;v.push_back(-x);v.push_back(x);}
 for(int i=start;i<(int)p.ribSpacings.size();i++){x+=p.ribSpacings[i];v.push_back(-x);v.push_back(x);}
 std::sort(v.begin(),v.end());return v;
}
inline std::vector<std::string> validateV3(const Params&p){
 auto errors=validate(p);if(!errors.empty())return errors;
 for(double x:{p.padAngle,p.fillet,p.ventOffset,p.ventEnd,p.ventDiameter,p.outerSetback})if(!std::isfinite(x)){errors.push_back("All parameters must be finite.");return errors;}
 try{
  auto xs=innerRibPositions(p);
  if(p.padAngle<p.angle||p.padAngle>180||!std::isfinite(p.padAngle))errors.push_back("Wear plate angle must be between contact angle and 180 degrees.");
  if(p.fillet<=0||p.fillet*2>=p.padWidth)errors.push_back("Wear plate corner radius must fit within its width.");
  if(p.ventDiameter<=0||p.ventOffset<=p.ventDiameter/2||p.ventOffset>=p.padWidth/2)errors.push_back("Vent offset must lie between the hole radius and half the wear plate width.");
  if(p.ventEnd<=p.ventDiameter/2||p.ventEnd>=p.height-p.base)errors.push_back("Vent end offset is invalid.");
  if(p.outerSetback<=p.rib/2||p.outerSetback>=p.length/2)errors.push_back("Outer rib setback is invalid.");
  double limit=std::min(p.length/2-p.outerSetback-p.rib,(p.diameter/2+p.pad)*sin(p.angle*PI/360)-p.rib);
  if(!xs.empty()&&std::abs(xs.back())>=limit)errors.push_back("Inner rib positions must fit between the outer ribs and under the wear plate.");
 }catch(const std::exception&e){errors.push_back(e.what());}return errors;
}
inline void dimensionGraphics(Dimension&dim,double h,int layer){
 auto line=[&](Point a,Point b){dim.graphics.push_back({0,a.x,a.y,b.x,b.y,0,"",layer});};
 auto arrow=[&](Point tip,Point dir){dir=unit(dir);Point side=normal(dir)*(h*.19),back=tip+dir*h;
  Entity e={5,tip.x,tip.y,0,0,0,"",layer};e.points={tip.x,tip.y,back.x+side.x,back.y+side.y,back.x-side.x,back.y-side.y,back.x-side.x,back.y-side.y};dim.graphics.push_back(e);};
 Point a=dim.first,b=dim.second;std::string value=num(dim.measurement);double rot=0;
 if(dim.type<=1){
  Point u=dim.type==0?Point{cos(dim.rotation*PI/180),sin(dim.rotation*PI/180)}:unit(b-a),n=normal(u);
  Point aa=a+n*dot(dim.at-a,n),bb=b+n*dot(dim.at-b,n);double sign=dot(bb-aa,u)<0?-1:1;u=u*sign;
  auto ext=[&](Point start,Point end){Point dir=unit(end-start);line(start+dir*(h*.4),end+dir*(h*.5));};ext(a,aa);ext(b,bb);
  dim.textAt=(aa+bb)*.5+n*(h*.6);rot=atan2(u.y,u.x)*180/PI;if(rot>90||rot<-90)rot+=180;
  double gap=std::min(magnitude(bb-aa)*.2,h*(value.size()+dim.prefix.size())*.3);
  Point mid=(aa+bb)*.5;line(aa,mid-u*gap);line(mid+u*gap,bb);arrow(aa,u);arrow(bb,u*-1);
 }else if(dim.type==2||dim.type==3){
  Point c=dim.type==2?a:(a+b)*.5;Point tip=b;Point dir=unit(dim.at-tip);line(tip,dim.at);arrow(tip,dir);dim.textAt=dim.at+Point{h*.4,h*.3};value=(dim.type==2?"R":"%%c")+value;
  if(dim.type==3){line(a,b);arrow(a,unit(b-a));}
 }else{
  Point c=dim.centre;double radius=magnitude(dim.at-c),s=atan2(a.y-c.y,a.x-c.x),end=atan2(b.y-c.y,b.x-c.x);while(end<s)end+=2*PI;
  Entity e={2,c.x,c.y,radius,s*180/PI,end*180/PI,"",layer};dim.graphics.push_back(e);
  Point aa=c+Point{cos(s),sin(s)}*radius,bb=c+Point{cos(end),sin(end)}*radius;
  line(a,aa+unit(aa-c)*h*.5);line(b,bb+unit(bb-c)*h*.5);arrow(aa,{-sin(s),cos(s)});arrow(bb,{sin(end),-cos(end)});
  double mid=(s+end)/2;dim.textAt=c+Point{cos(mid),sin(mid)}*(radius-h*.8);value+="°";
 }
 Entity text={3,dim.textAt.x,dim.textAt.y,h,0,0,dim.prefix+value,layer};text.previewText=plainMtext(text.text);text.rotation=rot;text.widthFactor=.8;dim.graphics.push_back(text);
}
inline Drawing generate(const Params&p){
 auto errors=validateV3(p);if(!errors.empty())throw std::runtime_error(errors.front());
 Drawing d;d.type=p.type;auto layers=refLayers(p.type);auto layer=[&](const std::string&s){for(size_t i=0;i<layers.size();i++)if(layers[i].name==s)return (int)i;throw std::runtime_error("Missing reference layer");};
 int visible=layer("可见 (Himile)"),centre=layer("中心线 (Himile)"),dimLayer=layer("尺寸 (Himile)");
 const double papers[][2]={{1189,841},{841,594},{594,420},{420,297},{297,210}};d.sheetW=papers[p.paper][0];d.sheetH=papers[p.paper][1];
 double need=std::max({p.height/(135*d.sheetH/420),p.length/(130*d.sheetH/420),p.depth/(55*d.sheetW/594),(p.diameter+2*p.pad)*sin(p.padAngle*PI/360)/(170*d.sheetW/594)});
 const double scales[]={1,2,2.5,4,5,10,15,20,25,40,50,75,100,150,200,250,400,500,750,1000};d.recommended=1000;for(double s:scales)if(s>=need){d.recommended=s;break;}
 d.requiredRatio=need;d.ratio=p.scale?p.scale:d.recommended;double S=d.ratio;d.plotFactor=S;double W=d.sheetW*S,H=d.sheetH*S,h=3.5*S,offset=8*S;
 auto line=[&](Point a,Point b,int l,int role=0){Entity e={0,a.x,a.y,b.x,b.y,0,"",l};e.role=role;d.e.push_back(e);};
 auto rect=[&](double x,double y,double w,double ht,int role=0){line({x,y},{x+w,y},visible,role);line({x+w,y},{x+w,y+ht},visible,role);line({x+w,y+ht},{x,y+ht},visible,role);line({x,y+ht},{x,y},visible,role);};
 auto arc=[&](Point c,double r,double s,double end,int role=0){Entity e={2,c.x,c.y,r,s,end,"",visible};e.role=role;d.e.push_back(e);};
 auto circle=[&](Point c,double r,int role=0){Entity e={1,c.x,c.y,r,0,0,"",visible};e.role=role;d.e.push_back(e);};
 auto label=[&](Point a,std::string text,bool chinese=false){Entity e={3,a.x,a.y,h,0,0,text,dimLayer};e.previewText=text;if(chinese)e.style=refStyles(p.type).size()-1;d.e.push_back(e);};
 auto dim=[&](std::string key,int type,Point a,Point b,Point at,double rotation=0,Point c=Point{},std::string prefix=""){
  Dimension q;q.type=type;q.key=key;q.first=a;q.second=b;q.centre=c;q.at=at;q.rotation=rotation;q.prefix=prefix;
  if(type==0)q.measurement=std::abs(dot(b-a,{cos(rotation*PI/180),sin(rotation*PI/180)}));
  else if(type==1||type==3)q.measurement=magnitude(b-a);else if(type==2)q.measurement=magnitude(b-a);
  else {double ang=atan2(b.y-c.y,b.x-c.x)-atan2(a.y-c.y,a.x-c.x);while(ang<0)ang+=2*PI;q.measurement=ang*180/PI;}
  if(q.measurement<1e-7)return;dimensionGraphics(q,h,dimLayer);d.dimensions.push_back(q);
 };
 auto dh=[&](std::string key,Point a,Point b,double y){dim(key,0,a,b,{(a.x+b.x)/2,y});};
 auto dv=[&](std::string key,Point a,Point b,double x){dim(key,0,a,b,{x,(a.y+b.y)/2},90);};
 const double R=p.diameter/2,ro=R+p.pad,theta=p.angle*PI/360,wear=p.padAngle*PI/360;
 const double frontX=W*.72,frontY=H*.52,sideY=frontY,planY=H*.245,fixedX=W*.19,slidingX=W*.405;
 Point c={frontX,frontY+p.height};double left=frontX-p.length/2,right=frontX+p.length/2,baseTop=frontY+p.base;
 rect(left,frontY,p.length,p.base,1);arc(c,R,270-p.padAngle/2,270+p.padAngle/2,1);arc(c,ro,270-p.padAngle/2,270+p.padAngle/2,1);
 for(int sign:{-1,1})line(c+Point{sign*sin(wear),-cos(wear)}*R,c+Point{sign*sin(wear),-cos(wear)}*ro,visible,1);
 line({frontX,frontY-offset},{frontX,c.y+offset},centre);line({left-offset,c.y},{right+offset,c.y},centre);
 auto inner=innerRibPositions(p);
 // X is the distance from the base edge to the outer face, not the rib centre.
 double contactX=ro*sin(theta),contactY=c.y-ro*cos(theta),outerX=p.length/2-p.outerSetback;
 for(int iteration=0;iteration<12;iteration++){Point dir=unit(Point{contactX-outerX,contactY-baseTop});outerX=p.length/2-p.outerSetback-p.rib/(2*dir.y);}
 std::vector<double> ribBases={-outerX};ribBases.insert(ribBases.end(),inner.begin(),inner.end());ribBases.push_back(outerX);
 Point outerDir=unit(Point{contactX-outerX,contactY-baseTop});
 Point innerFace=Point{frontX+outerX,baseTop}+normal(outerDir)*(p.rib/2),fromCentre=innerFace-c;
 double projection=dot(fromCentre,outerDir),intersection=-projection-sqrt(std::max(0.,projection*projection-dot(fromCentre,fromCentre)+ro*ro));
 Point innerContact=innerFace+outerDir*intersection,radial=unit(innerContact-c),tangent=normal(radial);
 d.deg3=acos(std::clamp(std::abs(dot(outerDir,tangent)),0.,1.))*180/PI;d.webNotched=d.deg3<20;

 for(size_t i=0;i<ribBases.size();i++){
  double bx=ribBases[i],tx=(i==0?-contactX:i+1==ribBases.size()?contactX:bx),ty=c.y-sqrt(std::max(0.,ro*ro-tx*tx));
  Point direction=unit(Point{tx-bx,ty-baseTop}),perp=normal(direction);Point bottom={frontX+bx,baseTop};
  for(int sign:{-1,1}){Point a=bottom+perp*(sign*p.rib/2);a=a-direction*((a.y-baseTop)/direction.y);Point v=direction,z=a-c;double bb=dot(z,v),dis=bb*bb-dot(z,z)+ro*ro;if(dis<0)throw std::runtime_error("Rib does not intersect wear plate.");double t=-bb-sqrt(dis);Point b=a+v*t;line(a,b,visible,2);}
  if(i==0||i+1==ribBases.size()){Point mid=bottom+direction*((ty-baseTop)*.3/direction.y);dim("tw",1,mid-perp*(p.rib/2),mid+perp*(p.rib/2),mid+perp*offset);}
  if(i>0&&i+1<ribBases.size())dh("tw",{frontX+bx-p.rib/2,baseTop},{frontX+bx+p.rib/2,baseTop},baseTop+offset*(1+(i%2)));
 }
 // Web profile: the 50 mm end relief follows a radius through the vessel centre.
 double endRadius=d.webNotched?ro+50:ro;
 double endIntersection=-projection-sqrt(std::max(0.,projection*projection-dot(fromCentre,fromCentre)+endRadius*endRadius));
 Point rightNotch=innerFace+outerDir*endIntersection,rightArc=c+unit(rightNotch-c)*ro;
 Point leftNotch={2*c.x-rightNotch.x,rightNotch.y},leftArc={2*c.x-rightArc.x,rightArc.y};
 Point webBase=innerFace-outerDir*((innerFace.y-baseTop)/outerDir.y);
 line({2*c.x-webBase.x,baseTop},leftNotch,visible,7);if(d.webNotched)line(leftNotch,leftArc,visible,7);
 double webHalfAngle=atan2(rightArc.x-c.x,c.y-rightArc.y)*180/PI;
 arc(c,ro,270-webHalfAngle,270+webHalfAngle,7);if(d.webNotched)line(rightArc,rightNotch,visible,7);line(rightNotch,webBase,visible,7);

 dv("Hs",{left,frontY},{frontX,c.y},left-offset*2);dh("E",{left,frontY},{right,frontY},frontY-offset*2);
 dv("tb",{right,frontY},{right,baseTop},right+offset);dh("X",{left,baseTop},{left+p.outerSetback,baseTop},frontY-offset);
 for(size_t i=1;i<inner.size();i++)dh("di",{frontX+inner[i-1],baseTop},{frontX+inner[i],baseTop},frontY-offset*(3+(i%2)));
 dim("theta",4,c+Point{-sin(theta),-cos(theta)}*R,c+Point{sin(theta),-cos(theta)}*R,c+Point{0,-R*.45},0,c);
 dim("theta-w",4,c+Point{-sin(wear),-cos(wear)}*R,c+Point{sin(wear),-cos(wear)}*R,c+Point{0,-R*.65},0,c);
 Point padDirection={sin(wear*.8),-cos(wear*.8)};dim("tp",1,c+padDirection*R,c+padDirection*ro,c+padDirection*(R+p.pad/2)+normal(padDirection)*offset*1.5);
 label({frontX-h*2,c.y+offset},p.type?"A-A":"VIEW A");
 // Longitudinal elevations: wear plate ends have convex tangent fillets.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,by=sideY,top=by+p.height-ro*cos(wear),padBottom=by+p.height-ro;
  double pw=p.padWidth,r=p.fillet,wx=p.type?(view?1:-1)*(p.supportWidth-p.web)/2:0;
  rect(px-p.depth/2,by,p.depth,p.base,10);
  line({px-pw/2,padBottom},{px-pw/2,top-r},visible,11);arc({px-pw/2+r,top-r},r,90,180,11);
  line({px-pw/2+r,top},{px+pw/2-r,top},visible,11);arc({px+pw/2-r,top-r},r,0,90,11);line({px+pw/2,top-r},{px+pw/2,padBottom},visible,11);line({px-pw/2,padBottom},{px+pw/2,padBottom},visible,11);
  rect(px-p.supportWidth/2,by+p.base,p.supportWidth,padBottom-by-p.base,12);
  rect(px+wx-p.web/2,by+p.base,p.web,top-by-p.base-p.rib,13);
  line({px,by-offset},{px,top+offset},centre);
  Point vent={px-pw/2+p.ventOffset,padBottom+p.ventEnd};circle(vent,p.ventDiameter/2,14);line({vent.x-offset*.4,vent.y},{vent.x+offset*.4,vent.y},centre);line({vent.x,vent.y-offset*.4},{vent.x,vent.y+offset*.4},centre);
  dh("Wp",{px-pw/2,top},{px+pw/2,top},top+offset*2);dh("b",{px-p.supportWidth/2,top},{px+p.supportWidth/2,top},top+offset);
  dh("a1",{px-pw/2,vent.y},vent,vent.y+offset*.7);
  Point fc={px-pw/2+r,top-r},fp=fc+Point{-sqrt(.5),sqrt(.5)}*r;dim("R1",2,fc,fp,{px-pw/2-offset,top+offset},0,{},"4×");
 }
 // Plans share the physical rib stations, not scaled or inferred annotation endpoints.
 for(int view=0;view<2;view++){
  double px=view?slidingX:fixedX,py=planY,x0=px-p.depth/2,y0=py-p.length/2,wx=p.type?(view?1:-1)*(p.supportWidth-p.web)/2:0;
  rect(x0,y0,p.depth,p.length,3);rect(px+wx-p.web/2,y0,p.web,p.length,8);
  for(double y:ribBases)rect(px-p.supportWidth/2,py+y-p.rib/2,p.supportWidth,p.rib,4);
  line({px,y0-offset},{px,y0+p.length+offset},centre);line({x0-offset,py},{x0+p.depth+offset,py},centre);
  std::vector<int> rows=p.type?std::vector<int>{view?-1:1}:std::vector<int>{-1,1};
  for(int row:rows)for(int i=0;i<p.holes;i++){
   double x=px+row*(p.depth/2-p.edgeY),y=py-p.length/2+p.edgeX+(p.length-2*p.edgeX)*i/(p.holes-1),rad=p.hole/2,straight=view?p.slot-p.hole:0;
   if(straight<1e-8)circle({x,y},rad,view?6:5);else {arc({x-straight/2,y},rad,90,270,6);arc({x+straight/2,y},rad,270,450,6);line({x-straight/2,y+rad},{x+straight/2,y+rad},visible,6);line({x-straight/2,y-rad},{x+straight/2,y-rad},visible,6);}
   line({x-rad-h*.5,y},{x+rad+h*.5,y},centre);line({x,y-rad-h*.5},{x,y+rad+h*.5},centre);
   if(std::abs(y-py)>1e-7)dv("a2",{x,py},{x,y},row<0?x0-offset*(1.2+i*.75):x0+p.depth+offset*(1.2+i*.75));
   if(i==0&&row==rows.front()){
    dim("bolt-diameter",3,{x,y-rad},{x,y+rad},{x+p.depth*.65,y+offset},0,{},std::to_string(totalHoles(p))+"×");
    if(view&&straight>1e-8)dh("a4",{x-straight/2,y+rad},{x+straight/2,y+rad},y+rad+offset);
   }
  }
  dv("E",{x0,y0},{x0,y0+p.length},view?x0+p.depth+offset*2:x0-offset*(p.holes*.75+2));
  dh("F",{x0,y0+p.length},{x0+p.depth,y0+p.length},y0+p.length+offset*2);
  if(!p.type)dh("a3",{px-p.depth/2+p.edgeY,py},{px+p.depth/2-p.edgeY,py},py-offset*2);
  dh("ts",{px+wx-p.web/2,py},{px+wx+p.web/2,py},py+offset*1.4);
  label({px-p.depth/2,y0-offset*2},view?"Sliding Saddle":"Fixed Saddle");
  label({px-p.depth/2,y0-offset},view?"滑动鞍座":"固定鞍座",true);
 }
 label({W*.27,H*.48},"B-B");label({W*.81,H*.93},"1 : "+num(d.ratio));
 d.modelCount=d.e.size()+d.dimensions.size();d.minX=d.minY=0;d.maxX=W;d.maxY=H;return d;
}
}
