// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
namespace saddle {
inline std::vector<unsigned> cadCodepoints(const std::string&s){std::vector<unsigned> out;for(size_t i=0;i<s.size();){unsigned c=(unsigned char)s[i++];if(c>=128){int n=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:3;c&=n==1?31:n==2?15:7;while(n--&&i<s.size())c=(c<<6)|((unsigned char)s[i++]&63);}out.push_back(c);}return out;}
inline double cadDimensionTextWidth(const Entity&e){double sum=0;for(unsigned c:cadCodepoints(plainMtext(e.text))){if(c>=32&&c<=126){static const int advance[]={278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584};sum+=advance[c-32];}else if(c==0x00d7||c==0x00b1)sum+=584;else if(c==0x00b0)sum+=400;else if(c==0x00d8)sum+=778;else sum+=556;}return sum/716*e.a*e.widthFactor;}
}
