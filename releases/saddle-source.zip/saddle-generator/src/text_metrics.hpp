// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
namespace saddle {
inline std::vector<unsigned> cadCodepoints(const std::string&s){std::vector<unsigned> out;for(size_t i=0;i<s.size();){unsigned c=(unsigned char)s[i++];if(c>=128){int n=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:3;c&=n==1?31:n==2?15:7;while(n--&&i<s.size())c=(c<<6)|((unsigned char)s[i++]&63);}out.push_back(c);}return out;}
inline double cadDimensionTextWidth(const Entity&e){double sum=0;for(unsigned c:cadCodepoints(plainMtext(e.text))){if(c>='0'&&c<='9')sum+=556;else if(c=='.'||c==' ')sum+=278;else if(c=='('||c==')'||c=='-')sum+=333;else if(c=='R')sum+=722;else if(c==0x00d7||c==0x00b1)sum+=584;else if(c==0x00b0)sum+=400;else if(c==0x00d8)sum+=778;else sum+=556;}return sum/716*e.a*e.widthFactor;}
}
