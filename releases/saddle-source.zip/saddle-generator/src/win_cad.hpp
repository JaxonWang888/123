// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <stdexcept>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdio>
#include <oleauto.h>
#include <objbase.h>
#include <uiautomationclient.h>
#include <atomic>
#include <thread>
#include <mutex>
#include <chrono>
#include <cwctype>
#include <exception>
#include "native_bom_job.hpp"
#include "dimension_job.hpp"
namespace saddlecad {
inline std::string utf8(const std::wstring&s){int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);std::string out(n,0);if(n)WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),out.data(),n,nullptr,nullptr);return out;}
inline std::wstring wideError(const std::string&s){int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring out(n,0);if(n)MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),out.data(),n);return out;}
inline void writeLog(const std::wstring&path,const std::wstring&value){auto data=utf8(value);HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot write AutoCAD processing log");DWORD done=0;BOOL ok=WriteFile(h,data.data(),(DWORD)data.size(),&done,nullptr);CloseHandle(h);if(!ok||done!=data.size())throw std::runtime_error("Cannot finish AutoCAD processing log");}
struct Value {
 VARIANT v;Value(){VariantInit(&v);}explicit Value(const std::wstring&s):Value(){v.vt=VT_BSTR;v.bstrVal=SysAllocStringLen(s.data(),(UINT)s.size());}explicit Value(const wchar_t*s):Value(std::wstring(s)){}explicit Value(double d):Value(){v.vt=VT_R8;v.dblVal=d;}explicit Value(long n):Value(){v.vt=VT_I4;v.lVal=n;}explicit Value(bool b):Value(){v.vt=VT_BOOL;v.boolVal=b?VARIANT_TRUE:VARIANT_FALSE;}explicit Value(IDispatch*p):Value(){v.vt=VT_DISPATCH;v.pdispVal=p;if(p)p->AddRef();}
 Value(const Value&o):Value(){VariantCopy(&v,const_cast<VARIANT*>(&o.v));}Value(Value&&o)noexcept:v(o.v){VariantInit(&o.v);}Value&operator=(Value o){std::swap(v,o.v);return *this;}~Value(){VariantClear(&v);}
 std::wstring str()const{VARIANT x;VariantInit(&x);if(FAILED(VariantChangeType(&x,const_cast<VARIANT*>(&v),0,VT_BSTR)))throw std::runtime_error("AutoCAD returned non-text value");std::wstring s=x.bstrVal?x.bstrVal:L"";VariantClear(&x);return s;}
 double number()const{VARIANT x;VariantInit(&x);if(FAILED(VariantChangeType(&x,const_cast<VARIANT*>(&v),0,VT_R8)))throw std::runtime_error("AutoCAD returned non-numeric value");double n=x.dblVal;VariantClear(&x);return n;}
 bool boolean()const{return number()!=0;}
};
inline void pump(unsigned ms){ULONGLONG end=GetTickCount64()+ms;do{MSG m;while(PeekMessageW(&m,nullptr,0,0,PM_REMOVE)){TranslateMessage(&m);DispatchMessageW(&m);}Sleep(10);}while(GetTickCount64()<end);}
struct ComError:std::runtime_error {HRESULT code;ComError(HRESULT result,const std::string&message):std::runtime_error(message),code(result){}};
struct Object {
 IDispatch*p=nullptr;Object()=default;explicit Object(IDispatch*value,bool add=true):p(value){if(p&&add)p->AddRef();}explicit Object(const Value&value){if(value.v.vt!=VT_DISPATCH||!value.v.pdispVal)throw std::runtime_error("AutoCAD did not return an object");p=value.v.pdispVal;p->AddRef();}Object(const Object&o):Object(o.p){}Object(Object&&o)noexcept:p(o.p){o.p=nullptr;}Object&operator=(Object o){std::swap(p,o.p);return *this;}~Object(){if(p)p->Release();}
 Value invoke(const wchar_t*name,WORD flags,std::vector<Value> args={})const{
  if(!p)throw std::runtime_error("AutoCAD object is unavailable");LPOLESTR key=const_cast<wchar_t*>(name);DISPID id;HRESULT hr;ULONGLONG namesUntil=GetTickCount64()+120000;do{hr=p->GetIDsOfNames(IID_NULL,&key,1,LOCALE_USER_DEFAULT,&id);if(hr!=RPC_E_CALL_REJECTED&&hr!=RPC_E_SERVERCALL_RETRYLATER)break;pump(150);}while(GetTickCount64()<namesUntil);if(FAILED(hr))throw ComError(hr,"AutoCAD property is unavailable: "+utf8(name));
  std::vector<VARIANT> ordered;for(auto it=args.rbegin();it!=args.rend();++it)ordered.push_back(it->v);DISPID property=DISPID_PROPERTYPUT;DISPPARAMS params={};params.rgvarg=ordered.data();params.cArgs=(UINT)ordered.size();if(flags&(DISPATCH_PROPERTYPUT|DISPATCH_PROPERTYPUTREF)){params.rgdispidNamedArgs=&property;params.cNamedArgs=1;}
  ULONGLONG until=GetTickCount64()+120000;
  for(;;){Value out;EXCEPINFO error={};UINT index=0;hr=p->Invoke(id,IID_NULL,LOCALE_USER_DEFAULT,flags,&params,&out.v,&error,&index);std::wstring detail=error.bstrDescription?error.bstrDescription:L"";SysFreeString(error.bstrSource);SysFreeString(error.bstrDescription);SysFreeString(error.bstrHelpFile);
   if(SUCCEEDED(hr))return out;
   if((hr==RPC_E_CALL_REJECTED||hr==RPC_E_SERVERCALL_RETRYLATER)&&GetTickCount64()<until){pump(150);continue;}
   char code[32];snprintf(code,sizeof(code)," (0x%08lX)",(unsigned long)hr);throw ComError(hr,"AutoCAD "+utf8(name)+code+(detail.empty()?"":": "+utf8(detail)));
  }
 }
 Value get(const wchar_t*key)const{return invoke(key,DISPATCH_PROPERTYGET);}Object obj(const wchar_t*key)const{return Object(get(key));}void put(const wchar_t*key,Value value)const{bool reference=value.v.vt==VT_DISPATCH;try{invoke(key,reference?DISPATCH_PROPERTYPUTREF:DISPATCH_PROPERTYPUT,{value});}catch(const ComError&e){if(!reference||e.code!=DISP_E_MEMBERNOTFOUND)throw;invoke(key,DISPATCH_PROPERTYPUT,{value});}}Value call(const wchar_t*key,std::vector<Value> args={})const{return invoke(key,DISPATCH_METHOD,std::move(args));}Object item(Value key)const{return Object(invoke(L"Item",DISPATCH_METHOD|DISPATCH_PROPERTYGET,{key}));}
};
inline std::wstring windowText(HWND h){int n=GetWindowTextLengthW(h);std::wstring value(n+1,0);GetWindowTextW(h,value.data(),n+1);value.resize(n);return value;}
inline std::wstring compact(std::wstring value){std::wstring out;for(wchar_t c:value)if(!iswspace(c)&&c!=L'&')out+=towlower(c);return out;}
inline bool contains(const std::wstring&value,const wchar_t*key){return value.find(key)!=std::wstring::npos;}
enum class Prompt {None,Foreign,CancelOpen,Repair,Repaired};
inline Prompt promptKind(const std::wstring&title,const std::wstring&body){auto t=compact(title),b=compact(body);
 if(contains(t,L"外来dwg")||contains(t,L"foreigndwg")||contains(t,L"non-autodesk"))return Prompt::Foreign;
 if((contains(t,L"打开图形")||contains(t,L"opendrawing"))&&(contains(b,L"取消这次打开")||contains(b,L"cancelthisopen")))return Prompt::CancelOpen;
 if((contains(t,L"打开图形")||contains(t,L"opendrawing"))&&(contains(b,L"已修复图形文件")||contains(b,L"drawingfilehasbeenrepaired")))return Prompt::Repaired;
 if((contains(t,L"打开图形")||contains(t,L"opendrawing"))&&(contains(b,L"图形文件需要修复")||contains(b,L"drawingfilerequiresrecovery")||contains(b,L"drawingfilerequiresrepair")))return Prompt::Repair;
 return Prompt::None;
}
inline bool matchesButton(Prompt kind,const std::wstring&caption,int id){auto b=compact(caption);
 if(kind==Prompt::Foreign)return contains(b,L"继续打开dwg文件")||contains(b,L"continueopening")||contains(b,L"openanyway");
 if(kind==Prompt::CancelOpen)return id==IDNO||b==L"否(n)"||b==L"否"||b==L"no"||b==L"no(n)";
 if(kind==Prompt::Repair)return b.rfind(L"修复",0)==0||b==L"recover"||b==L"repair";
 if(kind==Prompt::Repaired)return id==IDCLOSE||id==IDOK||contains(b,L"关闭")||b==L"close"||b==L"ok"||b==L"确定";
 return false;
}
struct DialogContent {std::wstring body;std::vector<HWND>buttons;};
inline BOOL CALLBACK readChild(HWND h,LPARAM context){auto&content=*(DialogContent*)context;auto text=windowText(h);if(!text.empty())content.body+=text+L"\n";wchar_t cls[128]={};GetClassNameW(h,cls,128);if(!_wcsicmp(cls,L"Button"))content.buttons.push_back(h);return TRUE;}
template<class T>struct Ref {T*p=nullptr;Ref()=default;Ref(const Ref&)=delete;Ref&operator=(const Ref&)=delete;Ref(Ref&&o)noexcept:p(o.p){o.p=nullptr;}~Ref(){if(p)p->Release();}T**out(){return &p;}};
static const GUID automationClass={0xff48dba4,0x60ef,0x4201,{0xaa,0x87,0x54,0x10,0x3e,0xef,0x59,0x4e}};
static const GUID automationInterface={0x30cbe57d,0xd9d0,0x452a,{0xab,0x13,0x7a,0xc5,0xac,0x48,0x25,0xee}};
static const GUID invokeInterface={0xfb377fbe,0x8ea6,0x46d5,{0x9c,0x73,0x64,0x99,0x64,0x2d,0x30,0x59}};
#include "win_table_dialog.inc"
struct DialogWatcher {
 std::atomic<bool> tableRequested{false};std::atomic<int> tableResult{0};std::wstring tableError;
 std::atomic<bool> stop{false},opening{false};std::atomic<DWORD>pid{0};std::thread thread;std::wstring target,additionalTarget,events;IUIAutomation*accessible=nullptr;std::mutex mutex;std::map<HWND,ULONGLONG>clicked;
 explicit DialogWatcher(std::wstring file,std::wstring additional=L""):target(std::move(file)),additionalTarget(std::move(additional)){}
 ~DialogWatcher(){stop=true;if(thread.joinable())thread.join();}
 static BOOL CALLBACK visit(HWND h,LPARAM data){((DialogWatcher*)data)->check(h);return TRUE;}
 void check(HWND h){if((!opening&&!tableRequested)||!IsWindowVisible(h))return;DWORD owner=0;GetWindowThreadProcessId(h,&owner);if(!pid||owner!=pid)return;if(tableRequested&&nativeTableDialog(h)){try{configureTableDialog(h);tableResult=1;}catch(const std::exception&e){{std::lock_guard<std::mutex>lock(mutex);tableError=wideError(e.what());}tableResult=-1;HWND cancel=GetDlgItem(h,IDCANCEL);if(cancel)SendMessageW(cancel,BM_CLICK,0,0);}tableRequested=false;return;}auto title=windowText(h);auto shortTitle=compact(title);if(!contains(shortTitle,L"外来dwg")&&!contains(shortTitle,L"foreigndwg")&&!contains(shortTitle,L"non-autodesk")&&!contains(shortTitle,L"打开图形")&&!contains(shortTitle,L"opendrawing"))return;DialogContent content;EnumChildWindows(h,readChild,(LPARAM)&content);auto kind=promptKind(title,content.body);if(kind==Prompt::None){checkAccessible(h,title);return;}
  // If a prompt names a DWG path, it must name this export, not another file.
  auto full=compact(content.body),base=compact(target.substr(target.find_last_of(L"\\/")+1));if((contains(full,L":\\")||contains(full,L".dwg"))&&!contains(full,base.c_str())&&(additionalTarget.empty()||!contains(full,compact(additionalTarget.substr(additionalTarget.find_last_of(L"\\/")+1)).c_str())))return;
  if(clicked.count(h)&&GetTickCount64()-clicked[h]<1500)return;
  for(HWND button:content.buttons)if(IsWindowEnabled(button)&&matchesButton(kind,windowText(button),GetDlgCtrlID(button))){std::lock_guard<std::mutex> lock(mutex);events+=L"[自动处理提示] "+title+L"\n"+content.body+L"[选择] "+windowText(button)+L"\n\n";clicked[h]=GetTickCount64();if(!PostMessageW(button,BM_CLICK,0,0))events+=L"[发送失败] Windows 错误 "+std::to_wstring(GetLastError())+L"；请确认两程序运行权限相同。\n";return;}
  checkAccessible(h,title);
 }
 void checkAccessible(HWND h,const std::wstring&title){
  if(!accessible)return;Ref<IUIAutomationElement>root;Ref<IUIAutomationCondition>condition;Ref<IUIAutomationElementArray>all;
  if(FAILED(accessible->ElementFromHandle((UIA_HWND)h,root.out()))||!root.p||FAILED(accessible->CreateTrueCondition(condition.out()))||FAILED(root.p->FindAll(TreeScope_Descendants,condition.p,all.out()))||!all.p)return;
  struct Button {Ref<IUIAutomationElement>element;std::wstring caption;};std::vector<Button>buttons;std::wstring body;int count=0;all.p->get_Length(&count);
  for(int i=0;i<count;i++){Ref<IUIAutomationElement>e;if(FAILED(all.p->GetElement(i,e.out()))||!e.p)continue;BSTR text=nullptr;e.p->get_CurrentName(&text);std::wstring name=text?text:L"";SysFreeString(text);if(!name.empty())body+=name+L"\n";CONTROLTYPEID type=0;BOOL enabled=FALSE;int process=0;e.p->get_CurrentControlType(&type);e.p->get_CurrentIsEnabled(&enabled);e.p->get_CurrentProcessId(&process);if(type==UIA_ButtonControlTypeId&&enabled&&(DWORD)process==pid)buttons.push_back({std::move(e),name});}
  auto kind=promptKind(title,body);if(kind==Prompt::None)return;auto full=compact(body),base=compact(target.substr(target.find_last_of(L"\\/")+1));if((contains(full,L":\\")||contains(full,L".dwg"))&&!contains(full,base.c_str())&&(additionalTarget.empty()||!contains(full,compact(additionalTarget.substr(additionalTarget.find_last_of(L"\\/")+1)).c_str())))return;
  if(clicked.count(h)&&GetTickCount64()-clicked[h]<1500)return;
  for(auto&button:buttons)if(matchesButton(kind,button.caption,0)){Ref<IUnknown>pattern;Ref<IUIAutomationInvokePattern>invoke;if(FAILED(button.element.p->GetCurrentPattern(UIA_InvokePatternId,pattern.out()))||!pattern.p||FAILED(pattern.p->QueryInterface(invokeInterface,(void**)invoke.out())))continue;
   HRESULT result=invoke.p->Invoke();if(SUCCEEDED(result)){std::lock_guard<std::mutex>lock(mutex);events+=L"[UIAutomation 自动处理提示] "+title+L"\n"+body+L"[选择] "+button.caption+L"\n\n";clicked[h]=GetTickCount64();}return;
  }
 }
 void start(){thread=std::thread([this]{HRESULT init=CoInitializeEx(nullptr,COINIT_MULTITHREADED);if(SUCCEEDED(init))CoCreateInstance(automationClass,nullptr,CLSCTX_INPROC_SERVER,automationInterface,(void**)&accessible);while(!stop){if(opening||tableRequested)EnumWindows(visit,(LPARAM)this);Sleep(150);}if(accessible){accessible->Release();accessible=nullptr;}if(SUCCEEDED(init))CoUninitialize();});}
 std::wstring report(){std::lock_guard<std::mutex> lock(mutex);return events;}
};
inline std::wstring fullPath(const std::wstring&file){DWORD n=GetFullPathNameW(file.c_str(),0,nullptr,nullptr);if(!n)throw std::runtime_error("Cannot resolve drawing path");std::wstring out(n,0);DWORD used=GetFullPathNameW(file.c_str(),n,out.data(),nullptr);if(!used||used>=n)throw std::runtime_error("Invalid drawing path");out.resize(used);return out;}
inline bool samePath(const std::wstring&a,const std::wstring&b){return !_wcsicmp(fullPath(a).c_str(),fullPath(b).c_str());}
inline std::wstring makeBackup(const std::wstring&file){auto base=file.substr(0,file.size()-4)+L".自动处理前备份";for(int i=0;i<10000;i++){auto path=base+(i?L"("+std::to_wstring(i+1)+L")":L"")+file.substr(file.size()-4);if(CopyFileW(file.c_str(),path.c_str(),TRUE))return path;if(GetLastError()!=ERROR_FILE_EXISTS&&GetLastError()!=ERROR_ALREADY_EXISTS)throw std::runtime_error("Cannot preserve the original DWG backup");}throw std::runtime_error("Too many AutoCAD backups");}
inline Object connect2018(){
 // Mechanical 2018 exposes the shared AutoCAD 22 ActiveX interface. Reuse only
 // that major version, so another installed AutoCAD version is not changed.
 for(const wchar_t*name:{L"AutoCAD.Application.22",L"AutoCAD.Application.22.0"}){CLSID cls;if(FAILED(CLSIDFromProgID(name,&cls)))continue;IUnknown*unknown=nullptr;if(SUCCEEDED(GetActiveObject(cls,nullptr,&unknown))&&unknown){IDispatch*dispatch=nullptr;HRESULT hr=unknown->QueryInterface(IID_IDispatch,(void**)&dispatch);unknown->Release();if(SUCCEEDED(hr))return Object(dispatch,false);}}
 for(const wchar_t*name:{L"AutoCAD.Application.22",L"AutoCAD.Application.22.0"}){CLSID cls;if(FAILED(CLSIDFromProgID(name,&cls)))continue;IDispatch*dispatch=nullptr;if(SUCCEEDED(CoCreateInstance(cls,nullptr,CLSCTX_LOCAL_SERVER,IID_IDispatch,(void**)&dispatch)))return Object(dispatch,false);}
 throw std::runtime_error("未找到或无法连接 AutoCAD / AutoCAD Mechanical 2018 的 ActiveX 接口。DWG 已导出；请确认 2018 已完成首次启动，且两程序以相同权限运行。" );
}
inline bool dimensionName(const std::wstring&name){return name.rfind(L"AcDb",0)==0&&name.find(L"Dimension")!=std::wstring::npos;}
#include "dimension_tolerance.inc"
struct DimensionRecord {Object entity;Value linear,text;bool hasLinear=false,hasText=false;DimensionToleranceSnapshot tolerance;};
inline void verifyDimensions(const std::vector<DimensionRecord>&records,double scale){for(auto&r:records){auto&e=r.entity;
 verifyDimensionTolerance(e,r.tolerance);
 if(e.get(L"StyleName").str()!=L"HM-ASME 1-1"||fabs(e.get(L"TextRotation").number())>1e-10||fabs(e.get(L"ScaleFactor").number()-scale)>1e-8*std::max(1.,scale))throw std::runtime_error("AutoCAD dimension property verification failed");
 if(r.hasText&&e.get(L"TextOverride").str()!=r.text.str())throw std::runtime_error("Actual-size dimension text changed during normalization");
 if(r.hasLinear&&fabs(e.get(L"LinearScaleFactor").number()-r.linear.number())>1e-10)throw std::runtime_error("Actual-size measurement factor changed during normalization");
}}
struct BatchResult {unsigned dimensions=0,blocks=0,tolerances=0;std::vector<DimensionRecord>records;};
inline BatchResult normalizeDimensions(const Object&doc,double scale,unsigned expectedDimensions=0){
 auto blocks=doc.obj(L"Blocks");long count=(long)blocks.get(L"Count").number();BatchResult result;
 for(long i=0;i<count;i++){auto block=blocks.item(Value(i));bool xref=false;try{xref=block.get(L"IsXRef").boolean();}catch(...){throw std::runtime_error("Cannot determine whether a CAD block is an external reference");}if(xref)continue;result.blocks++;
  long entities=(long)block.get(L"Count").number();for(long j=0;j<entities;j++){auto entity=block.item(Value(j));if(!dimensionName(entity.get(L"ObjectName").str()))continue;
   // Keep the actual-size text and linear measurement factor of enlarged holes.
   Value linear,text;bool hasLinear=false,hasText=true;try{linear=entity.get(L"LinearScaleFactor");hasLinear=true;}catch(const ComError&e){if(e.code!=DISP_E_MEMBERNOTFOUND&&e.code!=DISP_E_UNKNOWNNAME)throw;}text=entity.get(L"TextOverride");
   auto tolerance=captureDimensionTolerance(entity);if(tolerance.properties.front().second.number()!=0)result.tolerances++;result.records.push_back({entity,linear,text,hasLinear,hasText,tolerance});result.dimensions++;
  }
 }
 if(!result.dimensions)throw std::runtime_error("No native dimensions were found; drawing was not saved automatically");
 if(expectedDimensions&&result.dimensions<expectedDimensions)throw std::runtime_error("原生尺寸数量少于导出时的数量，未自动修改标注。请检查修复后的图纸。" );
 // Capture every dimension before changing even the shared dimension style.
 auto styles=doc.obj(L"DimStyles");Object style;
 try{style=styles.item(Value(L"HM-ASME 1-1"));}catch(...){style=Object(styles.call(L"Add",{Value(L"HM-ASME 1-1")}));style.call(L"CopyFrom",{doc.get(L"ActiveDimStyle")});}
 doc.put(L"ActiveDimStyle",Value(style.p));doc.call(L"SetVariable",{Value(L"DIMSCALE"),Value(scale)});style.call(L"CopyFrom",{Value(doc.p)});doc.put(L"ActiveDimStyle",Value(style.p));
 // Snapshot entity references before modifying dimensions: regeneration may
 // replace anonymous display blocks while the block table is being enumerated.
 for(auto&r:result.records){auto&entity=r.entity;entity.put(L"StyleName",Value(L"HM-ASME 1-1"));if(r.hasLinear)entity.put(L"LinearScaleFactor",r.linear);if(r.hasText)entity.put(L"TextOverride",r.text);entity.put(L"ScaleFactor",Value(scale));entity.put(L"TextRotation",Value(0.0));entity.call(L"Update");}

 doc.call(L"Regen",{Value(1L)});
 // Tolerances are deliberately the last entity-formatting pass, after every
 // dimension has changed style and the style changes have regenerated.
 for(auto&r:result.records){restoreDimensionTolerance(r.entity,r.tolerance);r.entity.call(L"Update");}
 verifyDimensions(result.records,scale);if(fabs(doc.call(L"GetVariable",{Value(L"DIMSCALE")}).number()-scale)>1e-8*std::max(1.,scale))throw std::runtime_error("AutoCAD global dimension scale verification failed");return result;
}
inline unsigned repairDeletedObjects(const std::wstring&report){for(const wchar_t*key:{L"删除的对象",L"Objects deleted",L"Objects erased"}){auto at=report.find(key);if(at==std::wstring::npos)continue;at+=wcslen(key);size_t end=std::min(report.size(),at+24);while(at<end&&!iswdigit(report[at]))at++;unsigned count=0;while(at<end&&iswdigit(report[at])){count=std::min(1000000U,count*10+(unsigned)(report[at]-L'0'));at++;}if(count)return count;}return 0;}
#include "win_native_bom.inc"
inline std::array<double,3> dimensionPointValue(const Value&v){
 if(!(v.v.vt&VT_ARRAY)||!v.v.parray)throw std::runtime_error("CAD returned an invalid dimension point");long lo=0,hi=-1;SafeArrayGetLBound(v.v.parray,1,&lo);SafeArrayGetUBound(v.v.parray,1,&hi);if(hi-lo!=2)throw std::runtime_error("CAD dimension point is not 3D");VARTYPE type=VT_EMPTY;if(FAILED(SafeArrayGetVartype(v.v.parray,&type)))throw std::runtime_error("Cannot read dimension point type");std::array<double,3> p{};
 for(long i=0;i<3;i++){long at=lo+i;if(type==VT_R8){if(FAILED(SafeArrayGetElement(v.v.parray,&at,&p[i])))throw std::runtime_error("Cannot read dimension point");}else if(type==VT_VARIANT){Value item;if(FAILED(SafeArrayGetElement(v.v.parray,&at,&item.v)))throw std::runtime_error("Cannot read dimension point");p[i]=item.number();}else throw std::runtime_error("Unsupported dimension point type");if(!std::isfinite(p[i]))throw std::runtime_error("Invalid dimension coordinate");}return p;
}
inline Value dimensionPoint(const std::array<double,3>&p){return bomPoint(p[0],p[1]);}
inline void waitDimensionBridge(const Object&doc){auto until=GetTickCount64()+10000;do{if(doc.call(L"GetVariable",{Value(L"CMDACTIVE")}).number()==0&&doc.call(L"GetVariable",{Value(L"USERS5")}).str()!=L"SADDLE_PENDING")return;pump(50);}while(GetTickCount64()<until);throw std::runtime_error("读取尺寸定义点超时，未继续修改。" );}
#include "dimension_endpoints.inc"
#include "dimension_apply.inc"

inline int processFile(const std::wstring&file,double scale,unsigned expected,unsigned expectedDimensions=0,const std::wstring&templatePath=L"",bool normalize=true){
 if(!std::isfinite(scale)||scale<=0||file.size()<4)return 2;auto path=fullPath(file),logPath=path+L".自动处理.log";std::wstring backup,report=L"目标图纸："+path+L"\n图纸比例 1:"+std::to_wstring(scale)+L"\n";bool saved=false;
 HANDLE mutex=CreateMutexW(nullptr,FALSE,L"Local\\SaddleAutoCADPostProcess");DWORD lockResult=mutex?WaitForSingleObject(mutex,0):WAIT_FAILED;if(lockResult!=WAIT_OBJECT_0&&lockResult!=WAIT_ABANDONED){if(mutex)CloseHandle(mutex);MessageBoxW(nullptr,L"DWG 已导出，但另一个 AutoCAD 自动整理任务尚未结束。请待其结束后再次导出。",L"未启动第二个整理任务",MB_OK|MB_ICONINFORMATION);return 3;}
 HRESULT initialized=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);DialogWatcher watcher(path,templatePath);
 try{
  if(FAILED(initialized))throw std::runtime_error("Cannot initialize Windows COM automation");
  auto app=connect2018();app.put(L"Visible",Value(true));auto handle=app.get(L"HWND");auto cadWindow=(HWND)(ULONG_PTR)(handle.v.vt==VT_I4?(ULONG_PTR)(DWORD)handle.v.lVal:(ULONG_PTR)handle.number());DWORD process=0;GetWindowThreadProcessId(cadWindow,&process);if(!process)throw std::runtime_error("Cannot identify the AutoCAD process; no dialogs will be clicked");watcher.pid=process;watcher.start();
  auto documents=app.obj(L"Documents");long n=(long)documents.get(L"Count").number();
  for(long i=n-1;i>=0;i--){auto existing=documents.item(Value(i));auto name=existing.get(L"FullName").str();if(!name.empty()&&samePath(name,path)){if(!existing.get(L"Saved").boolean())throw std::runtime_error("目标图纸在 AutoCAD 中有未保存修改，已停止自动处理。请先保存或关闭该图纸后重试。" );existing.call(L"Close",{Value(false)});}}
  backup=makeBackup(path);report+=L"原始备份："+backup+L"\n";writeLog(logPath,report+L"正在打开图纸……\n");
  watcher.opening=true;Object doc;
  try{doc=Object(documents.call(L"Open",{Value(path),Value(false)}));}catch(const std::exception&e){
   // Recovery can finish in a document even when the original Open call returns
   // an error. Accept only the exact exported path, never whichever tab is active.
   report+=L"Open 接口返回："+wideError(e.what())+L"\n";ULONGLONG until=GetTickCount64()+30000;
   do{try{long count=(long)documents.get(L"Count").number();for(long i=0;i<count;i++){auto candidate=documents.item(Value(i));auto name=candidate.get(L"FullName").str();if(!name.empty()&&samePath(name,path)){doc=candidate;break;}}}catch(...){}if(doc.p)break;pump(200);}while(GetTickCount64()<until);
   if(!doc.p){watcher.opening=false;throw;}
  }
  if(!samePath(doc.get(L"FullName").str(),path))throw std::runtime_error("AutoCAD returned a different drawing; no changes were applied");
  if(doc.get(L"ReadOnly").boolean())throw std::runtime_error("目标图纸为只读，未自动修改。" );
  if(repairDeletedObjects(watcher.report()))throw std::runtime_error("修复报告显示删除了对象，已停止自动修改和保存。请检查原图备份与 AutoCAD 中修复后的图纸。" );
  unsigned original=(unsigned)doc.obj(L"ModelSpace").get(L"Count").number();if(expected&&original<expected)throw std::runtime_error("打开/修复后模型对象数量减少，已停止自动修改和保存。请检查 AutoCAD 中的图纸及原始备份。" );
  doc.call(L"Activate");auto planPath=path+L".标注数据";bool hasPlan=GetFileAttributesW(planPath.c_str())!=INVALID_FILE_ATTRIBUTES;std::vector<PlannedDimension> dimensionTasks;if(!hasPlan&&expectedDimensions)throw std::runtime_error("缺少同名.标注数据文件，无法校验并补写原始公差，请使用V35重新导出。" );if(hasPlan){auto plan=readDimensionJob(readNativeBomFile(planPath));if(expectedDimensions&&plan.dimensions!=expectedDimensions)throw std::runtime_error("标注计划与导出尺寸数不符。" );dimensionTasks=bindDimensionTasks(doc,plan);}else report+=L"未提供生成标注计划：仅保留CAD当前公差，不声称恢复未识别的原始公差。\n";unsigned bomRows=0;auto bomPath=path+L".BOM数据";bool hasBom=GetFileAttributesW(bomPath.c_str())!=INVALID_FILE_ATTRIBUTES;if(hasBom){auto job=readBomJob(readNativeBomFile(bomPath));bomRows=createCommandBom(doc,documents,templatePath,job,watcher,0,0,scale);report+=L"BOM：原生TABLE命令，明细栏样式，从样式开始，额外列/行0，填写"+std::to_wstring(bomRows)+L"行；名称及规格明细左中对齐、左右水平边距2×图纸比例；其他明细格水平及垂直边距1×图纸比例；表头边距保留模板，其余单元格正中对齐。\n";}watcher.opening=false;BatchResult result;if(normalize){result=normalizeDimensions(doc,scale,expectedDimensions);report+=L"已保留原有尺寸公差："+std::to_wstring(result.tolerances)+L"个；公差数值不随图纸比例缩放。\n";}if(normalize&&expectedDimensions&&result.dimensions<expectedDimensions)throw std::runtime_error("找到的原生尺寸少于导出时的数量，可能有尺寸被修复或转换。未自动保存，请检查图纸。" );if((unsigned)doc.obj(L"ModelSpace").get(L"Count").number()<original)throw std::runtime_error("标注整理后对象数量减少，未自动保存。" );
  // Finish ALL dimension styles and text positioning before the final tolerance pass.
  if(hasPlan){placeDimensionTasks(dimensionTasks);doc.call(L"Regen",{Value(1L)});}
  if(normalize)for(auto&r:result.records){restoreDimensionTolerance(r.entity,r.tolerance);r.entity.call(L"Update");}
  if(hasPlan){applyDimensionTolerancesLast(dimensionTasks);syncGeneratedTolerances(result,dimensionTasks);verifyDimensionTasks(dimensionTasks);unsigned count=0;for(auto&t:dimensionTasks)if(t.task.tolerance>0)count++;report+=L"最终标注阶段：根据生成数据补写并校验"+std::to_wstring(count)+L"个原生尺寸公差；指定数字位置已校验。\n";}
  if(normalize)verifyDimensions(result.records,scale);
  if(hasBom){long format=!_wcsicmp(path.substr(path.size()-4).c_str(),L".dxf")?61L:60L;doc.call(L"SaveAs",{Value(path),Value(format)});}else doc.call(L"Save");if(normalize)verifyDimensions(result.records,scale);if(hasPlan)verifyDimensionTasks(dimensionTasks);if(!doc.get(L"Saved").boolean())throw std::runtime_error("AutoCAD did not confirm that the drawing was saved");
  report+=watcher.report()+L"完成：已处理 "+std::to_wstring(result.dimensions)+L" 个尺寸标注；已按选项整理样式、旋转与全局比例 "+std::to_wstring(scale)+L"。\n已保存，图纸保留在 AutoCAD 中打开。\n";writeLog(logPath,report);saved=true;

 }catch(const std::exception&e){watcher.opening=false;report+=watcher.report()+L"未完成："+wideError(e.what())+L"\n";try{writeLog(logPath,report);}catch(...){}MessageBoxW(nullptr,(L"基础图纸已导出，AutoCAD处理未完成；原生BOM可能尚未生成。\n\n"+wideError(e.what())+L"\n\n"+(backup.empty()?L"":L"原始备份："+backup+L"\n")+L"日志："+logPath+L"\n未知提示不会自动点击。请在 AutoCAD 中检查当前图纸。" ).c_str(),L"自动整理未完成",MB_OK|MB_ICONWARNING);}
 watcher.stop=true;if(watcher.thread.joinable())watcher.thread.join();if(SUCCEEDED(initialized))CoUninitialize();ReleaseMutex(mutex);CloseHandle(mutex);return saved?0:4;
}
inline std::wstring quote(const std::wstring&arg){std::wstring out=L"\"";size_t slashes=0;for(wchar_t c:arg){if(c==L'\\'){slashes++;continue;}if(c==L'\"'){out.append(slashes*2+1,L'\\');out+=c;}else{out.append(slashes,L'\\');out+=c;}slashes=0;}out.append(slashes*2,L'\\');return out+L"\"";}
inline std::wstring exactNumber(double value){std::wostringstream out;out<<std::setprecision(17)<<value;return out.str();}
inline bool launch(const std::wstring&path,double scale,unsigned expected,unsigned expectedDimensions=0,HWND observer=nullptr,bool normalize=true){wchar_t exe[32768]={};if(!GetModuleFileNameW(nullptr,exe,32768))return false;auto command=quote(exe)+L" --cad-postprocess "+quote(path)+L" "+exactNumber(scale)+L" "+std::to_wstring(expected)+L" "+std::to_wstring(expectedDimensions)+L" "+(normalize?L"1":L"0");STARTUPINFOW startup={sizeof(startup)};PROCESS_INFORMATION process={};if(!CreateProcessW(exe,command.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&startup,&process))return false;CloseHandle(process.hThread);if(observer){try{std::thread([handle=process.hProcess,observer]{WaitForSingleObject(handle,INFINITE);DWORD result=4;GetExitCodeProcess(handle,&result);CloseHandle(handle);PostMessageW(observer,WM_APP+19,result,0);}).detach();}catch(...){CloseHandle(process.hProcess);}}else CloseHandle(process.hProcess);return true;}
}
