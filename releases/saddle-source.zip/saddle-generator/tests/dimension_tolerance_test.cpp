// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>
#include <functional>
#include <stdexcept>
#include <cassert>
#include <iostream>
struct Value {double value;explicit Value(double v=0):value(v){}double number()const{return value;}};
std::string utf8(const std::wstring&s){return std::string(s.begin(),s.end());}
struct Object {std::function<Value(const wchar_t*)>read;std::function<void(const wchar_t*,Value)>write;Value get(const wchar_t*n)const{return read(n);}void put(const wchar_t*n,Value v)const{write(n,v);}};
#include "dimension_tolerance.inc"
int main(){int checks=0;
 for(int method:{0,1,2,3,4}){
  std::map<std::wstring,Value> props={{L"ToleranceDisplay",Value(method)},{L"TolerancePrecision",Value(1)},{L"ToleranceHeightScale",Value(.75)},{L"ToleranceJustification",Value(1)},{L"ToleranceSuppressLeadingZeros",Value(0)},{L"ToleranceSuppressTrailingZeros",Value(0)},{L"ToleranceUpperLimit",Value(method==1?1.:.3)},{L"ToleranceLowerLimit",Value(method==1?1.:-.2)}};
  int writes=0;Object obj{[&](const wchar_t*n){std::wstring name=n;if(name!=L"ToleranceDisplay"&&props.at(L"ToleranceDisplay").number()==0)throw std::runtime_error("conditional property unavailable");if((name==L"ToleranceUpperLimit"||name==L"ToleranceLowerLimit")&&props.at(L"ToleranceDisplay").number()==4)throw std::runtime_error("basic limits unavailable");return props.at(name);},[&](const wchar_t*n,Value v){std::wstring name=n;if(name!=L"ToleranceDisplay")assert(props.at(L"ToleranceDisplay").number()!=0);props[name]=v;writes++;}};
  auto saved=captureDimensionTolerance(obj);assert(writes==0);for(auto&entry:props)entry.second=Value(0); // StyleName/CopyFrom resets the values.
  restoreDimensionTolerance(obj,saved);verifyDimensionTolerance(obj,saved);assert(props.at(L"ToleranceDisplay").number()==method);if(method!=0)assert(props.at(L"TolerancePrecision").number()==1&&props.at(L"ToleranceSuppressTrailingZeros").number()==0);if(method==1)assert(props.at(L"ToleranceUpperLimit").number()==1&&props.at(L"ToleranceLowerLimit").number()==1);checks++;
  if(method!=0){props[L"TolerancePrecision"]=Value(0);bool failed=false;try{verifyDimensionTolerance(obj,saved);}catch(...){failed=true;}assert(failed);checks++;}
 }
 {Object obj{[](const wchar_t*)->Value{throw std::runtime_error("read failed");},[](const wchar_t*,Value){assert(false);}};bool failed=false;try{captureDimensionTolerance(obj);}catch(...){failed=true;}assert(failed);checks++;}
 {Object obj{[](const wchar_t*){return Value(9);},[](const wchar_t*,Value){assert(false);}};bool failed=false;try{captureDimensionTolerance(obj);}catch(...){failed=true;}assert(failed);checks++;}
 std::cout<<checks<<" tolerance snapshot/restore checks passed; no real AutoCAD\n";
}
