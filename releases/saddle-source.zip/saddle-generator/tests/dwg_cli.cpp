#include "dwg_export.hpp"
#include <iostream>
int main(int argc,char**argv){try{saddle::Params p;if(argc>2)p.type=std::stoi(argv[2]);if(argc>3)p.holes=std::stoi(argv[3]);if(argc>4)p.ribs=std::stoi(argv[4]);if(argc>5)p.sliding=std::stoi(argv[5]);auto d=saddle::generate(p);saddle::writeDWG(d,argv[1]);std::cout<<d.e.size()<<" entities\n";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
