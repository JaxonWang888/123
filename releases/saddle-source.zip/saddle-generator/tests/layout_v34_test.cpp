// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "model.hpp"
#include "cad_compat.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int checks=0;
 for(int type:{0,1})for(int ribs:{4,6})for(double scale:{15.,25.,40.})for(double distance:{500.,800.}){
  Params p;p.type=type;p.ribs=ribs;p.ribSpacings.assign(spacingCount(ribs),300);p.scale=scale;p.holeDistances={distance};auto d=generate(p);auto rs=ribShapes(p);double py=d.sheetH*scale*.245-8*scale;
  int ts=0,right=0,tol=0;
  for(auto&q:d.dimensions){
   if(q.key=="ts"){ts++;assert(q.textPositionExplicit);double bottom=1e100,top=-1e100;for(auto&e:q.graphics)if(e.kind==3){bottom=e.y;top=e.y+e.a;}
    for(auto&r:rs){double low=py+r.station-r.footThickness/2,high=py+r.station+r.footThickness/2;assert(q.at.y<low-1e-7||q.at.y>high+1e-7);assert(top<low-1e-7||bottom>high+1e-7);}for(double station:anchorStations(p)){double y=py+station;assert(top<y-p.hole/2||bottom>y+p.hole/2);}assert(std::abs(q.measurement-p.web)<1e-7);}
   if(q.key=="earth-edge-gap"&&q.textToRight){right++;assert(q.textPositionExplicit);for(auto&e:q.graphics)if(e.kind==3){assert(e.rotation==0&&e.x>q.at.x+scale);for(auto&note:d.e)if(note.kind==3&&(note.text=="Earth Lug"||note.text=="接地板")&&std::abs(note.x-q.at.x)<30*scale&&std::abs(note.y-q.at.y)<20*scale){double nw=note.text=="接地板"?3*note.a*1.45:cadDimensionTextWidth(note);double tw=cadDimensionTextWidth(e);assert(e.x+tw<note.x||e.x>note.x+nw||e.y+e.a<note.y||e.y>note.y+note.a);}}}
   if(q.tolerance>0){tol++;assert(q.key=="bolt-pair"&&q.tolerance==1);}
  }
  assert(ts==2&&right==1&&tol==2);auto job=nativeDimensionJob(d);auto parsed=saddlecad::readDimensionJob(saddlecad::writeDimensionJob(job));assert(parsed.dimensions==d.dimensions.size()&&parsed.tasks.size()==5);
  for(auto&t:parsed.tasks){assert(t.position||t.tolerance==1);assert(saddlecad::matchesDimensionTask(t,t.first,t.second));assert(saddlecad::matchesDimensionTask(t,t.second,t.first));auto wrong=t.first;wrong[0]+=1;assert(!saddlecad::matchesDimensionTask(t,wrong,t.second));}checks++;
 }
 bool bad=false;try{saddlecad::readDimensionJob("SADDLE_DIMENSIONS_V34\n1 2\n");}catch(...){bad=true;}assert(bad);checks++;
 std::cout<<checks<<" V34 layout/annotation job cases passed\n";
}
