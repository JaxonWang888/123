#include "model.hpp"
#include <cassert>
#include <iostream>
#include <limits>
using namespace saddle;
int main(){Params p;assert(validate(p).empty());auto a=generate(p);assert(a.ratio>=1);int round=0;for(auto&e:a.e)if(e.kind==1&&e.a==p.hole/2)round++;assert(round==p.holes);
 for(int t=0;t<2;t++)for(int n:{4,6,8,12,20,40})for(int ribs:{2,3,4,8,20})for(int sliding=0;sliding<2;sliding++){p=Params();p.type=t;p.holes=n;p.ribs=ribs;p.sliding=sliding;if(!validate(p).empty())continue;auto d=generate(p);int count=0;for(auto&e:d.e)if((!sliding&&e.kind==1&&e.a==p.hole/2)||(sliding&&e.kind==2&&e.a==p.hole/2))count++;assert(count==n*(sliding?2:1));}
 p=Params();auto d=generate(p);p.scale=25;auto s=generate(p);for(size_t i=0;i<d.modelCount;i++){assert(d.e[i].x==s.e[i].x);assert(d.e[i].y==s.e[i].y);assert(d.e[i].a==s.e[i].a);}
 p=Params();p.holes=5;assert(!validate(p).empty());p=Params();p.height=100;assert(!validate(p).empty());p=Params();p.diameter=std::numeric_limits<double>::quiet_NaN();assert(!validate(p).empty());
 p=Params();p.paper=4;auto small=generate(p);p.paper=0;auto large=generate(p);assert(small.recommended>=large.recommended);
 Drawing bounds;bounds.arc(0,1000,1000,210,330);bounds.bounds();assert(bounds.maxY<501&&bounds.minY<1e-8);std::cout<<"model tests passed\n";}
