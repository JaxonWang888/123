// SPDX-License-Identifier: GPL-3.0-or-later
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){
 int cases=0;
 for(int type:{0,1})for(int holes:{2,3,5})for(int ribs:{2,3,6,7}){
  Params p;p.type=type;p.holes=holes;p.ribs=ribs;p.ribSpacings.assign(spacingCount(ribs),240);
  assert(validateV3(p).empty());auto d=generate(p);auto inner=innerRibPositions(p);
  assert(inner.size()==(unsigned)ribs-2);for(size_t i=0;i<inner.size();i++)assert(std::abs(inner[i]+inner[inner.size()-1-i])<1e-8);
  if(ribs%2)assert(inner[inner.size()/2]==0);else if(ribs>2)assert(std::abs(inner[inner.size()/2]-120)<1e-8);
  int fixed=0,slots=0;std::vector<const Entity*> outlines;
  for(auto&e:d.e){if(e.role==5&&e.kind==1)fixed++;if(e.role==6&&e.kind==2)slots++;if(e.role==3)outlines.push_back(&e);assert(e.kind!=5);assert(e.text.find("Note")==std::string::npos);}
  assert(fixed==holes*(type?1:2));assert(slots==2*fixed);assert(outlines.size()==8);
  int a2=0,di=0;for(auto&q:d.dimensions){assert(q.measurement>0);assert(!q.graphics.empty());if(q.key=="a2"){a2++;assert(std::abs(q.second.y-q.first.y)>1e-7);}if(q.key=="di"){di++;assert(std::abs(q.measurement-240)<1e-8);}if(q.key=="a4")assert(std::abs(q.measurement-(p.slot-p.hole))<1e-8);if(q.key=="a3")assert(std::abs(q.measurement-(p.depth-2*p.edgeY))<1e-8);if(q.key=="a1")assert(std::abs(q.measurement-p.ventOffset)<1e-8);assert(q.key!="Ls"&&q.key!="Deg-3");}
  assert(a2==2*(type?1:2)*(holes-(holes%2)));assert(di==std::max(0,ribs-3));
  p.scale=25;auto scaled=generate(p);assert(scaled.dimensions.size()==d.dimensions.size());for(size_t i=0;i<d.dimensions.size();i++)assert(std::abs(d.dimensions[i].measurement-scaled.dimensions[i].measurement)<1e-7);
  if(type){std::vector<const Entity*> web;for(auto&e:d.e)if(e.role==8)web.push_back(&e);assert(web.size()==8);for(int view=0;view<2;view++){double bcentre=(outlines[view*4]->x+outlines[view*4]->a)/2,wcentre=(web[view*4]->x+web[view*4]->a)/2;assert(std::abs(wcentre-bcentre-(view?1:-1)*(p.supportWidth-p.web)/2)<1e-7);}}
  cases++;
 }
 Params p;p.ribs=7;p.ribSpacings={200,350};auto v=innerRibPositions(p);assert((v==std::vector<double>{-550,-200,0,200,550}));p.ribs=6;p.ribSpacings={200,350};v=innerRibPositions(p);assert((v==std::vector<double>{-450,-100,100,450}));p.ribSpacings.clear();assert(!validateV3(p).empty());
 p=Params();auto d=generate(p);assert(!d.webNotched);p.outerSetback=300;d=generate(p);assert(d.webNotched&&d.deg3<20);int radialEdges=0;Point c={d.maxX*.72,d.maxY*.52+p.height};for(auto&e:d.e)if(e.role==7&&e.kind==0&&std::abs(hypot(e.a-e.x,e.b-e.y)-50)<1e-7){Point x={e.x-c.x,e.y-c.y},y={e.a-c.x,e.b-c.y};assert(std::abs(x.x*y.y-x.y*y.x)<1e-6);radialEdges++;}assert(radialEdges==2);
 std::cout<<cases<<" parameter cases plus independent spacing, native measurement, symmetry, outward web and Note8 checks passed\n";
}
