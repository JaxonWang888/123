// SPDX-License-Identifier: GPL-3.0-or-later
#include "model.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int cases=0;
 for(int type:{0,1})for(int holes:{1,2,3,4,5})for(int count:{4,6}){
  Params p;p.type=type;p.holes=holes;p.ribs=count;p.ribSpacings.assign(spacingCount(count),300);p.holeDistances.clear();if(holes/2==1)p.holeDistances={800};if(holes/2==2)p.holeDistances={300,800};assert(validateV3(p).empty());auto d=generate(p);auto r=ribShapes(p);Point centre={0,p.height};
  for(size_t i=0;i<r.size();i++){auto&q=r[i];assert(std::abs(dot(q.top[1]-q.top[0],q.direction))<1e-7);assert(std::abs(magnitude(q.contact-centre)-(p.diameter/2+p.pad))<1e-7);if(i>0&&i+1<r.size())assert(q.top[0].y==q.top[1].y);}
  double angle=atan2(r.back().contact.x,p.height-r.back().contact.y)*360/PI;assert(std::abs(angle-p.angle)<1e-8);
  auto ys=anchorStations(p);assert(ys.size()==(unsigned)holes);for(int i=0;i<holes;i++)assert(std::abs(ys[i]+ys[holes-1-i])<1e-8);if(holes%2)assert(ys[holes/2]==0);
  int welds=0,jogged=0;
  int fixed=0,slots=0,baseHidden=0,vents=0,webHidden=0,a2=0;std::vector<const Entity*> sections;
  for(auto&e:d.e){assert(e.kind!=9);if(e.role==51&&e.kind==1){welds++;assert(e.x<d.maxX*.3);}if(e.role==5&&e.kind==1)fixed++;if(e.role==6&&e.kind==2)slots++;if(e.role==17){assert(e.layer==6);baseHidden++;}if(e.role==14&&e.layer==6){assert(e.kind==0);vents++;double mid=(e.x+e.a)/2;assert(mid<d.maxX*.405&&mid>d.maxX*.19);}if(e.role==13&&e.layer==6)webHidden++;if(e.kind==8){sections.push_back(&e);if(e.role==21){assert(std::abs(e.y-((d.maxY*.245-8*d.ratio)-r.back().base[0].x))<1e-7);assert(std::abs(e.y+e.b-((d.maxY*.245-8*d.ratio)+r.back().base[0].x))<1e-7);assert(e.y>(d.maxY*.245-8*d.ratio)-p.length/2&&e.y+e.b<(d.maxY*.245-8*d.ratio)+p.length/2);}}assert(e.text!="VIEW A");}
  assert(welds==1);
  for(const char* caption:{"A-A","B-B","270°","90°","180°"})assert(std::count_if(d.e.begin(),d.e.end(),[&](const Entity&e){return e.text==caption;})==1);
  assert(std::count_if(d.e.begin(),d.e.end(),[](const Entity&e){return e.role==71&&e.kind==5;})==4);
  int ticks=0;for(auto&e:d.e)if(e.role==71&&e.kind==0&&std::abs(hypot(e.a-e.x,e.b-e.y)-2*d.ratio)<1e-7){ticks++;if(std::abs(e.a-e.x)<1e-7)assert((e.b-e.y)*(e.y-(d.maxY*.52))<0);else assert((e.a-e.x)*(e.x-(d.maxX*(.19+.405)/2))<0);}assert(ticks==4);
  auto captionY=[&](const std::string&name){for(auto&e:d.e)if(e.text==name)return e.y;return -1e30;};
  assert(captionY("A-A")>d.maxY*.52+p.height+8*d.ratio);
  assert(captionY("B-B")<std::min(captionY("Fixed Saddle"),captionY("Sliding Saddle"))-3*d.ratio);
  assert((d.maxY*.245-8*d.ratio)+p.length/2+20*d.ratio<captionY("B-B")-5*d.ratio);
  Point contact=r.back().contact+Point{d.maxX*.72,d.maxY*.52};int contactArrows=0,contours=0;
  for(auto&e:d.e)if(e.role==75){if(e.kind==5){assert(magnitude(Point{e.x,e.y}-contact)<1e-7);assert(std::abs(magnitude(Point{e.x,e.y}-Point{d.maxX*.72,d.maxY*.52+p.height})-(p.diameter/2+p.pad))<1e-7);contactArrows++;}if(e.kind==2){assert(e.b==180&&e.c==360);contours++;bool touches=false;for(auto&l:d.e)if(l.role==75&&l.kind==0&&std::abs(l.y-l.b)<1e-7&&std::abs(l.y-e.y)<1e-7)touches=true;assert(touches);}}
  assert(contactArrows==1&&contours==1);

  int lowerBreak=0,upperContour=0;double padContact=d.maxY*.52+p.height-p.diameter/2;
  for(auto&e:d.e){if(e.role==70){assert(e.kind==0&&refLayers(p.type).at(e.layer).name=="5 断开线（双点划线）");lowerBreak++;}if(e.role==50&&e.kind==0&&std::abs(e.y-e.b)<1e-7){assert(e.y>=padContact-1e-7);if(std::abs(e.y-padContact-p.pad)<1e-7)upperContour++;}}
  assert(lowerBreak==10&&upperContour==3);
  double lowerMin=1e30,lowerMax=-1e30;for(auto&e:d.e)if(e.role==70){lowerMin=std::min({lowerMin,e.y,e.b});lowerMax=std::max({lowerMax,e.y,e.b});}assert(std::abs(lowerMax-lowerMin-p.length*.2)<1e-7);


  assert(fixed==holes*(type?1:2));assert(slots==fixed*2);assert(baseHidden==(type?4:8));assert(vents==4);assert(webHidden==(type?0:6));
  for(size_t i=0;i<sections.size();i++)for(size_t j=i+1;j<sections.size();j++){auto&a=*sections[i],&b=*sections[j];double dx=std::min(a.x+a.a,b.x+b.a)-std::max(a.x,b.x),dy=std::min(a.y+a.b,b.y+b.b)-std::max(a.y,b.y);assert(dx<1e-7||dy<1e-7);}
  for(auto&q:d.dimensions){if(q.jogged){jogged++;assert(q.key=="wear-inner-radius"&&q.type==2&&std::abs(q.measurement-p.diameter/2)<1e-7);assert(q.graphics.size()>=7);}if(q.key=="bolt-pair"){a2++;assert(q.tolerance==1);assert(std::find(p.holeDistances.begin(),p.holeDistances.end(),q.measurement/2)!=p.holeDistances.end());}if(q.key=="a3")assert(std::abs(q.measurement-p.holeRowSpacing)<1e-7);for(auto&e:q.graphics)assert(e.layer==(e.kind==3?2:4));}
  assert(a2==2*(holes/2)&&jogged==1);
  int padEdge=0,baseEdge=0,bDims=0;
  for(auto&q:d.dimensions){if(q.key=="b"){assert(std::abs(q.measurement-p.supportWidth)<1e-7);bDims++;}if(q.key=="pad-to-web-outer"){padEdge++;assert(std::abs(q.measurement-(p.padWidth-p.supportWidth)/2)<1e-7);}if(q.key=="base-to-web-outer"){baseEdge++;assert(std::abs(q.measurement-(p.depth-p.supportWidth)/2)<1e-7);}}
  assert(bDims==2&&padEdge==1&&baseEdge==(type?2:0));
  double widthY=0,gapY=0,xY=0,diY=0;int fillets=0;
  for(auto&q:d.dimensions){if(q.key=="b"&&!widthY)widthY=q.at.y;if(q.key=="pad-to-web-outer")gapY=q.at.y;if(q.key=="X")xY=q.at.y;if(q.key=="di")diY=q.at.y;if(q.key=="R1"){assert(q.second.x>q.first.x);assert(q.first.x>d.maxX*(fillets?.405:.19));fillets++;}}
  assert(fillets==2);assert(std::abs(widthY-gapY)<1e-7);if(diY)assert(std::abs(xY-diY)<1e-7);

  for(double px:{d.maxX*.19,d.maxX*.405}){double lo=1e30,hi=-1e30;for(auto*e:sections)if(std::abs(e->x-px)<p.depth){lo=std::min(lo,e->x);hi=std::max(hi,e->x+e->a);}assert(std::abs(hi-lo-p.supportWidth)<1e-7);assert(std::abs((hi+lo)/2-px)<1e-7);}

  p.scale=25;auto scaled=generate(p);assert(scaled.dimensions.size()==d.dimensions.size());for(size_t i=0;i<d.dimensions.size();i++)if(!d.dimensions[i].textOverride.empty())assert(scaled.dimensions[i].textOverride==d.dimensions[i].textOverride);else assert(std::abs(scaled.dimensions[i].measurement*scaled.dimensions[i].measurementScale-d.dimensions[i].measurement*d.dimensions[i].measurementScale)<1e-7);cases++;
 }
 Params p;p.type=1;p.holes=2;p.holeDistances={150};assert(!validateV3(p).empty());p.holeDistances={300};assert(validateV3(p).empty());p.holes=1;p.holeDistances.clear();assert(validateV3(p).empty());p.ribs=3;p.ribSpacings.clear();assert(!validateV3(p).empty());
 p=Params();p.holeRowSpacing=120;p.holeDistances={300};assert(validateV3(p).empty());p.holeRowSpacing=70;assert(!validateV3(p).empty());
 p=Params();p.holeDistances={890};assert(!validateV3(p).empty());p.holes=4;p.holeDistances={300,290};assert(!validateV3(p).empty());
 p=Params();p.ribs=7;p.ribSpacings={200,350};auto positions=innerRibPositions(p);assert((positions==std::vector<double>{-550,-200,0,200,550}));
 p=Params();auto d=generate(p);assert(!d.webNotched);p.outerSetback=300;d=generate(p);assert(d.webNotched);int radialEdges=0;Point c={d.maxX*.72,d.maxY*.52+p.height};for(auto&e:d.e)if(e.role==7&&e.kind==0&&std::abs(hypot(e.a-e.x,e.b-e.y)-50)<1e-7){Point a={e.x-c.x,e.y-c.y},b={e.a-c.x,e.b-c.y};assert(std::abs(a.x*b.y-a.y*b.x)<1e-6);radialEdges++;}assert(radialEdges==2);
 for(auto&q:d.dimensions)if(q.key=="web-gap-50"){assert(std::abs(q.measurement-50)<1e-7);const auto&text=q.graphics.back();Point above={-sin(text.rotation*PI/180),cos(text.rotation*PI/180)};assert(dot(q.textAt-q.at,above)>0);assert(magnitude(q.at-c)>p.diameter/2+p.pad+50);}

 Params old;old.type=1;upgradeLegacySaddleWidth(old);assert(old.supportWidth==292&&ribAxialWidth(old)==280);
 auto noteSpan=[](const Drawing&drawing){double span=0;for(auto&e:drawing.e)if(e.role==52&&e.kind==0&&std::abs(e.y-e.b)<1e-7)span=std::max(span,std::abs(e.a-e.x));return span;};
 Params shortNote;auto shortDrawing=generate(shortNote);double shortSpan=noteSpan(shortDrawing);assert(shortSpan<65*shortDrawing.ratio);
 shortNote.boltSpecIndex=14;shortNote.boltMaterialIndex=8;shortNote.boltCoatingIndex=3;assert(noteSpan(generate(shortNote))>shortSpan);
 // Equipment distances change labels, never the broken schematic geometry.
 Params equipment;auto firstDrawing=generate(equipment);equipment.datumDistance=1234;equipment.saddleDistance=5678;equipment.ribPadWeld=9;auto changedDrawing=generate(equipment);
 auto geometry=[](const Drawing&g){std::vector<double> values;for(auto&e:g.e)if(e.role==10||e.role==11||e.role==12||e.role==13)values.insert(values.end(),{double(e.kind),e.x,e.y,e.a,e.b});return values;};assert(geometry(firstDrawing)==geometry(changedDrawing));
 for(auto&q:changedDrawing.dimensions)if(q.key=="saddle-centre-distance"||q.key=="saddle-edge-reference"){
  assert(q.textOverride==(q.key=="saddle-centre-distance"?"5678":"(5678)"));assert(std::abs(q.measurement-594*changedDrawing.ratio*.215)<1e-7);
  assert(q.graphics.back().text==q.textOverride);
 }
 assert(std::any_of(changedDrawing.e.begin(),changedDrawing.e.end(),[](const Entity&e){return e.text=="到基准线(1034)";}));
 assert(std::count_if(changedDrawing.e.begin(),changedDrawing.e.end(),[](const Entity&e){return e.text=="9";})==1);
 assert(std::count_if(changedDrawing.e.begin(),changedDrawing.e.end(),[](const Entity&e){return e.role==75&&e.kind==5;})==1);
 for(auto&e:changedDrawing.e)if(e.role==74||e.role==75)assert(refLayers(equipment.type).at(e.layer).name=="2 明细栏-技术特性表-剖面线-管口表-管口载荷表（细实线）");
 equipment.saddleDistance=0;assert(!validateV3(equipment).empty());equipment.saddleDistance=3000;equipment.datumDistance=NAN;assert(!validateV3(equipment).empty());
 std::cout<<cases<<" V7 parameter cases plus flat ends, contact angle, projections, symmetric holes, nonintersecting sections, interference and Note8 checks passed\n";
}
