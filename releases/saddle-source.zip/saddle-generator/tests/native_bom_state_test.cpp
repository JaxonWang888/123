// SPDX-License-Identifier: GPL-3.0-or-later
// Run the production TABLE edit-state helpers on Linux with a deterministic
// COM adapter. This is not an AutoCAD or Win32 window integration test.
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <stdexcept>
#include <algorithm>
#include <cwctype>
#include <iostream>
using ULONGLONG=unsigned long long;
static ULONGLONG clockMs=0;
ULONGLONG GetTickCount64(){return clockMs;}
void pump(unsigned ms){clockMs+=ms;}
std::string utf8(const std::wstring&s){std::string out;for(auto c:s)out+=c<128?char(c):'?';return out;}
std::wstring compact(const std::wstring&s){std::wstring out;for(auto c:s)if(!iswspace(c)&&c!=L'&')out+=towlower(c);return out;}
struct Value {
 double n=0;std::wstring s;long*ref=nullptr;
 Value()=default;explicit Value(double v):n(v){}explicit Value(long v):n(v){}explicit Value(bool v):n(v){}explicit Value(const wchar_t*v):s(v){}explicit Value(std::wstring v):s(std::move(v)){}
 double number()const{return n;}bool boolean()const{return n!=0;}std::wstring str()const{return s;}
};
Value bomLongRef(long&n){Value v;v.ref=&n;return v;}
std::wstring bomCellText(const std::string&){return L"鞍座明细表";}
struct Object {
 std::function<Value(const std::wstring&,const std::vector<Value>&)>fn;
 Value call(const wchar_t*name,std::vector<Value>args={})const{return fn(name,args);}
};
#include "native_bom_table_ops.inc"
int main(){int checks=0;
 long state=5;bool changed=false;
 Object cell{[&](auto&name,auto&a)->Value{if(name==L"GetCellState")return Value(state);if(name==L"SetCellState"){state=(long)a[2].number();return Value();}throw std::runtime_error("unexpected cell operation");}};
 editBomCell(cell,3,2,4,"SetMargin",[&]{assert(state==1);changed=true;state|=64;});
 assert(changed&&state==69);checks++;
 state=5;bool failed=false;
 try{editBomCell(cell,3,2,5,"SetMargin",[&]{assert(state==0);throw std::runtime_error("injected write failure");});}catch(const std::exception&e){auto msg=std::string(e.what());failed=msg.find("row=3, col=2, CellState=5")!=std::string::npos;}
 assert(failed&&state==5);checks++;
 for(long flags:{2L,8L,16L}){state=flags;changed=false;failed=false;try{editBomCell(cell,0,0,5,"write",[&]{changed=true;});}catch(...){failed=true;}assert(failed&&!changed&&state==flags);checks++;}
 long active=1;std::wstring names=L"TABLEDIT";int cancelled=0,cleared=0;bool stuck=false;
 Object doc{[&](auto&name,auto&a)->Value{if(name==L"GetVariable")return a[0].str()==L"CMDACTIVE"?Value(active):Value(names);if(name==L"SendCommand"){assert(a[0].str()==L"\x1b\x1b");cancelled++;if(!stuck){active=0;names.clear();}return Value();}throw std::runtime_error("unexpected document operation");}};
 Object table{[&](auto&name,auto&)->Value{if(name==L"ClearSubSelection"){assert(active==0&&names.empty());cleared++;return Value();}throw std::runtime_error("unexpected table operation");}};
 finishBomTableEditing(doc,table);assert(cancelled==1&&cleared==1);checks++;
 active=1;names=L"LINE";cancelled=cleared=0;failed=false;
 try{finishBomTableEditing(doc,table);}catch(...){failed=true;}assert(failed&&!cancelled&&!cleared);checks++;
 active=1;names=L"TABLEDIT";stuck=true;failed=false;
 try{finishBomTableEditing(doc,table,150);}catch(...){failed=true;}assert(failed&&cancelled==1&&!cleared);checks++;
 active=0;names.clear();stuck=false;cancelled=cleared=0;
 finishBomTableEditing(doc,table);assert(!cancelled&&cleared==1);checks++;
 std::wstring title;state=1;bool merged=true;int updates=0;
 Object titleTable{[&](auto&name,auto&a)->Value{
  if(name==L"IsMergedCell"){long r=(long)a[0].number();if(r==0&&merged){*a[2].ref=0;*a[3].ref=0;*a[4].ref=0;*a[5].ref=11;return Value(true);}return Value(false);}
  if(name==L"GetCellState")return Value(state);
  if(name==L"SetCellState"){state=(long)a[2].number();return Value();}
  if(name==L"SetText"){assert(state==0&&a[0].number()==0&&a[1].number()==0);title=a[2].str();return Value();}
  if(name==L"GetText")return Value(title);
  if(name==L"Update"){updates++;return Value();}
  throw std::runtime_error("unexpected title operation");}};
 setBomTitle(titleTable,3);assert(title==L"鞍座明细表"&&state==1&&updates==1);checks++;
 merged=false;failed=false;try{setBomTitle(titleTable,3);}catch(...){failed=true;}assert(failed&&updates==1);checks++;
 std::map<long,long> rowStates={{0,5},{1,4}};bool rowSet=false;
 Object rowTable{[&](auto&name,auto&a)->Value{long col=(long)a[1].number();if(name==L"GetCellState")return Value(rowStates[col]);if(name==L"SetCellState"){rowStates[col]=(long)a[2].number();return Value();}if(name==L"SetRowHeight"){assert(rowStates[0]==1&&rowStates[1]==0&&a[1].number()==8);rowSet=true;return Value();}throw std::runtime_error("unexpected row operation");}};
 setBomRowHeight(rowTable,3,0,2,8);assert(rowSet&&rowStates[0]==5&&rowStates[1]==4);checks++;
 // Exercise actual COM writes across name data, header and other columns.
 for(double scale:{1.,15.,25.})for(auto rc:std::vector<std::pair<long,long>>{{3,3},{1,3},{3,0},{0,0}}){
  long flags=4,alignment=0;std::map<long,double> margins={{2,.6},{8,.8},{1,.3},{4,.4}};auto originalMargins=margins;int marginWrites=0;
  Object formatted{[&](auto&name,auto&a)->Value{if(name==L"GetCellState")return Value(flags);if(name==L"SetCellState"){flags=(long)a[2].number();return Value();}assert(flags==0);if(name==L"SetMargin"){marginWrites++;margins[(long)a[2].number()]=a[3].number();return Value();}if(name==L"SetCellAlignment"){alignment=(long)a[2].number();return Value();}throw std::runtime_error("unexpected formatting operation");}};
  formatBomCell(formatted,rc.first,rc.second,3,scale,2,8,1,4);
  bool nameData=rc.first==3&&rc.second==3;
  if(rc.first<3){assert(margins==originalMargins&&marginWrites==0);}else if(nameData){assert(margins.at(2)==2*scale&&margins.at(8)==2*scale&&margins.at(1)==.3&&margins.at(4)==.4&&marginWrites==2);}else{for(long side:{1L,2L,4L,8L})assert(margins.at(side)==scale);assert(marginWrites==4);}
  assert(alignment==(nameData?4:5)&&flags==4);checks++;
 }
 std::cout<<checks<<" production TABLE edit-state checks passed (host COM adapter, no real AutoCAD)\n";
}
