#include <cstdio>
#include <cstring>
#include <string>
extern "C" {
#include "dwg.h"
#include "bits.h"
#include "out_dxf.h"
}
int main(int argc,char**argv){Dwg_Data d={};int r=dwg_read_file(argv[1],&d);if(r>=DWG_ERR_CRITICAL)return 1;FILE*text=fopen((std::string(argv[2])+".texts").c_str(),"wb");auto*block=dwg_model_space_object(&d);unsigned idx=0;for(auto*o=get_first_owned_entity(block);o;o=get_next_owned_entity(block,o)){if(o->fixedtype==DWG_TYPE_BLOCK||o->fixedtype==DWG_TYPE_ENDBLK)continue;const char*value=nullptr;if(o->fixedtype==DWG_TYPE_MTEXT)value=o->tio.entity->tio.MTEXT->text;if(o->fixedtype==DWG_TYPE_TEXT)value=o->tio.entity->tio.TEXT->text_value;if(value){fprintf(text,"%u ",idx);for(size_t i=0;i<strlen(value);i++)fprintf(text,"%02x",(unsigned char)value[i]);fputc('\n',text);}idx++;}fclose(text);Bit_Chain b={};b.version=R_2018;b.from_version=d.header.version;b.codepage=d.header.codepage;b.fh=fopen(argv[2],"wb");if(!b.fh)return 2;r=dwg_write_dxf(&b,&d);fclose(b.fh);dwg_free(&d);return r>=DWG_ERR_CRITICAL?3:0;}
