// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "model.hpp"
#include "cad_compat.hpp"
#include <cassert>
#include <iostream>
using namespace saddle;
int main(){int checks=0;for(int type:{0,1})for(int count:{2,3,4,5,6,8,10})for(double scale:{15.,25.}){
 Params p;p.type=type;p.ribs=count;p.ribSpacings.assign(spacingCount(count),180);p.scale=scale;p.holes=2;p.holeDistances={45};auto d=generate(p);auto ribs=ribShapes(p);std::vector<double> expected;
 for(size_t i=1;i+1<ribs.size();i++){double h=ribs[i].top[0].y;bool seen=false;for(double v:expected)if(fabs(h-v)<1e-7)seen=true;if(!seen)expected.push_back(h);}
 std::vector<const Dimension*> labels;for(auto&q:d.dimensions)if(q.key=="tw"){labels.push_back(&q);assert(fabs(q.measurement-p.rib)<1e-7);assert(fabs(magnitude(q.second-q.first)-p.rib)<1e-7);}
 assert(labels.size()==expected.size()+1); // all BOM inner length groups plus inclined outer rib
 for(double h:expected){int found=0;for(auto*q:labels){Point mid=(q->first+q->second)*.5;for(size_t i=ribs.size()/2;i+1<ribs.size();i++)if(fabs(ribs[i].top[0].y-h)<1e-7){Point local=(ribs[i].base[0]+ribs[i].base[1])*.5+ribs[i].direction*((h-p.base)*.3/ribs[i].direction.y);
 // Check that each length group has an actual thickness dimension at its height.
 if(fabs(q->first.y-q->second.y)<1e-7 && fabs(mid.y-(d.sheetH*d.ratio*.52+local.y))<1e-7)found++;
 break;}}
 assert(found==1);}
 checks++;}
 std::cout<<checks<<" rib thickness group coverage cases passed\n";
}
