# SPDX-License-Identifier: GPL-3.0-or-later
"""Compile actual normalization functions from win_cad.hpp with a host adapter."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
code=(root/'src/win_cad.hpp').read_text()
section=code[code.index('inline bool dimensionName('):code.index('inline unsigned repairDeletedObjects(')]
fixture=(root/'tests/dimension_normalization_host.cpp.in').read_text()
with tempfile.TemporaryDirectory() as tmp:
 src=Path(tmp)/'host.cpp';exe=Path(tmp)/'host-test';src.write_text(fixture.replace('// PRODUCTION_NORMALIZATION',section))
 subprocess.run(['g++','-std=c++17','-O2','-UNDEBUG','-I'+str(root/'src'),str(src),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
