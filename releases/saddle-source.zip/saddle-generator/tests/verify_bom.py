# Independent checks of native balloon alignment and BOM values in exported DXF.
import pathlib,sys,math,json
import ezdxf
from ezdxf.lldxf.encoding import decode_dxf_unicode
root=pathlib.Path(sys.argv[1]);results=[]
for path in sorted(root.glob('case_*.dxf'))+[root/'notch-sample.dxf',root/'notch-sample.readback.dxf']:
 if not path.exists():continue
 doc=ezdxf.readfile(path);ms=doc.modelspace();S=doc.header['$DIMSCALE'];texts=list(ms.query('TEXT MTEXT'))
 plain=lambda e:decode_dxf_unicode(e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text)
 circles=[c for c in ms.query('CIRCLE') if math.isclose(c.dxf.radius,5*S,abs_tol=1e-6)]
 count=8 if path.stem.split('_')[-1].split('.')[0]=='6' or path.stem.startswith('notch') else 7
 assert len(circles)==count,(path,len(circles),count)
 nums=[]
 for c in circles:
  matches=[t for t in ms.query('TEXT') if t.dxf.get('halign',0)==1 and t.dxf.get('valign',0)==2 and math.isclose(t.dxf.height,5*S,abs_tol=1e-6) and (t.dxf.align_point-c.dxf.center).magnitude<1e-6]
  assert len(matches)==1,(path,c.dxf.center,matches)
  t=matches[0];assert t.dxf.style=='HM-ASME';nums.append(int(t.dxf.text))
 assert sorted(nums)==list(range(1,count+1))
 values=[plain(e) for e in texts]
 for value in ('93201-2406362','ASME-EB-04','SA-240 316/316L','0.16','0.32','General','See This DWG.','***','FIXED BASE PLATE','SLIDING BASE PLATE','WEAR PLATE','WEB PLATE','OUTSIDE RIB PLATE','EARTH LUG'):
  assert value in values,(path,value)
 assert values.count('***')==3*(count-1)
 assert values.count('0.16')==values.count('0.32')==1
 results.append({'file':path.name,'items':count,'diameter_mm':10,'digit_height_mm':5,'alignment':'middle-center'})
assert len(results)==42,len(results)
(root/'verification-bom.json').write_text(json.dumps({'passed':True,'files':len(results),'checks':results},indent=2));print(len(results),'native BOM / balloon files passed')
