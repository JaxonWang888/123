# Native definition checks for the Mechanical 2018 compatibility regression.
import json,math,pathlib,subprocess,sys
import ezdxf
from ezdxf.lldxf.encoding import decode_dxf_unicode
root=pathlib.Path(sys.argv[1]);reader=sys.argv[2];records=[]
scales=sorted(root.glob('scale_*.dwg'));assert len(scales)==4
for dwg in scales:
    scale=float(dwg.stem.split('_')[1]);readback=dwg.with_suffix('.readback.dxf')
    subprocess.run([reader,str(dwg),str(readback)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for path in (dwg.with_suffix('.dxf'),readback):
        doc=ezdxf.readfile(path);audit=doc.audit();assert not audit.errors and not audit.fixes
        assert doc.header['$DIMSTYLE']=='HM 1-1' and doc.header['$DIMSCALE']==scale
        assert doc.header['$DIMTXT']==3.5 and doc.header['$DIMTMOVE']==2
        assert doc.dimstyles.get('HM 1-1').dxf.dimscale==scale
        ms=doc.modelspace();dims=list(ms.query('DIMENSION LARGE_RADIAL_DIMENSION'));assert len(dims)>25
        for dim in dims:
            assert dim.override().get('dimscale')==scale and dim.override().get('dimtmove')==2
            assert dim.dxf.dimtype&128 and doc.blocks[dim.dxf.geometry].block.dxf.flags&1
            block=doc.blocks[dim.dxf.geometry];text=list(block.query('TEXT'))[-1]
            delta=dim.dxf.text_midpoint-text.dxf.insert
            assert delta.magnitude>=text.dxf.height*.49
            assert math.isclose((dim.dxf.get('text_rotation',0)-text.dxf.rotation)%360,0,abs_tol=1e-6) or math.isclose((dim.dxf.get('text_rotation',0)-text.dxf.rotation)%360,360,abs_tol=1e-6)
        angles=[q for q in dims if q.dxftype()=='DIMENSION' and q.dimtype==5]
        assert sorted(round((q.dxf.defpoint-q.dxf.defpoint4).magnitude,6) for q in angles)==[450,650]
        assert doc.header['$TEXTSTYLE']=='HM-ASME'
        assert all(e.dxf.style=='HM-ASME' for e in doc.query('TEXT MTEXT'))
        assert doc.styles.get('HM-ASME').get_extended_font_data()==('Arial',False,False)
        assert doc.styles.get('Saddle_SimSun').get_extended_font_data()==('SimSun',False,False)
        labels=[decode_dxf_unicode(e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text) for e in ms.query('TEXT MTEXT')]
        assert all(s in labels for s in ('固定鞍座','滑动鞍座','排气孔','长圆孔'))
        records.append({'file':path.name,'global_scale':scale,'dimensions':len(dims),'audit_errors':0,'audit_fixes':0})
# Verify the actual serialized DWG strings, independent of DXF text conversion.
raw_files=list(root.glob('*.readback.dxf.texts'));assert len(raw_files)==25
for path in raw_files:
    strings=[bytes.fromhex(line.split(' ',1)[1]) for line in path.read_text().splitlines()]
    assert all(all(b<128 for b in value) and b'????' not in value for value in strings)
    assert any(b'\\U+56FA\\U+5B9A\\U+978D\\U+5EA7' in value for value in strings)
(root/'verification-compat.json').write_text(json.dumps({'passed':True,'files':len(records),'raw_dwg_files':len(raw_files),'checks':records},indent=2))
print(f'{len(records)} scale documents passed current-style/per-entity ratio, explicit text location, anonymous block and font checks; {len(raw_files)} raw DWG text streams are Unicode-safe')
