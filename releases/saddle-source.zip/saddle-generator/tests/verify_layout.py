# Independently inspect native exported dimension geometry, not just values.
import pathlib,math,json,sys
import ezdxf
root=pathlib.Path(sys.argv[1]);records=[]
for path in sorted(root.glob('*.dxf')):
 doc=ezdxf.readfile(path);count=radial=0
 for q in doc.modelspace().query('DIMENSION'):
  block=doc.blocks[q.dxf.geometry];texts=list(block.query('TEXT'));assert len(texts)==1
  t=texts[0];r=math.radians(t.dxf.rotation);reading=ezdxf.math.Vec3(math.cos(r),math.sin(r),0);above=ezdxf.math.Vec3(-math.sin(r),math.cos(r),0)
  if q.dimtype in (0,1):
   a=q.dxf.defpoint2;b=q.dxf.defpoint3;at=q.dxf.defpoint
   u=ezdxf.math.Vec3(math.cos(math.radians(q.dxf.get('angle',0))),math.sin(math.radians(q.dxf.get('angle',0))),0) if q.dimtype==0 else (b-a).normalize()
   assert abs(abs(u.dot(reading))-1)<1e-7
   assert (t.dxf.insert-at).dot(above)>0
   segments=[]
   for e in block.query('LINE'):
    x=e.dxf.start;y=e.dxf.end;v=y-x
    if v.magnitude<1e-8:continue
    if abs(abs(v.normalize().dot(u))-1)<1e-7 and abs((x-at).dot(ezdxf.math.Vec3(-u.y,u.x,0)))<1e-6:
     segments.append(sorted((x.dot(u),y.dot(u))))
   low,high=sorted((a.dot(u),b.dot(u)));textmid=q.dxf.text_midpoint.dot(u)
   assert any(x<=min(low,textmid)+1e-6 and y>=max(high,textmid)-1e-6 for x,y in segments),(path,q.dxf.handle,'broken dimension line')
   if low-1e-6<=textmid<=high+1e-6:assert abs(textmid-(low+high)/2)<1e-5
   else:assert q.dxf.text_midpoint.dot(reading)<min(a.dot(reading),b.dot(reading))
   # ezdxf does not import native user text locations into its rendering context;
   # regenerate centred cases only. All outside placements are checked above
   # against their serialized location and complete display-block extension.
   if low<=textmid<=high and (math.isclose(q.get_measurement(),400) or math.isclose(q.get_measurement(),280)):
    q.override().render();regenerated=doc.blocks[q.dxf.geometry]
    assert any(abs((e.dxf.start-at).dot(ezdxf.math.Vec3(-u.y,u.x,0)))<1e-6 and min(e.dxf.start.dot(u),e.dxf.end.dot(u))<textmid<max(e.dxf.start.dot(u),e.dxf.end.dot(u)) for e in regenerated.query('LINE')),(path,'regenerated centre gap')
   count+=1
  elif q.dimtype==4:
   c=q.dxf.defpoint;tip=q.dxf.defpoint4;u=(tip-c).normalize()
   assert abs(abs(reading.dot(u))-1)<1e-7,(path,'radius text angle')
   assert any((e.dxf.start-c).magnitude<1e-6 and (e.dxf.end-c).cross(u).magnitude<1e-5 and (e.dxf.end-c).dot(u)>(tip-c).magnitude for e in block.query('LINE')),(path,'radius line misses centre')
   q.override().render()
   native_lines=list(doc.blocks[q.dxf.geometry].query('LINE'))
   assert native_lines and all((e.dxf.start-c).cross(u).magnitude<1e-5 and (e.dxf.end-c).cross(u).magnitude<1e-5 for e in native_lines),(path,'regenerated radius direction')
   radial+=1
 records.append({'file':path.name,'continuous_linear_dimensions':count,'radial_lines_through_centre':radial})
assert len(records)==50
(root/'verification-layout.json').write_text(json.dumps({'passed':True,'files':len(records),'checks':records},indent=2))
print('50 documents passed continuous lines, centred/left placement, parallel text, under-text extensions and radial-centre alignment')
