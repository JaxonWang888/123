"""Independently compare Windows-produced DWG round trips with DXF geometry."""
import pathlib,subprocess,collections,math,json,sys
import ezdxf
base=pathlib.Path(sys.argv[1]);converter=sys.argv[2];report=[]
def signature(e):
 t=e.dxftype();d=e.dxf
 if t=='LINE':return (t,d.layer,*d.start,*d.end)
 if t=='CIRCLE':return (t,d.layer,*d.center,d.radius)
 if t=='ARC':return (t,d.layer,*d.center,d.radius,d.start_angle%360,d.end_angle%360)
 if t=='TEXT':return (t,d.layer,*d.insert,d.height,d.text)
 raise AssertionError(t)
for dwg in sorted(base.glob('case_*.dwg')):
 dst=dwg.with_suffix('.readback.dxf');r=subprocess.run([converter,'-y','-o',str(dst),str(dwg)],text=True,capture_output=True)
 assert r.returncode==0,(dwg.name,r.stderr)
 expected=ezdxf.readfile(dwg.with_suffix('.dxf'));actual=ezdxf.readfile(dst)
 for doc in [expected,actual]:
  assert doc.units==4
  audit=doc.audit();assert not audit.errors and not audit.fixes,(dwg.name,[(x.code,x.message) for x in audit.errors+audit.fixes])
 a=list(expected.modelspace());b=list(actual.modelspace());assert len(a)==len(b)
 for x,y in zip(a,b):
  xs,ys=signature(x),signature(y);assert len(xs)==len(ys)
  for u,v in zip(xs,ys):
   if isinstance(u,(int,float)):assert math.isclose(u,v,rel_tol=1e-9,abs_tol=1e-7),(dwg.name,u,v)
   else:assert u==v,(dwg.name,u,v)
 _,typ,slide,holes,ribs=dwg.stem.split('_');typ,slide,holes,ribs=map(int,(typ,slide,holes,ribs))
 hole_entities=[e for e in b if e.dxftype() in ('CIRCLE','ARC') and math.isclose(e.dxf.radius,27)]
 assert len(hole_entities)==holes*(2 if slide else 1)
 if typ==1:
  centers={round(e.dxf.center.y,7) for e in hole_entities}
  # Slot arcs have two centres per hole; all slots share the same axial row.
  assert len(centers)==(2 if slide else 1)
 report.append({'file':dwg.name,'entities':len(b),'holes':holes,'ribs':ribs,'audit_errors':0,'audit_fixes':0,'geometry_match':True})
assert len(report)==32,len(report)
(base/'roundtrip-report.json').write_text(json.dumps({'passed':True,'cases':report},indent=2));print(f'{len(report)} Windows DWGs: geometry, hole counts, units and audits passed')
