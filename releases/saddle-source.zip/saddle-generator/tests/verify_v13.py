# Independently audit actual Windows exports and DWG round trips.
import collections,json,math,pathlib,subprocess,sys
import ezdxf
from ezdxf.lldxf.encoding import decode_dxf_unicode
root=pathlib.Path(sys.argv[1]);reader=pathlib.Path(sys.argv[2]);report=[]
layer='6 尺寸线-管口号外圆（细实线）'
for dwg in sorted(root.glob('case_*.dwg'))+[root/'notch-sample.dwg']:
    if dwg.stem=='notch-sample': type_,holes,ribs=0,3,6
    else:
        _,type_,_,holes,ribs=dwg.stem.split('_');type_,holes,ribs=map(int,(type_,holes,ribs))
    expected_count=holes*(1 if type_ else 2);ys=([0] if holes%2 else [])
    distances=[] if holes==1 else [800] if holes<4 else [300,800]
    for d in distances:ys.extend((-d,d))
    ys.sort();converted=dwg.with_suffix('.readback.dxf')
    subprocess.run([str(reader),str(dwg),str(converted)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for path in (dwg.with_suffix('.dxf'),converted):
        doc=ezdxf.readfile(path);audit=doc.audit();assert not audit.errors and not audit.fixes,(path,audit.errors,audit.fixes)
        ms=doc.modelspace();dims=list(ms.query('DIMENSION'));assert len(dims)>25
        assert doc.header['$INSUNITS']==4 and doc.header['$DIMSCALE']==15
        for dim in dims:
            assert dim.dxf.layer==layer and dim.dxf.dimstyle=='HM 1-1'
            style=doc.dimstyles.get(dim.dxf.dimstyle)
            for k,v in dict(dimscale=15,dimlfac=1,dimtxt=3.5,dimasz=2.5,dimexo=.625,dimexe=1,dimgap=1,dimdec=1).items():assert math.isclose(style.dxf.get(k),v), (k,style.dxf.get(k),v)
            assert dim.dxf.dimtype&128
            assert dim.override().get('dimscale')==15 and dim.override().get('dimtmove')==2
            assert dim.dxf.geometry in doc.blocks
            assert doc.blocks[dim.dxf.geometry].block.dxf.flags&1
            raw=dim.dxf.actual_measurement;measured=dim.get_measurement()
            if dim.dxf.dimtype&7==5:raw=math.degrees(raw)
            assert math.isclose(raw,measured,abs_tol=1e-6)
        texts=[decode_dxf_unicode(e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text) for e in ms.query('TEXT MTEXT')]
        assert not any(any(s in text for s in ('Note','Deg-3','BOM','Ls','A-A','B-B','VIEW A','***')) for text in texts)
        assert not list(ms.query('LEADER MLEADER TABLE INSERT'))
        arrows=list(ms.query('SOLID'));assert len(arrows)>=7
        assert all(e.dxf.layer=='2 明细栏-技术特性表-剖面线-管口表-管口载荷表（细实线）' for e in arrows)
        assert len(ms.query('SPLINE'))==1 and ms.query('SPLINE')[0].dxf.layer=='5 断开线（双点划线）'
        assert all(e.dxf.layer=='2 明细栏-技术特性表-剖面线-管口表-管口载荷表（细实线）' for e in doc.query('TEXT MTEXT'))
        assert not any((dim.dxf.dimtype&7)==3 for dim in dims)
        tol=[dim for dim in dims if dim.override().get('dimtol',0)]
        assert len(tol)==2*(holes//2)
        for dim in tol:
            assert dim.override().get('dimtp')==1 and dim.override().get('dimtm')==1 and dim.override().get('dimtdec')==1
            assert any(math.isclose(dim.get_measurement(),v*2) for v in distances)
        detail=[dim for dim in dims if dim.override().get('dimlfac',1)!=1];assert len(detail)==3
        actual=sorted(round(dim.dxf.actual_measurement*dim.override().get('dimlfac'),6) for dim in detail)
        assert actual==[27,36,54],actual
        # Regenerate detail dimensions independently, then simulate a CAD reset of
        # DIMLFAC: explicit actual-part text must remain unchanged in either case.
        for detail_dim in detail:
            expected=round(detail_dim.dxf.actual_measurement*detail_dim.override().get('dimlfac'),6)
            text=decode_dxf_unicode(detail_dim.dxf.text)
            assert '<>' not in text and str(int(expected)) in text
            for factor in (detail_dim.override().get('dimlfac'),1):
                override=detail_dim.override();override['dimlfac']=factor;override.render()
                labels=[decode_dxf_unicode(e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text) for e in doc.blocks[detail_dim.dxf.geometry].query('TEXT MTEXT')]
                assert any(str(int(expected)) in value for value in labels),(path,expected,labels)

        assert sum('Fixed Saddle' in text for text in texts)==1 and sum('Sliding Saddle' in text for text in texts)==1
        ratio=15;W,H=594*ratio,420*ratio
        expected_x=[W*.19] if type_ else [W*.19-220,W*.19+220]
        holes_actual=sorted((round(e.dxf.center.x,6),round(e.dxf.center.y,6)) for e in ms.query('CIRCLE') if math.isclose(e.dxf.radius,27,abs_tol=1e-6))
        expected=sorted((round(x,6),round(H*.245+y,6)) for x in expected_x for y in ys)
        assert holes_actual==expected,(path,holes_actual,expected)
        sections=list(ms.query('HATCH'));expected_sections=2*((ribs+1) if type_ else (2*ribs-1));assert len(sections)==expected_sections
        rectangles=[]
        for section in sections:
            assert section.dxf.pattern_name=='ANSI31' and not section.dxf.solid_fill
            assert len(section.paths)==1
            verts=section.paths[0].vertices;xs=[p[0] for p in verts];ys_=[p[1] for p in verts]
            assert len(verts)==4;rectangles.append((min(xs),min(ys_),max(xs),max(ys_)))
        # Exported web ends must coincide with the actual outer-rib INNER faces.
        # Derive the faces from the exported rib hatch boundaries, not defaults.
        for px in (W*.19,W*.405):
            webs=[a for a in rectangles if math.isclose(a[2]-a[0],12,abs_tol=1e-6) and math.isclose((a[0]+a[2])/2,px+((1 if px>W*.3 else -1)*146 if type_ else 0),abs_tol=1e-6)]
            assert len(webs)==1
            transverse=[a for a in rectangles if a[0]>=px-140-1e-6 and a[2]<=px+140+1e-6 and a[3]-a[1]<100]
            low=min(transverse,key=lambda a:a[1]);high=max(transverse,key=lambda a:a[3]);web=webs[0]
            assert math.isclose(web[1],low[3],abs_tol=1e-6) and math.isclose(web[3],high[1],abs_tol=1e-6),(path,web,low,high)
            assert web[1]>H*.245-900 and web[3]<H*.245+900
        for i,a in enumerate(rectangles):
            for b in rectangles[i+1:]:assert min(a[2],b[2])-max(a[0],b[0])<1e-6 or min(a[3],b[3])-max(a[1],b[1])<1e-6
        # True projection heights and flat top caps measured from exported front edges.
        front=[e for e in ms.query('LINE') if e.dxf.layer=='可见 (Himile)' and e.dxf.start.x>W*.5 and e.dxf.end.x>W*.5]
        caps=[e for e in front if math.isclose((e.dxf.end-e.dxf.start).magnitude,12,abs_tol=1e-6) and e.dxf.start.y>H*.52+24 and e.dxf.end.y>H*.52+24]
        caps=[cap for cap in caps if any(((edge.dxf.start-cap.dxf.start).magnitude<1e-6 or (edge.dxf.end-cap.dxf.start).magnitude<1e-6) and (edge.dxf.end-edge.dxf.start).magnitude>100 for edge in front)]
        assert len(caps)==ribs,(path,len(caps),ribs)
        for cap in caps:
            a,b=cap.dxf.start,cap.dxf.end
            matching=[]
            for edge in front:
                if (edge.dxf.start-a).magnitude<1e-6 or (edge.dxf.end-a).magnitude<1e-6:
                    if (edge.dxf.end-edge.dxf.start).magnitude>100:matching.append(edge)
            assert any(abs((e.dxf.end-e.dxf.start).dot(b-a))<1e-5 for e in matching),(path,'non-perpendicular end')
        # Invisible bolt projection and pad/web occlusion are actual hidden layers.
        hidden=[e for e in ms.query('LINE') if e.dxf.layer=='4 不可见线（虚线）']
        for edge in hidden:
            length=(edge.dxf.end-edge.dxf.start).magnitude
            if length>1e-8:assert length/(19.05*doc.header['$LTSCALE']*edge.dxf.ltscale)>=3-1e-6
        base_hidden=[e for e in hidden if math.isclose(e.dxf.start.y,H*.52,abs_tol=1e-6) and math.isclose(e.dxf.end.y,H*.52+24,abs_tol=1e-6)]
        assert len(base_hidden)==(4 if type_ else 8)
        vent_bottom=H*.52+1400-1012;vent_top=vent_bottom+12
        vents=[e for e in hidden if math.isclose(e.dxf.start.y,vent_bottom,abs_tol=1e-6) and math.isclose(e.dxf.end.y,vent_top,abs_tol=1e-6)]
        assert len(vents)==4
        assert sorted(round((e.dxf.start.x+e.dxf.end.x)/2,6) for e in vents)==sorted(round(x,6) for x in (W*.19+177,W*.19+183,W*.405-177,W*.405-183))
        if dwg.stem=='notch-sample':
            centre=(W*.72,H*.52+1400);radial=[]
            for edge in ms.query('LINE'):
                a,b=edge.dxf.start,edge.dxf.end
                if a.x<W*.5 or a.y<H*.52:continue
                if math.isclose((b-a).magnitude,50,abs_tol=1e-7):
                    ar=(a.x-centre[0],a.y-centre[1]);br=(b.x-centre[0],b.y-centre[1]);assert abs(ar[0]*br[1]-ar[1]*br[0])<1e-5
                    assert all(math.isclose(x,y,abs_tol=1e-6) for x,y in zip(sorted((math.hypot(*ar),math.hypot(*br))),(1012,1062)))
                    radial.append(edge)
            assert len(radial)==2
        assert doc.styles.get('Saddle_SimSun').dxf.font=='simsun.ttc'
        assert any('Vent Hole' in text for text in texts) and any('M48 Q235B' in text for text in texts)
        assert any('TYP.(' in text for text in texts) and '12.5' in texts
        radius=list(ms.query('LARGE_RADIAL_DIMENSION'));assert len(radius)==1
        radius=radius[0];assert radius.dxf.dimstyle=='HM 1-1' and radius.dxf.layer==layer
        assert math.isclose(radius.dxf.actual_measurement,1000) and math.isclose((radius.dxf.chord_point-radius.dxf.defpoint).magnitude,1000)
        assert math.isclose(radius.dxf.unknown2,math.pi/4) and radius.dxf.geometry in doc.blocks
        assert doc.dxfversion>='AC1018'
        welds=[e for e in ms.query('CIRCLE') if math.isclose(e.dxf.radius,13.5)];assert len(welds)==1
        weld=welds[0].dxf.center;assert weld.x<W*.3
        assert any((e.dxf.end-weld).magnitude<1e-6 and e.dxf.start.y>weld.y+100 for e in ms.query('LINE'))
        crop=[e for e in ms.query('CIRCLE') if math.isclose(e.dxf.radius,306)];assert len(crop)==1
        assert crop[0].dxf.center.x<W*.6 and crop[0].dxf.center.x-306>W*.405+280+120*(len(distances)*.9+2.5)
        
        for px in (W*.19,W*.405):
            inside=[e for e in hidden if math.isclose(e.dxf.start.y,H*.52+400) and math.isclose(e.dxf.end.y,H*.52+400) and math.isclose(e.dxf.start.x,px-200) and math.isclose(e.dxf.end.x,px+200)]
            assert len(inside)==1
        if dwg.stem=='notch-sample':
            assert 'WEB GAP' in texts
            reference=[dim for dim in dims if dim.dxf.get('text','')=='(<>)'];assert len(reference)==1
            contact=(W*.72+1012*math.sin(math.radians(60)),H*.52+1400-1012*math.cos(math.radians(60)))
            q=reference[0];assert math.dist((q.dxf.defpoint2.x,q.dxf.defpoint2.y),contact)<1e-6
            assert math.isclose(math.dist((q.dxf.defpoint3.x-W*.72,q.dxf.defpoint3.y-(H*.52+1400)),(0,0)),1012,abs_tol=1e-6)
         
        assert '固定鞍座' in texts and '滑动鞍座' in texts and '排气孔' in texts
        assert not any('????' in text for text in texts)
        assert doc.header['$TEXTSTYLE']=='HM-ASME'
        assert all(e.dxf.style=='HM-ASME' for e in doc.query('TEXT MTEXT'))
        assert doc.styles.get('HM-ASME').get_extended_font_data()==('Arial',False,False)
        assert doc.styles.get('Saddle_SimSun').get_extended_font_data()==('SimSun',False,False)
        for text in doc.query('TEXT MTEXT'):
            assert text.dxf.style=='HM-ASME'
            if text.dxftype()=='MTEXT' and any(0x3400<=ord(c)<=0x9fff for c in decode_dxf_unicode(text.plain_text())):
                assert r'\fSimSun|b0|i0|c134|p18;' in text.text and r'\W1;' in text.text and r'\P' not in text.text
        assert radius.override().get('dimscale')==15 and radius.override().get('dimtmove')==2 and radius.dxf.dimtype&128
        # Independently regenerate angle dimensions from their native definitions.
        # V8 used defpoint=(0,0), yielding a 7938 mm arc; the intended radii are 450/650.
        angles=[q for q in dims if q.dimtype==5];assert len(angles)==2
        assert sorted(round((q.dxf.defpoint-q.dxf.defpoint4).magnitude,6) for q in angles)==[450,650]
        regenerated=[]
        for angle in angles:
            angle.override().render()
            arcs=list(doc.blocks[angle.dxf.geometry].query('ARC'))
            regenerated.extend(round(a.dxf.radius,6) for a in arcs)
        assert sorted(regenerated)==[450,650],regenerated
        report.append({'file':path.name,'native_dimensions':len(dims),'native_hatches':len(sections),'audit_errors':0,'audit_fixes':0})
(root/'verification-v13.json').write_text(json.dumps({'passed':True,'files':len(report),'checks':report},ensure_ascii=False,indent=2))
print(f'{len(report)} V13 direct/readback CAD documents passed style/scale/layer, placement, flat ends, hidden projection and disjoint native hatch checks')
